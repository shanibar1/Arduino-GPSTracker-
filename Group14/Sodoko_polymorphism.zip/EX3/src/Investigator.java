
public class Investigator extends Agent {
	private double contribution;
	private int rank; 
	public Investigator (String name, int ID, int experience, boolean canDrive, double contribution, int rank) throws IllegalIDException, IllegalRankException, IllegalContributionException {
		super(ID, name, experience,0, canDrive);
		this.contribution = contribution;
		if(!(rank>0)) {//throwing exception rank has to be positive number
			throw new IllegalRankException("this rank is not positive!");
		}
		if(!(contribution>0)) {// throwing exception contribution has to be positive number
			throw new IllegalContributionException("this contribution is not positive!");
		}
	}
	public double getcontriblution() {
		return this.contribution;
	}
	public int rank() {
		return this.rank;
	}
	
	public void updateSalary(int opLevel) {
		this.salary += this.rank * this.contribution;
	}
}

