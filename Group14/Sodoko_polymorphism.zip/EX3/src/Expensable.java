
public interface Expensable {
	public double getUsageCost();
}
