
public interface Experiencable {
	public int getexperience();
	
}
