
public class Detective extends Agent{
	private boolean weaponLicense;

	public Detective (String name, int ID, int experience, boolean canDrive ,boolean weaponLicense) throws IllegalIDException {
		super(ID, name, experience,0, canDrive);
		this.weaponLicense = weaponLicense;
	}
	public boolean getweaponLicense() {
		return this.weaponLicense;
	}

	public void updateSalary(int opLevel) {
		this.salary += opLevel*this.experience;
	}
}
