public class IllegalContributionException extends RuntimeException {
	public  IllegalContributionException(String msg){
		super(msg);
	}
}
