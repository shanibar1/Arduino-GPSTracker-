import java.util.Vector;
abstract public class Vehicle implements Expensable, Comparable <Vehicle> {
	protected int speed;
	protected double usageCost;
	protected int capacity;
	protected int ID;
	protected Vector <Agent> team;
	protected boolean deployed;

	public Vehicle (int speed,double usageCost,int capacity,int ID) {//Contractor
		this.speed = speed;
		this.usageCost = usageCost;
		this.ID = ID;
		team = new Vector <Agent>();
		if (this instanceof Motorcycle) {
			double prob = Math.random();
			if (prob > 1/2) {
				this.capacity = 1;
			}
			else this.capacity = 2;
		} else {
			this.capacity = capacity;
		}
		this.deployed = false;
	}

	public int getID() {
		return this.ID;
	}
	
	
	public int numOFlicenses() {// the num of licenses in the current vehicle
		int haveLicanse = 0;
		for(int i = 0 ;i < team.size(); i++) {
			if(team.get(i).getcanDrive()) {
				haveLicanse = haveLicanse + 1;
			}
		}
		return haveLicanse;
	}

	public int dontHaveLicanse() {// the num of licenses we don't have in the current vehicle
		int dontHaveLicanse = -1;
		for(int i=0;i<team.size();i++) {
			if(team.get(i).getcanDrive() == false) {
				dontHaveLicanse = i;
			}
		}
		return dontHaveLicanse;
	}

	public void addDetective (Agent agent) { // adding detective to vehicle
		if(team.size() == capacity) {
			throw new capacityerrorexcaption("Error,Thecarisfullcapacity");
		}
		team.add(agent); 
	}
	public int remaining () {
		return this.capacity - this.team.size();
	}
	
	public void addAgent(Agent agent) {
		if (agent instanceof Detective) {
			this.addDetective(agent);
		}
		else
			this.addInvestigator(agent);
	}
	
	public void addInvestigator (Agent agent) {
		int iDont=dontHaveLicanse();
		if(team.size() == capacity) {
			if ((agent.getcanDrive() == false && iDont == -1)||agent.getcanDrive() == true) {//�� ����� �� ������
				team.remove(capacity-1);
				team.add(capacity-1,agent);
			}
			if (agent.getcanDrive() == false) {//�� ����� �� ������
				team.remove(iDont);
				team.add(iDont,agent);//����� ��� ������ ���� ������
			}
		}
		if(team.size() == capacity-1) {
			if (agent.getcanDrive()) {
				team.add(agent);	
			}
			if(agent.getcanDrive() == false && numOFlicenses() > 0 ) {
				team.add(agent);
			}
		}
		team.add(agent); 
	}

	protected int getspeed () {
		return speed;
	}
	public int compareTo(Vehicle eOther) {
		if(this.getspeed() > eOther.getspeed())
			return 1;
		else if(this.getspeed() < eOther.getspeed())
			return -1;
		else
			return 0;
	}
	public double getUsageCost() {
		return this.usageCost;
	}
	
	public double getUsageCost(int opLevel) { // not used, for agent
		return 0;
	}
	
	public Vector<Agent> getTeam(){
		return this.team;
	}
	
	public boolean isDeployed()
	{
		return this.deployed;
	}
	
	public void deploy()
	{
		this.deployed = true;
	}
	
	public void release()
	{
		this.deployed = false;
	}
	
}

