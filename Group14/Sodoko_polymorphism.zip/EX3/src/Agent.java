
public abstract class Agent implements Comparable <Agent> , Experiencable, Expensable {
	protected int	ID;
	protected String name;
	protected int experience;
	protected double salary;
	protected boolean canDrive;
	protected boolean deployed;
	
	protected Agent(int ID, String name, int experience, int salary, boolean canDrive) throws IllegalIDException {// Contractor
		this.ID = ID;
		if(!(ID >= 10000 && ID <= 99999)) {
			throw new IllegalIDException("ID is not length five!");
		}
		this.name = name;
		this.experience = experience;
		this.salary = salary;
		this.canDrive = canDrive;
		this.deployed = false;
	}
	public int getID() {
		return this.ID;
	}
	
	public String getname() {
		return this.name;
	}
	public int getexperience() {
		return this.experience;
	}
	public double getsalery() {
		return this.salary;
	}
	
	public double getUsageCost() {
		return salary;
	}
	
	public int compareTo(Agent other) {
		if(getexperience()>other.getexperience()) {
			return 1;
		}
		else if(getexperience()<other.getexperience()) {
			return -1;
		}
		else
			return 0;
	}
	public boolean getcanDrive() {
		return this.canDrive;
	}
	
	public boolean isDeployed()
	{
		return this.deployed;
	}
	
	public void deploy()
	{
		this.deployed = true;
	}
	
	public void release()
	{
		this.deployed = false;
	}
	
	public abstract void updateSalary(int opLevel);
	
}
