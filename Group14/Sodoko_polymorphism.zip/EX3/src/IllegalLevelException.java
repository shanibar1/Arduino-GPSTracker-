public class IllegalLevelException extends RuntimeException {
	public  IllegalLevelException(String msg){
		super(msg);
	}
}
