import java.util.Vector;

public class Operation implements Comparable<Operation> {
	private int level;
	private Vector <Agent> assignedAgents; // TODO: when assigning an agent to an operation, update this variable
	private Vector <Vehicle> assignedVehicles; // TODO: when assigning a vehicle to an operation, update this variable
	private String codeName;

	public Operation(int level, String codeName) throws IllegalLevelException {
		this.level = level;
		if (!(this.level >= 0 && this.level <= 5)) {
			throw new IllegalLevelException("level must be between one to five!");
		}
		this.codeName = codeName;
		this.assignedVehicles = new Vector<Vehicle>();
		this.assignedAgents = new Vector<Agent>();
	}
	
	public String getOperationType() {
		switch(this.level) {
		case 1:
			return "inquiry";
		case 2:
			return "Background check";
		case 3:
			return "surveillance";
		case 4:
			return "fraud and illegal activity";
		case 5:
			return "missing people";
		default:
			return "unknown operation type";
		}
	}
	
	
	public Vector<Agent> getAssignedAgents() {
		return this.assignedAgents;
	}
	
	public void addAssignedVehicles(Vehicle e) {
		this.assignedVehicles.add(e);
		this.assignedAgents.addAll(e.getTeam());
	}

	
	public Vector<Vehicle> getAssignedVehicles() {
		return this.assignedVehicles;
	}
	
	public String getCodename() {
		return this.codeName;
	}

	public int numOfInvestigators() {
		switch (this.level) {
		case 1:
			return 2;
		case 2:
			return 3;
		case 3:
			return 1;
		case 4:
			return 4;
		case 5:
			return 7;
		default:
			return 0;
		}
	}

	public int numOfDetectives() {
		switch (this.level) {
		case 1:
			return 0;
		case 2:
			return 2;
		case 3:
			return 5;
		case 4:
			return 6;
		case 5:
			return 8;
		default:
			return 0;
		}
	}

	public int getLevel() {
		return this.level;
	}

	public int compareTo(Operation other) {
		if (this.getLevel() > other.getLevel()) {
			return 1;
		} else if (this.getLevel() < other.getLevel()) {
			return -1;
		} else
			return 0;
	}
}