public class Motorcycle extends Vehicle{
	public Motorcycle (int motorID, int speed, double usageCost) {
		super(speed, usageCost, 0,motorID);
	}
}
