public class IllegalRankException extends RuntimeException {
	
	public  IllegalRankException(String msg){
		super(msg);
	}
	public  IllegalRankException(){
		super();
	}
}

