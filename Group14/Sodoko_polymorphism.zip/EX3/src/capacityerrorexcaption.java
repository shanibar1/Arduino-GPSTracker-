public class capacityerrorexcaption extends RuntimeException {

	public capacityerrorexcaption(String msg){
	super(msg);
}
}
