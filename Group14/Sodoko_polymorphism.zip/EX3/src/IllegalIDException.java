public class IllegalIDException extends RuntimeException{
	
	public IllegalIDException(String msg){
		super(msg);
	}
	
}

