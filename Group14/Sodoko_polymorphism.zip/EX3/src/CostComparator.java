import java.util.Comparator;

public class CostComparator implements Comparator<Expensable>{

	public int compare(Expensable e1, Expensable e2) {
		if(e1.getUsageCost() < e2.getUsageCost())
			return -1;
		else if(e1.getUsageCost() > e2.getUsageCost())
			return 1;
		else return 0;
	}
}
