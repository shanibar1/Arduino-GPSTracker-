public class Car extends Vehicle{
	private int fuelCap;

	public Car(int carId, int speed, double usageCost, int capacity, int fuelCap) {
		super(speed,usageCost,capacity,carId);
		this.fuelCap=fuelCap;
		if(capacity<3||capacity>6) {
			throw new RuntimeException("capacityErrorExcaption");
		}
	}
}
