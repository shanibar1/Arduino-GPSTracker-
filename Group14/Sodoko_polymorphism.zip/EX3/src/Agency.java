
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;
public class Agency {
	private Vector <Agent> agentsVec;
	private Vector <Vehicle> vehiclesVec;
	private Vector <Operation> ops;


	public Agency (String agents, String vehicles) throws NumberFormatException, IllegalIDException, IllegalRankException, IllegalContributionException {// constractor + reading file 
		agentsVec = new Vector <Agent>();
		this.ops = new Vector<Operation>();

		BufferedReader inFile = null;
		try
		{
			FileReader agentsFile = new FileReader (agents);
			inFile = new BufferedReader (agentsFile);
			String line = inFile.readLine();// do not read the first line
			while (!line.isEmpty()) {
				line = inFile.readLine();
				if (line == null || line.isEmpty()) {
					break;
				}
				String []currAgent =line.split("	");// separate to strings
				switch (currAgent[2])
				{
				case "Detective":
					agentsVec.add(new Detective(currAgent[0], Integer.parseInt(currAgent[1]), Integer.parseInt(currAgent[3]), Boolean.parseBoolean(currAgent[4]), Boolean.parseBoolean(currAgent[5])));
					break;
				case "Investigator":
					agentsVec.add(new Investigator(currAgent[0], Integer.parseInt(currAgent[1]), Integer.parseInt(currAgent[3]), Boolean.parseBoolean(currAgent[4]),Double.parseDouble(currAgent[6]),Integer.parseInt(currAgent[7])) );
					break;
				}
			}
		}

		catch (FileNotFoundException exception)
		{
			System.out.println ("The file " + agents + " was not found.");
		}
		catch (IOException exception)
		{
			System.out.println (exception);
		}
		finally{
			try{
				inFile.close();
			} 
			catch(IOException exception){
				exception.printStackTrace();
			}
		}

		vehiclesVec = new Vector <Vehicle>();

		inFile=null;
		try
		{
			FileReader vehiclesFile = new FileReader (vehicles);
			inFile = new BufferedReader (vehiclesFile);
			String line = inFile.readLine();// do not read the first line
			while (!line.isEmpty()) {
				line = inFile.readLine();
				if (line == null || line.isEmpty()) {
					break;
				}
				String []currVehicle =line.split("	");// separate to strings
				switch (currVehicle[1])
				{
				case "Car":
					vehiclesVec.add(new Car (Integer.parseInt(currVehicle[0]),Integer.parseInt(currVehicle[2]) , Double.parseDouble(currVehicle[3]), Integer.parseInt(currVehicle[4]),Integer.parseInt(currVehicle[5]) ));
					break;
				case "Motorcycle":
					vehiclesVec.add(new Motorcycle (Integer.parseInt(currVehicle[0]), Integer.parseInt(currVehicle[2]),Double.parseDouble(currVehicle[3])));
					break;
				}
			}
		}

		catch (FileNotFoundException exception)
		{
			System.out.println ("The file " + vehicles + " was not found.");
		}
		catch (IOException exception)
		{
			System.out.println (exception);
		}
		finally{
			try{
				inFile.close();
			} catch(IOException exception){
				exception.printStackTrace();
			}
		}

	}
	public static <T extends Comparable<T>> T getMax(Vector<T> vec) {
		T curr = vec.get(0);
		for (int i = 1; i < vec.size(); i++) {
			if (curr.compareTo(vec.get(i)) < 0) {//find the max speed
				curr = vec.get(i);
			}
		}
		return curr;

	}


	public Vector<Operation> getOps(){
		return this.ops;
	}
	public void endOperation(String codename) throws Exception
	{
		Operation currentOp = null; // pointer to find the specific operation that the user entered
		for(int i = 0; i < this.ops.size(); i++) {
			if(this.ops.get(i).getCodename().equals(codename)) {//finds by codename
				currentOp = this.ops.get(i);
			}
		}

		if (currentOp == null) {// if we cannot found the codename
			System.out.println("The codename you have entered has no open operation");
			return;
		}

		Vector<Agent> assignedAgents = currentOp.getAssignedAgents(); //gives access to the operation field
		Vector<Vehicle> assignedVehicles = currentOp.getAssignedVehicles(); //gives access to the operation field

		Comparator <Expensable> comp = new CostComparator();
		int mostexpensive = Collections.max(currentOp.getAssignedVehicles(), comp).getID();	// finds the most expensive vehicle	
		for(int i = 0; i < assignedAgents.size(); i++) {// release active agents
			assignedAgents.get(i).release();	
		}
		for(int i = 0; i < assignedVehicles.size(); i++) {// release active vehicles
			assignedVehicles.get(i).release();
		}
		System.out.println("Operation Ended:");
		System.out.println("Code Name: " + currentOp.getCodename());
		System.out.println("Operation: " + currentOp.getOperationType());
		System.out.println("Number of agents in the event: " + String.valueOf(assignedAgents.size()));
		System.out.println("Agents average years of experience: " + String.valueOf(Agency.averageExperience(assignedAgents)));
		System.out.println("Operation cost: " + String.valueOf(Agency.totalExpenses(assignedVehicles)+ Agency.totalExpenses(assignedAgents)));
		System.out.println("Most expensive vehicle: "+ mostexpensive);

	}

	public boolean level2Op(Operation op) {
		Vector<Vehicle> vehicles = new Vector<>();// the specific vehicles for this operation from vehicleVec
		Vector<Agent> agents = new Vector<>();// the specific agents for this operation from agentsleVec
		int requiredInvesNum = op.numOfInvestigators(); //number of investigator we need from the chart
		int requiredDetNum = op.numOfDetectives(); //number of Detectives we need from the chart
		int numOfVehicles = vehicles.size(); // number of vehicles for this specific operation

		int remainingSeats = requiredInvesNum + requiredDetNum; // number of seat we needs foe all of the vehicles
		for (int i = 0; i < this.vehiclesVec.size() && remainingSeats > 0; i++) {//entered all the deployed vehicles
			if(this.vehiclesVec.get(i).isDeployed()) {
				continue;
			}
		Vehicle currentVehicle = this.vehiclesVec.get(i);
		vehicles.add(currentVehicle);// add vehicle for op vehicles vector
		remainingSeats = remainingSeats - currentVehicle.capacity;

		if(remainingSeats > 0)
			return false;

		int counter = 0;
		if (numOfVehicles < 2) {
			for(int j = 0; j <= this.agentsVec.size() && agents.size() < numOfVehicles ; j++) {//Check how many agents with car license there are
				if (this.agentsVec.get(j).getcanDrive()) {
					counter++;
				}
			}
			if (counter < 2) {// if the number of license smaller than 2 
				return false;
			}
			else { 
				vehicles.add(this.vehiclesVec.get(i+1));
				this.vehiclesVec.get(i+1).deploy(); 
				for(int k = 0 ; i < agents.size(); k++) {// verify that the agent that we had got a car license
					if (this.agentsVec.get(k).getcanDrive()) {
						if(this.agentsVec.get(k) instanceof Detective) {
							vehicles.get(i+1).addDetective(agents.get(k));
							agents.remove(k);
						}
						if(this.agentsVec.get(k) instanceof Investigator) {
							vehicles.get(i+1).addInvestigator(agents.get(k));
							agents.remove(k);
						}
					}
				}
			}
		}
	}
		int neededDrivers = vehicles.size();
		for(int i=0; i< this.agentsVec.size() && agents.size()  < numOfVehicles ; i++) {
			if(!this.agentsVec.get(i).isDeployed()) {//�� ��� �� �����
				if(this.agentsVec.get(i).getcanDrive()){// �� ��� ���
					if(this.agentsVec.get(i) instanceof Detective && requiredDetNum>0 ) {//insert the number of Detectives for this level
						agents.add(this.agentsVec.get(i));
						this.agentsVec.get(i).deploy();
						requiredDetNum--;
						vehicles.get(agents.size()-1).addDetective(this.agentsVec.get(i));
					}
					if(this.agentsVec.get(i) instanceof Investigator && requiredInvesNum>0) {//insert the number investigators of  for this level
						agents.add(this.agentsVec.get(i));
						requiredInvesNum--;
						this.agentsVec.get(i).deploy();
						vehicles.get(agents.size()-1).addInvestigator(this.agentsVec.get(i));
					}
					neededDrivers--;
				}
			}
		}

		if(neededDrivers > 0)
			return false;

		for(int i = 0; i< this.agentsVec.size() ; i++) {// fill the capacity for each vehicle
			if(this.agentsVec.get(i) instanceof Detective && requiredDetNum>0 && !this.agentsVec.get(i).isDeployed()) {
				agents.add(this.agentsVec.get(i));
				requiredDetNum--;
			}
			if(this.agentsVec.get(i) instanceof Investigator && requiredInvesNum>0 && !this.agentsVec.get(i).isDeployed()) {
				agents.add(this.agentsVec.get(i));
				requiredInvesNum--;
			}
			if(requiredInvesNum == 0 && requiredDetNum == 0) {// finish added all the agents in the vehicles 
				break;
			}
		}

		if(requiredDetNum > 0 || requiredInvesNum > 0)
			return false;

		for(int i = 0 ; i<vehicles.size(); i++) {
			op.addAssignedVehicles(vehicles.get(i));
		}
		this.ops.add(op);// add this operation to the operation vec 
		return true;	
	}

	public boolean levelOneOp(Operation op) {
		Vector<Vehicle> vehicles = new Vector<>();
		Vector<Agent> agents = new Vector<>();
		int requiredInvesNum = op.numOfInvestigators();
		int requiredDetNum = op.numOfDetectives();

		int remainingSeats = requiredInvesNum + requiredDetNum;
		for (int i = 0; i < this.vehiclesVec.size() && remainingSeats > 0; i++) {
			if(this.vehiclesVec.get(i).isDeployed()) {
				continue;
			}
			Vehicle currentVehicle = this.vehiclesVec.get(i);
			vehicles.add(currentVehicle);
			remainingSeats = remainingSeats - currentVehicle.capacity;
		}

		int numOfVehicles = vehicles.size();
		if(remainingSeats > 0)
			return false;

		int neededDrivers = vehicles.size();
		for(int i=0; i< this.agentsVec.size() && agents.size()  < numOfVehicles ; i++) {
			if(!this.agentsVec.get(i).isDeployed()) {
				if(this.agentsVec.get(i).getcanDrive()){
					if(this.agentsVec.get(i) instanceof Detective && requiredDetNum>0 ) {// //insert the number of Detectives for this level
						agents.add(this.agentsVec.get(i));
						this.agentsVec.get(i).deploy();
						requiredDetNum--;
						vehicles.get(agents.size()-1).addDetective(this.agentsVec.get(i));
					}
					if(this.agentsVec.get(i) instanceof Investigator && requiredInvesNum>0) {////insert the number investigators of  for this level
						agents.add(this.agentsVec.get(i));
						requiredInvesNum--;
						this.agentsVec.get(i).deploy();
						vehicles.get(agents.size()-1).addInvestigator(this.agentsVec.get(i));
					}
					neededDrivers--;
				}
			}
		}

		if(neededDrivers > 0)
			return false;

		for(int i = 0; i< this.agentsVec.size() ; i++) {// // fill the capacity for each vehicle
			if(this.agentsVec.get(i) instanceof Detective && requiredDetNum>0 && !this.agentsVec.get(i).isDeployed()) {
				agents.add(this.agentsVec.get(i));
				requiredDetNum--;
			}
			if(this.agentsVec.get(i) instanceof Investigator && requiredInvesNum>0 && !this.agentsVec.get(i).isDeployed()) {
				agents.add(this.agentsVec.get(i));
				requiredInvesNum--;
			}
			if(requiredInvesNum==0 && requiredDetNum ==0) {// finish added all the agents in the vehicles 
				break;
			}
		}

		if(requiredDetNum > 0 || requiredInvesNum > 0)
			return false;

		for(int i = 0 ; i<vehicles.size(); i++) {
			op.addAssignedVehicles(vehicles.get(i));
		}
		this.ops.add(op);// adding operation to the operationsvec
		return true;	
	}

	public boolean openOperation (int level, String codeName) throws IllegalLevelException {
		Collections.sort(this.agentsVec);
		Collections.reverse(this.agentsVec);
		Collections.sort(this.vehiclesVec);
		Collections.reverse(this.vehiclesVec);
		Operation op1 = new Operation(level,codeName);
		switch(level) {
		case 1:
			return levelOneOp(op1) ;
		case 2:
			return levelOneOp(op1); 
		case 3:
			return level2Op(op1);
		case 4:
			return level3Op(op1); 
		case 5:
			return level3Op(op1);
		default:
			return false;
		}
	}
	public static double averageExperience (Vector <? extends Experiencable > A) {
		double sumExp = 0;
		for(int i = 0; i < A.size(); i++) {
			sumExp = sumExp + A.get(i).getexperience();
		}
		return sumExp/A.size();
	}
	public static double totalExpenses(Vector <? extends Expensable > C) {
		double sumCostC = 0;
		for(int i = 0; i < C.size(); i++) {
			sumCostC = sumCostC + C.get(i).getUsageCost();
		}

		return sumCostC;

	}

	public boolean level3Op(Operation op) {
		Vector<Vehicle> vehicles = new Vector<>();
		Vector<Agent> agents = new Vector<>();
		int requiredInvesNum = op.numOfInvestigators();
		int requiredDetNum = op.numOfDetectives();

		int remainingSeats = requiredInvesNum + requiredDetNum;
		for (int i = 0; i < this.vehiclesVec.size() && remainingSeats > 0; i++) {
			if(this.vehiclesVec.get(i).isDeployed()) {
				continue;
			}
			Vehicle currentVehicle = this.vehiclesVec.get(i);
			vehicles.add(currentVehicle);
			remainingSeats = remainingSeats - currentVehicle.capacity;
		}

		int numOfVehicles = vehicles.size();
		if(remainingSeats > 0)
			return false;

		int neededDrivers = vehicles.size();
		for(int i=0; i< this.agentsVec.size() && agents.size()  < numOfVehicles ; i++) {
			if(!this.agentsVec.get(i).isDeployed()) {//�� ��� �� �����
				if(this.agentsVec.get(i).getcanDrive()){// �� ��� ���
					if(this.agentsVec.get(i) instanceof Detective && requiredDetNum>0 ) {// ����� �� ���� ������� ������� ���� ������� ���
						agents.add(this.agentsVec.get(i));
						this.agentsVec.get(i).deploy();
						requiredDetNum--;
						vehicles.get(agents.size()-1).addDetective(this.agentsVec.get(i));
					}
					if(this.agentsVec.get(i) instanceof Investigator && requiredInvesNum>0) {//����� �� ���� ������ ������� ���� ��
						agents.add(this.agentsVec.get(i));
						requiredInvesNum--;
						this.agentsVec.get(i).deploy();
						vehicles.get(agents.size()-1).addInvestigator(this.agentsVec.get(i));
					}
					neededDrivers--;
				}
			}
		}

		if(neededDrivers > 0)
			return false;

		for(int i = 0; i< this.agentsVec.size() ; i++) {// ���� �� ���� ���� ����� ��� ����� �� ��CAPACITY ���� ���
			if(this.agentsVec.get(i) instanceof Detective && requiredDetNum>0 && !this.agentsVec.get(i).isDeployed()) {
				agents.add(this.agentsVec.get(i));
				requiredDetNum--;
			}
			if(this.agentsVec.get(i) instanceof Investigator && requiredInvesNum>0 && !this.agentsVec.get(i).isDeployed()) {
				agents.add(this.agentsVec.get(i));
				requiredInvesNum--;
			}
			if(requiredInvesNum==0 && requiredDetNum ==0) {// ������ �� �� ������ ���� ������ ����� ������
				break;
			}
		}

		if(requiredDetNum > 0 || requiredInvesNum > 0)
			return false;

		for(int i = 0 ; i<vehicles.size(); i++) {
			op.addAssignedVehicles(vehicles.get(i));
		}
		
		int sumwep=0;
		int[] vehicleWappensNum = new int[vehicles.size()];//���� �����- ��� ����� �� ��� ���
		for(int i =0 ; i<vehicles.size(); i++) {
			for(int j =0 ; j<vehicles.get(i).team.size(); j++) {
				if(vehicles.get(i).team.get(j) instanceof Detective) {
					if(((Detective)(vehicles.get(i).team.get(j))).getweaponLicense()) {//����� ������ �������
						sumwep++;
						vehicleWappensNum[i]++;
					}
				}}}
		if(vehicles.size() > sumwep) {
			return false;
		}
		boolean flag = false;
		int f=0;
		int haveMoreThan2Wep = 0;
		// ������ �� ���� ��� ���� ����� ������
		for(int i=0 ; i<vehicleWappensNum.length; i++){
			if (vehicleWappensNum[i] == 0) {//�� ���� ������ ���� �� ���� ���
				while ( f<vehicleWappensNum.length) {//���� ��� ��� �� ����� 2 ����� �� ���
					if(vehicleWappensNum[f] > 2) {
						haveMoreThan2Wep=f;
						flag=true;// ���� F �� 2 ����� �����
					}
					else f++;
				}
			}
			for(int k=0 ; k<vehicles.get(f).team.size(); k++){//����� ���� �� �� ����� ���� F
				if(flag=true && !vehicles.get(f).team.get(k).getcanDrive() ) {// ����� ��� ��� 2 ����� �� ��� ���� �� ���� ���� �� ������ ������ ���� ���� �� ����� ����
					vehicles.get(i).getTeam().add(vehicles.get(f).team.get(k));
					vehicles.get(f).getTeam().remove(k);
				}
			}
		}

		
		this.ops.add(op);// ����� ���� ������� �������
		return true;	
	}
}