using System;
using System.ComponentModel;

namespace Group14
{
    public enum VolunteerRole
    {
        General,
        Driver
    }
}
