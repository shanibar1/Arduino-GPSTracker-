﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class VolunteerSignIn : Form
    {
        public VolunteerSignIn()
        {
            InitializeComponent();
        }

        private void textBox_VolunteerLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_VolunteerId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button_VolunteerSignIn_Click(object sender, EventArgs e)
        {
            if (checkDetails(textBox_VolunteerId.Text, textBox_VolunteerFirstName.Text, textBox_VolunteerLastName.Text))
            {
                //VolunteerManage vm = new VolunteerManage(textBox_VolunteerId.Text);
                //vm.Show();
                this.Hide();
            }
        }

        private void button_ReturnToVolunteerCrud_Click(object sender, EventArgs e)
        {
            VolunteerCRUD vc = new VolunteerCRUD();
            vc.Show();
            this.Hide();
        }
        private bool checkDetails(string volunteerId, string volunteerFirstName, string volunteerLastName)
        {
            bool correct = false;
            foreach (Volunteer v in Program.Volunteers)
            {
                bool id = v.get_volunteerId().Equals(volunteerId);
                bool firstName = v.get_volunteerFirstName().Equals(volunteerFirstName);
                bool lastName = v.get_volunteerLastName().Equals(volunteerLastName);
                if (id && firstName && lastName)
                    correct = true;
            }
            if (correct)
                return true;
            else
            {
                MessageBox.Show("פרטי התחברות לא תקינים");
                return false;
            }
        }

    }
}
