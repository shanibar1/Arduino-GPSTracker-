//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;

//namespace Group14
//{
//    public class DonatedFamilyRepresentative
//    {
//        private string id;
//        private string address;
//        private string firstName;
//        private string lastName;
//        private bool isActive;
//        private List<Package> Packages; // relevant packages for family

//        public DonatedFamilyRepresentative(string id, string address, string firstName, string lastName, bool isActive, bool is_new)
//        {
//            this.id = id;
//            this.address = address;
//            this.firstName = firstName;
//            this.lastName = lastName;
//            this.isActive = isActive;
//            if (is_new)
//            {
//                this.CreateDonatedFamilyRepresentative();
//                Program.DonatedFamilyRepresentatives.Add(this);
//            }
//        }

//        public void CreateDonatedFamilyRepresentative()
//        {
//            SqlCommand c = new SqlCommand();
//            c.CommandText = "EXECUTE SP_Create_Representative @representativeId, @Address_Locations, @firstName, @lastName, @isActive";
//            c.Parameters.AddWithValue("@representativeId", this.id);
//            c.Parameters.AddWithValue("@Address_Locations", this.address);
//            c.Parameters.AddWithValue("@firstName", this.firstName);
//            c.Parameters.AddWithValue("@lastName", this.lastName);
//            c.Parameters.AddWithValue("@isActive", this.isActive);
//            SQL_CON SC = new SQL_CON();
//            SC.execute_non_query(c);
//        }

//        public void GiveFeedback(Package p, int rate, string feedback)
//        {
//            Review review = new Review(p.get_packageId(), this.id, DateTime.Now, rate, feedback, true);
//        }

//        public void TrackPackage()
//        {

//        }

//        public void updatePackages()
//        {
//            this.Packages = new List<Package>();
//            foreach(Package p in Program.Packages)
//            {
//                bool correctAddress = p.get_address().Equals(this.address);
//                bool date = p.get ;
//                bool firstReview = noReview(p);
//                if (correctAddress && date && firstReview)
//                    this.Packages.Add(p);
//            }
//        }

//        private bool noReview(Package p)
//        {
//            foreach(Review r in Program.Reviews)
//            {
//                if (r.get_packageId().Equals(p.get_packageId()))
//                    return false;
//            }
//            return true;
//        }

//        public string get_id()
//        {
//            return this.id;
//        }

//        public void set_id(string id)
//        {
//            this.id = id;
//        }

//        public string get_address()
//        {
//            return this.address;
//        }

//        public void set_address(string address)
//        {
//            this.address = address;
//        }

//        public string get_firstName()
//        {
//            return this.firstName;
//        }

//        public void set_firstName(string firstName)
//        {
//            this.firstName = firstName;
//        }

//        public string get_lastName()
//        {
//            return this.lastName;
//        }

//        public void set_lastName(string lastName)
//        {
//            this.lastName = lastName;
//        }

//        public bool get_isActive()
//        {
//            return this.isActive;
//        }

//        public void set_isActive(bool isActive)
//        {
//            this.isActive = isActive;
//        }

//        public List<Package> GetPackages()
//        {
//            return this.Packages;
//        }

//    }
//}