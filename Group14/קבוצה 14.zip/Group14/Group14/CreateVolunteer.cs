﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class CreateVolunteer : Form
    {
        public CreateVolunteer()
        {
            InitializeComponent();
            comboBox_VolunteerRole.DataSource = Enum.GetValues(typeof(VolunteerRole));
            checkBox_DrivingLicence.Enabled = false;
            setLabelsError();
            makeLabelsErrorInvisible();
        }

        private void button_AddNewVolunteer_Click(object sender, EventArgs e)
        {
            bool driver = comboBox_VolunteerRole.Text.Equals("Driver") && checkBox_DrivingLicence.Checked && checkInput();
            bool other = !comboBox_VolunteerRole.Text.Equals("Driver") && checkInput();
            if (driver || other)
            {
                button_AddNewVolunteer.BackColor = Color.Green;
                Employee emp = new Employee(textBox_VolunteerId.Text, textBox_VolunteerFirstName.Text, textBox_VolunteerLastName.Text, textBox_VolunteerMail.Text, textBox_VolunteerPhoneNumber.Text, (EmployeeRole)Enum.Parse(typeof(EmployeeRole), comboBox_VolunteerRole.Text), true, true);//יצירת עובד חדש

                EmployeeCRUD ec = new EmployeeCRUD();
                ec.Show();
                this.Close();
                // זה אומר שגם סומן שהוא נהג וגם סומן שיש לו רישיון
            }
            else
            {
                button_AddNewVolunteer.BackColor = Color.Red;
            }
        }
    
        private void button_ReturnToVolunteerCRUD_Click(object sender, EventArgs e)
        {
            VolunteerCRUD vc = new VolunteerCRUD();
            vc.Show();
            this.Hide();
        }

        private bool checkInput()
        {
            bool properIdText = !textBox_VolunteerId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_VolunteerId.TextLength == 9);
            bool emptyId = textBox_VolunteerId.Text == "";

            // checking first name value
            bool properFirstNameText = !textBox_VolunteerFirstName.Text.All(char.IsLetter);
            bool emptyFirstName = textBox_VolunteerFirstName.Text == "";

            // checking last name value
            bool properLastNameText = !textBox_VolunteerLastName.Text.All(char.IsLetter);
            bool emptyLastName = textBox_VolunteerLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_VolunteerMail.Text.Contains('@') || textBox_VolunteerMail.Text.Contains('.'));
            bool properMailLength = !(textBox_VolunteerMail.TextLength >= 5);
            bool emptyMail = textBox_VolunteerMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_VolunteerPhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_VolunteerPhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_VolunteerPhoneNumber.Text == "";


            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerId.Visible = true;
            }
            else
            {
                if (Program.seekEmployee(textBox_VolunteerId.Text) != null)
                {
                    label_ErrorVolunteerId.Text = "תעודת הזהות כבר קיימת במערכת";
                }
                else
                {
                    label_ErrorVolunteerId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerFirstName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerLastName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorVolunteerMail.Visible = true;
            }
            else
            {
                label_ErrorVolunteerMail.Visible = false;
            }
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerPhone.Visible = true;
            }
            else
            {
                label_ErrorVolunteerPhone.Visible = false;
            }

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }



        private void comboBox_VolunteerRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox_VolunteerRole.Text.Equals("Driver"))
            {
                checkBox_DrivingLicence.Enabled = true;
            }
        }

        
        private void setLabelsError()
        {
            label_ErrorVolunteerId.Text = "";
            label_ErrorVolunteerFirstName.Text = "";
            label_ErrorVolunteerLastName.Text = "";
            label_ErrorVolunteerMail.Text = "";
            label_ErrorVolunteerPhone.Text = "";
        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorVolunteerId.Visible = false;
            label_ErrorVolunteerFirstName.Visible = false;
            label_ErrorVolunteerLastName.Visible = false;
            label_ErrorVolunteerMail.Visible = false;
            label_ErrorVolunteerPhone.Visible = false;
        }


       

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox_VolunteerId_TextChanged(object sender, EventArgs e)
        {

        }

        private void CreateVolunteer_Load(object sender, EventArgs e)
        {

        }
    }
}
