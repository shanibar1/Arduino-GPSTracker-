﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class UpdateDeleteEmployee : Form
    {
        private Employee exist_Employee;

        public UpdateDeleteEmployee()
        {
            InitializeComponent();
            //comboBox_EmployeeRole.DataSource = Enum.GetValues(typeof(EmployeeRole));
            string[] enumElements = Enum.GetNames(typeof(EmployeeRole));
            foreach(string item in enumElements)
            {
                comboBox_EmployeeRole.Items.Add(item.Replace("_", " "));
            }
            textBox_EmployeeFirstName.Enabled = false;
            textBox_EmployeeLastName.Enabled = false;
            textBox_EmployeeMail.Enabled = false;
            textBox_EmployeePhoneNumber.Enabled = false;
            comboBox_EmployeeRole.Enabled = false;
            makeLabelsErrorInvisible();
            button_DeleteEmployee.Hide();
            button_UpdateEmployee.Hide();
        }

        private void button_UpdateEmployee_Click(object sender, EventArgs e)
        {
            checkInput();
            makeLabelsErrorInvisible();
            exist_Employee.set_employeeFirstName(textBox_EmployeeFirstName.Text);
            exist_Employee.set_employeeLastName(textBox_EmployeeLastName.Text);
            exist_Employee.set_employeeMail(textBox_EmployeeMail.Text);
            exist_Employee.set_employeePhone(textBox_EmployeePhoneNumber.Text);
            EmployeeRole er = (EmployeeRole)comboBox_EmployeeRole.SelectedIndex;
            exist_Employee.set_employeeRole(er);
            //exist_Employee.set_employeeRole((EmployeeRole)Enum.Parse(typeof(EmployeeRole), comboBox_EmployeeRole.Text));
            exist_Employee.UpdateEmployee();

            EmployeeCRUD ecrud = new EmployeeCRUD();
            ecrud.Show();
            this.Close();
        }

        private void button_DeleteEmployee_Click(object sender, EventArgs e)
        {
            checkInput();
            makeLabelsErrorInvisible();
            exist_Employee.Delete_Employee();

            EmployeeCRUD ecrud = new EmployeeCRUD();
            ecrud.Show();
            this.Close();
        }

        private void button_ReturnToEmployeeCRUD_Click(object sender, EventArgs e)
        {
            EmployeeCRUD ec = new EmployeeCRUD();
            ec.Show();
            this.Hide();
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            if (checkIdInput())
            {
                makeLabelsErrorInvisible();
                if (textBox_EmployeeId != null)
                {
                    label_ErrorEmployeeId.Visible = false;
                    //הצגת הכפתורים
                    button_DeleteEmployee.Show();
                    button_UpdateEmployee.Show();
                    //איתור המופע המתאים והצגת הפרטים
                    exist_Employee = Program.seekEmployee(textBox_EmployeeId.Text);
                    textBox_EmployeeId.Enabled = false;
                    textBox_EmployeeFirstName.Enabled = true;
                    textBox_EmployeeLastName.Enabled = true;
                    textBox_EmployeeMail.Enabled = true;
                    textBox_EmployeePhoneNumber.Enabled = true;
                    comboBox_EmployeeRole.Enabled = true;
                    textBox_EmployeeFirstName.Text = exist_Employee.get_employeeFirstName();
                    textBox_EmployeeLastName.Text = exist_Employee.get_employeeLastName();
                    textBox_EmployeeMail.Text = exist_Employee.get_employeeMail();
                    textBox_EmployeePhoneNumber.Text = exist_Employee.get_employeePhone();
                    comboBox_EmployeeRole.DataSource = Enum.GetValues(typeof(EmployeeRole));
                    comboBox_EmployeeRole.Text = exist_Employee.get_employeeRole().ToString();
                }
            }
        }

        private bool checkIdInput()
        {
            bool properIdText = textBox_EmployeeId.Text.All(char.IsDigit);
            bool properIdLength = textBox_EmployeeId.TextLength == 9;
            bool emptyId = textBox_EmployeeId.Text == "";
            if (emptyId || !properIdText || !properIdLength)
            {
                MessageBox.Show("קלט לא תקין");
                if (emptyId)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס ערך";
                }
                else if (!properIdText)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (!properIdLength)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorEmployeeId.Visible = true;
                return false;
            }
            else
            {
                if (Program.seekEmployee(textBox_EmployeeId.Text) == null)
                {
                    label_ErrorEmployeeId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorEmployeeId.Visible = true;
                    return false;
                }
                else
                {
                    label_ErrorEmployeeId.Visible = false;
                    return true;
                }
            }
        }

        private bool checkInput()
        {
            label_ErrorEmployeeId.Visible = false;

            // checking first name value
            bool properFirstNameText = textBox_EmployeeFirstName.Text.All(char.IsNumber);
            bool emptyFirstName = textBox_EmployeeFirstName.Text == "";

            // checking last name value
            bool properLastNameText = textBox_EmployeeLastName.Text.All(char.IsNumber);
            bool emptyLastName = textBox_EmployeeLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_EmployeeMail.Text.Contains('@') || textBox_EmployeeMail.Text.Contains('.'));
            bool properMailLength = !(textBox_EmployeeMail.TextLength >= 5);
            bool emptyMail = textBox_EmployeeMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_EmployeePhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_EmployeePhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_EmployeePhoneNumber.Text == "";


            //print error message
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorEmployeeFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorEmployeeFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorEmployeeFirstName.Visible = true;
            }
            else
            {
                label_ErrorEmployeeFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorEmployeeLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorEmployeeLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorEmployeeLastName.Visible = true;
            }
            else
            {
                label_ErrorEmployeeLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorEmployeeMail.Visible = true;
            }
            else
            {
                label_ErrorEmployeeMail.Visible = false;
            }
            if (properPhoneText || !properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorEmployeePhone.Visible = true;
            }
            else
            {
                label_ErrorEmployeePhone.Visible = false;
            }

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorEmployeeId.Visible = false;
            label_ErrorEmployeeFirstName.Visible = false;
            label_ErrorEmployeeLastName.Visible = false;
            label_ErrorEmployeeMail.Visible = false;
            label_ErrorEmployeePhone.Visible = false;
        }

        private void UpdateDeleteEmployee_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
