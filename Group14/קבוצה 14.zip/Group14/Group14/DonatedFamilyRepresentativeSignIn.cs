﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class DonatedFamilyRepresentativeSignIn : Form
    {
        public DonatedFamilyRepresentativeSignIn()
        {
            InitializeComponent();
        }
        private void button_ReturnToHomePage_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }

        private void button_DonatedFamilySignIn_Click(object sender, EventArgs e)
        {
            if (checkDetails(textBox_DonatedFamilyId.Text, textBox_DonatedFamilyName.Text))
            {
                DonatedFamilyRepresentativeManage dfrm = new DonatedFamilyRepresentativeManage(textBox_DonatedFamilyId.Text, textBox_DonatedFamilyName.Text);
                dfrm.ShowDialog();
            }

        }

        private bool checkDetails(string donatedFamilyId, string donatedFamilyName) // NEED TO FILL!!!!!!!!!!!!!!
        {
            MessageBox.Show("פרטי התחברות לא תקינים");
            return false;
        }
    }
}
