using System;
using System.Data.SqlClient;

namespace Group14
{
    public class FoodItem {
        private string itemId;
        private string itemName;
        private int unitsInStock;
        private DateTime expiredDate; // PAY ATTENTION - DATE!!!
        private bool isInStock;

        public FoodItem(string itemId, string itemName, int unitsInStock, DateTime expiredDate, bool isInStock)
        {
            this.itemId = itemId;
            this.itemName = itemName;
            this.unitsInStock = unitsInStock;
            this.expiredDate = expiredDate;
            this.isInStock = isInStock;
        }

        public FoodItem(string id)
        {
            foreach (FoodItem i in Program.FoodItems)
            {
                if (i.itemId.Equals(id))
                {
                    this.itemId = i.GetItemId();
                    this.itemName = i.GetItemName();
                    this.unitsInStock = i.GetUnitsInStock();
                    this.expiredDate = i.GetExpiredDate();
                    this.isInStock = i.GetIsInStock();
                    break;
                }
            }
        }

        public void CreateFoodItem()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_FoodItem @foodId, @Name, @UnitsInStock, @ExpiredDate, @IsInStock";
            c.Parameters.AddWithValue("@foodId", this.itemId);
            c.Parameters.AddWithValue("@Name", this.itemName);
            c.Parameters.AddWithValue("@UnitsInStock", this.unitsInStock);
            c.Parameters.AddWithValue("@ExpiredDate", this.expiredDate);
            c.Parameters.AddWithValue("@IsInStock", this.isInStock);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void UpdateFoodItem()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.UpdateFoodItem @foodId, @Name, @UnitsInStock, @ExpiredDate, @IsInStock";
            c.Parameters.AddWithValue("@foodId", this.itemId);
            c.Parameters.AddWithValue("@Name", this.itemName);
            c.Parameters.AddWithValue("@UnitsInStock", this.unitsInStock);
            c.Parameters.AddWithValue("@ExpiredDate", this.expiredDate);
            c.Parameters.AddWithValue("@IsInStock", this.isInStock);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void DeleteFoodItem()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.DeleteFoodItem @foodId";
            c.Parameters.AddWithValue("@foodId", this.itemId);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void AddItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void ReadItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void UpdateItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void ArchiveItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public string GetItemId()
        {
            return this.itemId;
        }

        public void SetItemId(string itemId)
        {
            this.itemId = itemId;
        }

        public string GetItemName()
        {
            return this.itemName;
        }

        public void SetItemName(string itemName)
        {
            this.itemName = itemName;
        }

        public int GetUnitsInStock()
        {
            return this.unitsInStock;
        }

        public void SetUnitsInStock(int unitsInStock)
        {
            this.unitsInStock = unitsInStock;
        }

        public DateTime GetExpiredDate()
        {
            return this.expiredDate;
        }

        public void SetExpiredDate(DateTime expiredDate)
        {
            this.expiredDate = expiredDate;
        }

        public bool GetIsInStock()
        {
            return this.isInStock;
        }

        public void SetIsInStock(bool isInStock)
        {
            this.isInStock = isInStock;
        }
    }
}