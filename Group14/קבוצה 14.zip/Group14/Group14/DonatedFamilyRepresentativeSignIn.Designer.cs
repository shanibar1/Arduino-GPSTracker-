﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeSignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_DonatedFamilyId = new System.Windows.Forms.TextBox();
            this.textBox_DonatedFamilyName = new System.Windows.Forms.TextBox();
            this.button_DonatedFamilySignIn = new System.Windows.Forms.Button();
            this.button_ReturnToHomePage = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(296, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "התחברות משפחה נתרמת";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(276, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = ":ת.ז נציג המשפחה";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(259, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = ":שם המשפחה הנתרמת";
            // 
            // textBox_DonatedFamilyId
            // 
            this.textBox_DonatedFamilyId.Location = new System.Drawing.Point(108, 88);
            this.textBox_DonatedFamilyId.Name = "textBox_DonatedFamilyId";
            this.textBox_DonatedFamilyId.Size = new System.Drawing.Size(100, 20);
            this.textBox_DonatedFamilyId.TabIndex = 3;
            // 
            // textBox_DonatedFamilyName
            // 
            this.textBox_DonatedFamilyName.Location = new System.Drawing.Point(108, 148);
            this.textBox_DonatedFamilyName.Name = "textBox_DonatedFamilyName";
            this.textBox_DonatedFamilyName.Size = new System.Drawing.Size(100, 20);
            this.textBox_DonatedFamilyName.TabIndex = 4;
            // 
            // button_DonatedFamilySignIn
            // 
            this.button_DonatedFamilySignIn.Location = new System.Drawing.Point(242, 212);
            this.button_DonatedFamilySignIn.Name = "button_DonatedFamilySignIn";
            this.button_DonatedFamilySignIn.Size = new System.Drawing.Size(75, 23);
            this.button_DonatedFamilySignIn.TabIndex = 5;
            this.button_DonatedFamilySignIn.Text = "התחבר";
            this.button_DonatedFamilySignIn.UseVisualStyleBackColor = true;
            this.button_DonatedFamilySignIn.Click += new System.EventHandler(this.button_DonatedFamilySignIn_Click);
            // 
            // button_ReturnToHomePage
            // 
            this.button_ReturnToHomePage.Location = new System.Drawing.Point(50, 212);
            this.button_ReturnToHomePage.Name = "button_ReturnToHomePage";
            this.button_ReturnToHomePage.Size = new System.Drawing.Size(75, 23);
            this.button_ReturnToHomePage.TabIndex = 6;
            this.button_ReturnToHomePage.Text = "חזור";
            this.button_ReturnToHomePage.UseVisualStyleBackColor = true;
            this.button_ReturnToHomePage.Click += new System.EventHandler(this.button_ReturnToHomePage_Click);
            // 
            // DonatedFamilyRepresentativeSignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 258);
            this.Controls.Add(this.button_ReturnToHomePage);
            this.Controls.Add(this.button_DonatedFamilySignIn);
            this.Controls.Add(this.textBox_DonatedFamilyName);
            this.Controls.Add(this.textBox_DonatedFamilyId);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "DonatedFamilyRepresentativeSignIn";
            this.Text = "מסך התחברות משפחה נתרמת";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_DonatedFamilyId;
        private System.Windows.Forms.TextBox textBox_DonatedFamilyName;
        private System.Windows.Forms.Button button_DonatedFamilySignIn;
        private System.Windows.Forms.Button button_ReturnToHomePage;
    }
}