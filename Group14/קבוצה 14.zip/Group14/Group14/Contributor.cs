using System;

namespace Group14
{
public class Contributor {
    private string contributorName;
    private string contributorID;
    private string contributorMail;
    private string contributorPhone;

    public void AddDonation() {
        throw new System.NotImplementedException("Not implemented");
    }
    public void ShowLastDonations() {
        throw new System.NotImplementedException("Not implemented");
    }
    public Contributor() {
        throw new System.NotImplementedException("Not implemented");
    }


    }
}