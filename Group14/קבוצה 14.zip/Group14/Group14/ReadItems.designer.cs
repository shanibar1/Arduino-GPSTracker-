﻿//namespace Group14
//{
//    partial class ReadItems
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            this.components = new System.ComponentModel.Container();
//            this.dataGridView2 = new System.Windows.Forms.DataGridView();
//            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
//            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
//            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
//            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
//            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
//            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
//            this.sAD14DataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
//            this.sAD_14DataSet1 = new Group14.SAD_14DataSet();
//            this.foodItemsTableAdapter1 = new Group14.SAD_14DataSetTableAdapters.FoodItemsTableAdapter();
//            this.textBox_searchFoodItem = new System.Windows.Forms.TextBox();
//            this.label3 = new System.Windows.Forms.Label();
//            this.label4 = new System.Windows.Forms.Label();
//            this.comboBox_SearchFromFoodList = new System.Windows.Forms.ComboBox();
//            this.bindingSource2 = new System.Windows.Forms.BindingSource(this.components);
//            this.bindingSource3 = new System.Windows.Forms.BindingSource(this.components);
//            this.label5 = new System.Windows.Forms.Label();
//            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
//            this.buttonReturnToItemCrud = new System.Windows.Forms.Button();
//            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.sAD14DataSet1BindingSource)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.sAD_14DataSet1)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).BeginInit();
//            this.SuspendLayout();
//            // 
//            // dataGridView2
//            // 
//            this.dataGridView2.AllowUserToAddRows = false;
//            this.dataGridView2.AllowUserToDeleteRows = false;
//            this.dataGridView2.AutoGenerateColumns = false;
//            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
//            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
//            this.dataGridViewTextBoxColumn1,
//            this.dataGridViewTextBoxColumn2,
//            this.dataGridViewTextBoxColumn3,
//            this.dataGridViewTextBoxColumn4,
//            this.dataGridViewCheckBoxColumn1});
//            this.dataGridView2.DataSource = this.bindingSource1;
//            this.dataGridView2.Location = new System.Drawing.Point(33, 236);
//            this.dataGridView2.Name = "dataGridView2";
//            this.dataGridView2.ReadOnly = true;
//            this.dataGridView2.Size = new System.Drawing.Size(541, 162);
//            this.dataGridView2.TabIndex = 0;
//            // 
//            // dataGridViewTextBoxColumn1
//            // 
//            this.dataGridViewTextBoxColumn1.DataPropertyName = "foodId";
//            this.dataGridViewTextBoxColumn1.HeaderText = "foodId";
//            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
//            this.dataGridViewTextBoxColumn1.ReadOnly = true;
//            // 
//            // dataGridViewTextBoxColumn2
//            // 
//            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
//            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
//            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
//            this.dataGridViewTextBoxColumn2.ReadOnly = true;
//            // 
//            // dataGridViewTextBoxColumn3
//            // 
//            this.dataGridViewTextBoxColumn3.DataPropertyName = "UnitsInStock";
//            this.dataGridViewTextBoxColumn3.HeaderText = "UnitsInStock";
//            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
//            this.dataGridViewTextBoxColumn3.ReadOnly = true;
//            // 
//            // dataGridViewTextBoxColumn4
//            // 
//            this.dataGridViewTextBoxColumn4.DataPropertyName = "ExpiredDate";
//            this.dataGridViewTextBoxColumn4.HeaderText = "ExpiredDate";
//            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
//            this.dataGridViewTextBoxColumn4.ReadOnly = true;
//            // 
//            // dataGridViewCheckBoxColumn1
//            // 
//            this.dataGridViewCheckBoxColumn1.DataPropertyName = "IsInStock";
//            this.dataGridViewCheckBoxColumn1.HeaderText = "IsInStock";
//            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
//            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
//            // 
//            // bindingSource1
//            // 
//            this.bindingSource1.DataMember = "FoodItems";
//            this.bindingSource1.DataSource = this.sAD14DataSet1BindingSource;
//            // 
//            // sAD14DataSet1BindingSource
//            // 
//            this.sAD14DataSet1BindingSource.DataSource = this.sAD_14DataSet1;
//            this.sAD14DataSet1BindingSource.Position = 0;
//            this.sAD14DataSet1BindingSource.CurrentChanged += new System.EventHandler(this.sAD14DataSet1BindingSource_CurrentChanged);
//            // 
//            // sAD_14DataSet1
//            // 
//            this.sAD_14DataSet1.DataSetName = "SAD_14DataSet";
//            this.sAD_14DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
//            // 
//            // foodItemsTableAdapter1
//            // 
//            this.foodItemsTableAdapter1.ClearBeforeFill = true;
//            // 
//            // textBox_searchFoodItem
//            // 
//            this.textBox_searchFoodItem.Location = new System.Drawing.Point(277, 182);
//            this.textBox_searchFoodItem.Multiline = true;
//            this.textBox_searchFoodItem.Name = "textBox_searchFoodItem";
//            this.textBox_searchFoodItem.Size = new System.Drawing.Size(207, 20);
//            this.textBox_searchFoodItem.TabIndex = 1;
//            this.textBox_searchFoodItem.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
//            // 
//            // label3
//            // 
//            this.label3.AutoSize = true;
//            this.label3.Location = new System.Drawing.Point(515, 182);
//            this.label3.Name = "label3";
//            this.label3.Size = new System.Drawing.Size(56, 13);
//            this.label3.TabIndex = 2;
//            this.label3.Text = "סינון לפי";
//            this.label3.Click += new System.EventHandler(this.label3_Click);
//            // 
//            // label4
//            // 
//            this.label4.AutoSize = true;
//            this.label4.Location = new System.Drawing.Point(501, 114);
//            this.label4.Name = "label4";
//            this.label4.Size = new System.Drawing.Size(70, 13);
//            this.label4.TabIndex = 3;
//            this.label4.Text = "סינון חיפוש";
//            // 
//            // comboBox_SearchFromFoodList
//            // 
//            this.comboBox_SearchFromFoodList.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bindingSource2, "foodId", true));
//            this.comboBox_SearchFromFoodList.FormattingEnabled = true;
//            this.comboBox_SearchFromFoodList.Location = new System.Drawing.Point(363, 111);
//            this.comboBox_SearchFromFoodList.Name = "comboBox_SearchFromFoodList";
//            this.comboBox_SearchFromFoodList.Size = new System.Drawing.Size(121, 21);
//            this.comboBox_SearchFromFoodList.TabIndex = 4;
//            // 
//            // bindingSource2
//            // 
//            this.bindingSource2.DataMember = "FoodItems";
//            this.bindingSource2.DataSource = this.sAD14DataSet1BindingSource;
//            // 
//            // bindingSource3
//            // 
//            this.bindingSource3.DataMember = "FoodItems";
//            this.bindingSource3.DataSource = this.sAD14DataSet1BindingSource;
//            // 
//            // label5
//            // 
//            this.label5.AutoSize = true;
//            this.label5.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
//            this.label5.Location = new System.Drawing.Point(22, 26);
//            this.label5.Name = "label5";
//            this.label5.Size = new System.Drawing.Size(593, 63);
//            this.label5.TabIndex = 5;
//            this.label5.Text = "צפיה ברשימת הפריטים";
//            // 
//            // buttonReturnToItemCrud
//            // 
//            this.buttonReturnToItemCrud.Location = new System.Drawing.Point(12, 463);
//            this.buttonReturnToItemCrud.Name = "buttonReturnToItemCrud";
//            this.buttonReturnToItemCrud.Size = new System.Drawing.Size(75, 23);
//            this.buttonReturnToItemCrud.TabIndex = 6;
//            this.buttonReturnToItemCrud.Text = "חזור";
//            this.buttonReturnToItemCrud.UseVisualStyleBackColor = true;
//            this.buttonReturnToItemCrud.Click += new System.EventHandler(this.buttonReturnToItemCrud_Click);
//            // 
//            // readItems
//            // 
//            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
//            this.ClientSize = new System.Drawing.Size(765, 498);
//            this.Controls.Add(this.buttonReturnToItemCrud);
//            this.Controls.Add(this.label5);
//            this.Controls.Add(this.comboBox_SearchFromFoodList);
//            this.Controls.Add(this.label4);
//            this.Controls.Add(this.label3);
//            this.Controls.Add(this.textBox_searchFoodItem);
//            this.Controls.Add(this.dataGridView2);
//            this.Name = "ReadItems";
//            this.Text = "רשימת הפריטים במלאי";
//            this.Load += new System.EventHandler(this.readItems_Load_1);
//            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.sAD14DataSet1BindingSource)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.sAD_14DataSet1)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).EndInit();
//            this.ResumeLayout(false);
//            this.PerformLayout();

//        }

//        #endregion

//        private System.Windows.Forms.ComboBox comboBox_SearchFromList;
//        private System.Windows.Forms.Label label1;
//        private System.Windows.Forms.DataGridView dataGridView1;
//        private System.Windows.Forms.TextBox textBox_searchByName;
//        private System.Windows.Forms.Label label2;
//        private System.Windows.Forms.BindingSource sAD14DataSetBindingSource;
//        private SAD_14DataSet sAD_14DataSet;
//        private System.Windows.Forms.BindingSource foodItemsBindingSource;
//        private SAD_14DataSetTableAdapters.FoodItemsTableAdapter foodItemsTableAdapter;
//        private System.Windows.Forms.DataGridViewTextBoxColumn foodIdDataGridViewTextBoxColumn;
//        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
//        private System.Windows.Forms.DataGridViewTextBoxColumn unitsInStockDataGridViewTextBoxColumn;
//        private System.Windows.Forms.DataGridViewTextBoxColumn expiredDateDataGridViewTextBoxColumn;
//        private System.Windows.Forms.DataGridViewCheckBoxColumn isInStockDataGridViewCheckBoxColumn;
//        private System.Windows.Forms.DataGridView dataGridView2;
//        private System.Windows.Forms.BindingSource sAD14DataSet1BindingSource;
//        private SAD_14DataSet sAD_14DataSet1;
//        private System.Windows.Forms.BindingSource bindingSource1;
//        private SAD_14DataSetTableAdapters.FoodItemsTableAdapter foodItemsTableAdapter1;
//        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
//        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
//        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
//        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
//        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
//        private System.Windows.Forms.TextBox textBox_searchFoodItem;
//        private System.Windows.Forms.Label label3;
//        private System.Windows.Forms.Label label4;
//        private System.Windows.Forms.ComboBox comboBox_SearchFromFoodList;
//        private System.Windows.Forms.BindingSource bindingSource2;
//        private System.Windows.Forms.BindingSource bindingSource3;
//        private System.Windows.Forms.Label label5;
//        private System.ComponentModel.BackgroundWorker backgroundWorker1;
//        private System.Windows.Forms.Button buttonReturnToItemCrud;
//    }
//}