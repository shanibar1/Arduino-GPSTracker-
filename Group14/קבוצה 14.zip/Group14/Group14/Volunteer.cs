//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;

//namespace Group14
//{
//    public class Volunteer
//    {
//        private string volunteerId;
//        private string volunteerFirstName;
//        private string volunteerLastName;
//        private string volunteerMail;
//        private string volunteerPhone;
//        private VolunteerRole volunteerRole;
//        private bool volunteerDrivingLicence;
//        private bool isVolunteerActive;
//        private List<Event> past;
//        private List<Event> future;


//        //****************************************************
//        //public static int driverLocationX;
//        //public static int driverLocationY;
//        private int driverLocationX;
//        private int driverLocationY;
//        private int deliveryLocationX;
//        private int deliveryLocationY;
//        //****************************************************


//        public Volunteer(string volunteerId, string volunteerFirstName, string volunteerLastName, string volunteerMail, string volunteerPhone, bool VolunteerDrivingLicence, VolunteerRole volunteerRole, bool isVolunteerActive, bool is_new)
//        {
//            this.volunteerId = volunteerId;
//            this.volunteerFirstName = volunteerFirstName;
//            this.volunteerLastName = volunteerLastName;
//            this.volunteerMail = volunteerMail;
//            this.volunteerPhone = volunteerPhone;
//            this.volunteerRole = volunteerRole;
//            // Only driver needs a licence
//            if (this.volunteerRole.Equals("driver"))
//                this.volunteerDrivingLicence = true;
//            else
//                this.volunteerDrivingLicence = false;

//            this.isVolunteerActive = isVolunteerActive;
//            if (is_new)
//            {
//                this.CreateVolunteer();
//                Program.Volunteers.Add(this);
//            }
//        }

     
//        public void CreateVolunteer()
//        {
//            SqlCommand c = new SqlCommand();
//            c.CommandText = "EXECUTE SP_Create_Volunteer @volunteerId, @firstName, @lastName, @Email, @Phone, @drivingLiscence, @Type, @IsActive";
//            c.Parameters.AddWithValue("@volunteerId", this.volunteerId);
//            c.Parameters.AddWithValue("@firstName", this.volunteerFirstName);
//            c.Parameters.AddWithValue("@lastName", this.volunteerLastName);
//            c.Parameters.AddWithValue("@Email", this.volunteerMail);
//            c.Parameters.AddWithValue("@Phone", this.volunteerPhone);
//            c.Parameters.AddWithValue("@drivingLiscence", this.volunteerDrivingLicence.ToString());
//            c.Parameters.AddWithValue("@Type", this.volunteerRole.ToString());
//            c.Parameters.AddWithValue("@IsActive", this.isVolunteerActive);
//            SQL_CON SC = new SQL_CON();
//            SC.execute_non_query(c);
//        }

//        internal void UpdateVolunteer()
//        {
//            SqlCommand c = new SqlCommand();
//            c.CommandText = "EXECUTE dbo.UpdateVolunteer @Id, @firstName, @lastName, @Email, @Phone, @Role, @isActive";
//            c.Parameters.AddWithValue("@Id", this.volunteerId);
//            c.Parameters.AddWithValue("@firstName", this.volunteerFirstName);
//            c.Parameters.AddWithValue("@lastName", this.volunteerLastName);
//            c.Parameters.AddWithValue("@Email", this.volunteerMail);
//            c.Parameters.AddWithValue("@Phone", this.volunteerPhone);
//            c.Parameters.AddWithValue("@Role", this.volunteerRole.ToString());
//            c.Parameters.AddWithValue("@isActive", this.isVolunteerActive);
//            SQL_CON SC = new SQL_CON();
//            SC.execute_non_query(c);
//        }

//        // *********************************************************************************************************
//        //getting family's address to drive to
//        private void DonatedFamilyAddress(string address)
//        {
//            Location l = new Location();
//            foreach(DonatedFamilyRepresentative df in Program.DonatedFamilyRepresentatives)
//            {
//                if(df.get_address().Equals(address))
//                {
//                    this.deliveryLocationX = l.getXByAddress(address);
//                    this.deliveryLocationY = l.getYByAddress(address);
//                    break;
//                }
//            }
//        }

//        public int get_X()
//        {
//            return this.driverLocationX;
//        }

//        public int get_Y()
//        {
//            return this.driverLocationY;
//        }

//        public void Drive(int speed)
//        {
//            this.driverLocationX = this.go_East(speed) + this.go_West(speed);
//            this.driverLocationY = this.go_North(speed) + this.go_South(speed);
//        }

//        private int go_North(int speed)
//        {
//            if(this.driverLocationY < this.deliveryLocationY)
//            {
//                return this.driverLocationY + speed;
//            }
//            return 0;
//        }

//        private int go_South(int speed)
//        {
//            if (this.driverLocationY > this.deliveryLocationY)
//            {
//                return this.driverLocationY - speed;
//            }
//            return 0;
//        }

//        private int go_East(int speed)
//        {
//            if (this.driverLocationX > this.deliveryLocationX)
//            {
//                return this.driverLocationX - speed;
//            }
//            return 0;
//        }

//        private int go_West(int speed)
//        {
//            if (this.driverLocationX < this.deliveryLocationX)
//            {
//                return this.driverLocationX + speed;
//            }
//            return 0;
//        }

//        // *********************************************************************************************************

//        private void fillEventLists()
//        {
//            foreach (Event e in Program.Events)
//            {
//                if (e.isRegistered(this))
//                {
//                    if (e.GetDate() < DateTime.Now.Date)
//                        this.past.Add(e);
//                    else
//                        this.future.Add(e);
//                }
//            }
//        }

//        public void ParticipateInDistribution()
//        {
//            throw new System.NotImplementedException("Not implemented");
//        }
//        public void AssistInFoodPackaging()
//        {
//            throw new System.NotImplementedException("Not implemented");
//        }
//        public void RequestAssistance()
//        {
//            throw new System.NotImplementedException("Not implemented");
//        }
//        public void GetRoute()
//        {
//            throw new System.NotImplementedException("Not implemented");
//        }
//        public bool UpdatePackageStatus()
//        {
//            throw new System.NotImplementedException("Not implemented");
//        }
//        public Volunteer()
//        {
//            throw new System.NotImplementedException("Not implemented");
//        }

//        public string get_volunteerId()
//        {
//            return this.volunteerId;
//        }
//        public void set_volunteerId(string volunteerId)
//        {
//            this.volunteerId = volunteerId;
//        }

//        public string get_volunteerFirstName()
//        {
//            return this.volunteerFirstName;
//        }
//        public void set_volunteerFirstName(string volunteerFirstName)
//        {
//            this.volunteerFirstName = volunteerFirstName;
//        }

//        public string get_volunteerLastName()
//        {
//            return this.volunteerLastName;
//        }
//        public void set_volunteerLastName(string volunteerLastName)
//        {
//            this.volunteerLastName = volunteerLastName;
//        }

//        public string get_volunteerMail()
//        {
//            return this.volunteerMail;
//        }
//        public void set_volunteerMail(string volunteerMail)
//        {
//            this.volunteerMail = volunteerMail;
//        }

//        public string get_volunteerPhone()
//        {
//            return this.volunteerPhone;
//        }
//        public void set_volunteerPhone(string volunteerPhone)
//        {
//            this.volunteerPhone = volunteerPhone;
//        }

//        public bool get_drivingLicense()
//        {
//            return this.volunteerDrivingLicence;
//        }
//        public void set_drivingLicense(bool drivingLicense)
//        {
//            this.volunteerDrivingLicence = drivingLicense;
//        }

//        public VolunteerRole get_volunteerRole()
//        {
//            return this.volunteerRole;
//        }
//        public void set_volunteerRole(VolunteerRole volunteerRole)
//        {
//            this.volunteerRole = volunteerRole;
//        }

//        public bool get_isVolunteerActive()
//        {
//            return this.isVolunteerActive;
//        }
//        public void set_isVolunteerActive(bool isVolunteerActive)
//        {
//            this.isVolunteerActive = isVolunteerActive;
//        }

//    }
//}