﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class DonatedFamilyRepresentativeManage : Form
    {
        private DonatedFamilyRepresentative df;
        public DonatedFamilyRepresentativeManage(string familyId, string familyName)
        {
            InitializeComponent();
            foreach (DonatedFamilyRepresentative d in Program.DonatedFamilyRepresentatives)
            {
                if (d.get_id().Equals(familyId))
                {
                    this.df = d;
                    break;
                }
            }
            this.labelFamily.Text = "שלום למשפחת " + familyName + "!";
        }

        private void button_GiveFeedback_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeGiveFeedback gf = new DonatedFamilyRepresentativeGiveFeedback(this.df);
            gf.Show();
            this.Hide();
        }

        private void button_BackToHomePage_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }

        private void button_TrackPackage_Click(object sender, EventArgs e)
        {
            /*this.df.updatePackages();
            Package package;
            foreach (Package p in this.df.GetPackages())
            {
                if()
            }
            if ()
            {
                df = new DonatedFamilyRepresentativeTrackPackage(this.df, package);
                df.Show();
                this.Hide();
            }
            else
            {
                df = new DonatedFamilyRepresentativeTrackPackage(this.df, null);
                df.Show();
                this.Hide();
            }*/
        }
    }
}
