﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeGiveFeedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_ReturnToSignIn = new System.Windows.Forms.Button();
            this.button_GiveFeedback = new System.Windows.Forms.Button();
            this.textBox_Feedback = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxStars = new System.Windows.Forms.ComboBox();
            this.comboBox_Package = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_ReturnToSignIn
            // 
            this.button_ReturnToSignIn.Location = new System.Drawing.Point(67, 392);
            this.button_ReturnToSignIn.Name = "button_ReturnToSignIn";
            this.button_ReturnToSignIn.Size = new System.Drawing.Size(75, 23);
            this.button_ReturnToSignIn.TabIndex = 0;
            this.button_ReturnToSignIn.Text = "חזור";
            this.button_ReturnToSignIn.UseVisualStyleBackColor = true;
            this.button_ReturnToSignIn.Click += new System.EventHandler(this.button_ReturnToSignIn_Click);
            // 
            // button_GiveFeedback
            // 
            this.button_GiveFeedback.Location = new System.Drawing.Point(238, 392);
            this.button_GiveFeedback.Name = "button_GiveFeedback";
            this.button_GiveFeedback.Size = new System.Drawing.Size(75, 23);
            this.button_GiveFeedback.TabIndex = 2;
            this.button_GiveFeedback.Text = "שלח משוב";
            this.button_GiveFeedback.UseVisualStyleBackColor = true;
            this.button_GiveFeedback.Click += new System.EventHandler(this.button_GiveFeedback_Click);
            // 
            // textBox_Feedback
            // 
            this.textBox_Feedback.Location = new System.Drawing.Point(36, 128);
            this.textBox_Feedback.Multiline = true;
            this.textBox_Feedback.Name = "textBox_Feedback";
            this.textBox_Feedback.Size = new System.Drawing.Size(312, 219);
            this.textBox_Feedback.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(392, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = ":מלא משוב";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(419, 83);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = ":דרג";
            // 
            // comboBoxStars
            // 
            this.comboBoxStars.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStars.FormattingEnabled = true;
            this.comboBoxStars.Location = new System.Drawing.Point(256, 80);
            this.comboBoxStars.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxStars.Name = "comboBoxStars";
            this.comboBoxStars.Size = new System.Drawing.Size(92, 21);
            this.comboBoxStars.TabIndex = 6;
            // 
            // comboBox_Package
            // 
            this.comboBox_Package.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Package.FormattingEnabled = true;
            this.comboBox_Package.Location = new System.Drawing.Point(256, 33);
            this.comboBox_Package.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox_Package.Name = "comboBox_Package";
            this.comboBox_Package.Size = new System.Drawing.Size(92, 21);
            this.comboBox_Package.TabIndex = 7;
            this.comboBox_Package.SelectedIndexChanged += new System.EventHandler(this.comboBox_Package_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(388, 36);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = ":בחר חבילה";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(206, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "לשנות לתאריך ולא id";
            // 
            // DonatedFamilyRepresentativeGiveFeedback
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 443);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox_Package);
            this.Controls.Add(this.comboBoxStars);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_Feedback);
            this.Controls.Add(this.button_GiveFeedback);
            this.Controls.Add(this.button_ReturnToSignIn);
            this.Name = "DonatedFamilyRepresentativeGiveFeedback";
            this.Text = "מילוי משוב";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_ReturnToSignIn;
        private System.Windows.Forms.Button button_GiveFeedback;
        private System.Windows.Forms.TextBox textBox_Feedback;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxStars;
        private System.Windows.Forms.ComboBox comboBox_Package;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}