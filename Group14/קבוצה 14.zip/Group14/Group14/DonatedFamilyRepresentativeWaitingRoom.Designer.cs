﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeWaitingRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxWaiting = new System.Windows.Forms.PictureBox();
            this.labelWaiting = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWaiting)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxWaiting
            // 
            this.pictureBoxWaiting.Image = global::Group14.Properties.Resources.Spinner_1s_200px;
            this.pictureBoxWaiting.Location = new System.Drawing.Point(292, 209);
            this.pictureBoxWaiting.Name = "pictureBoxWaiting";
            this.pictureBoxWaiting.Size = new System.Drawing.Size(210, 209);
            this.pictureBoxWaiting.TabIndex = 0;
            this.pictureBoxWaiting.TabStop = false;
            // 
            // labelWaiting
            // 
            this.labelWaiting.AutoSize = true;
            this.labelWaiting.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.labelWaiting.ForeColor = System.Drawing.Color.Teal;
            this.labelWaiting.Location = new System.Drawing.Point(276, 109);
            this.labelWaiting.Name = "labelWaiting";
            this.labelWaiting.Size = new System.Drawing.Size(254, 33);
            this.labelWaiting.TabIndex = 1;
            this.labelWaiting.Text = "המתן למציאת חבילה";
            // 
            // DonatedFamilyRepresentativeWaitingRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelWaiting);
            this.Controls.Add(this.pictureBoxWaiting);
            this.Name = "DonatedFamilyRepresentativeWaitingRoom";
            this.Text = "מסך המתנה";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWaiting)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxWaiting;
        private System.Windows.Forms.Label labelWaiting;
    }
}