using System;

namespace Group14
{

    public class ShoppingItem {
        private int quantity;
        private float price;
        private DateTime lastDate; // PAY ATTENTION - DATE!!!

        public bool AddItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool RemoveItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public ShoppingItem() {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}