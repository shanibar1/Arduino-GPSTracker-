using System;

namespace Group14
{
    public class Vendor
    {
        private string vendorId;
        private string vendorName;
        private string vendorMail;
        private string vendorPhone;

        public void ShowOrdersHistory()
        {
            throw new System.NotImplementedException("Not implemented");
        }
        public void AddFeedback()
        {
            throw new System.NotImplementedException("Not implemented");
        }
        public Vendor()
        {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}
