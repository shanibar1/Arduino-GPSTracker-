using System;

namespace Group14
{

    public class Review {
        private DateTime reviewDate; // PAY ATTENTION - DATE!!!
        private int reviewRate;
        private string reviewWords;

        public bool AddReview() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool RemoveReview() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool EditReview() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Review() {
            throw new System.NotImplementedException("Not implemented");
        }

    }  
}
