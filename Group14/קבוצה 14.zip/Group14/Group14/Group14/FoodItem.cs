using System;

namespace Group14
{
    public class FoodItem {
        private string itemId;
        private string itemName;
        private ItemStatus itemStatus;
        private int unitsInStock;
        private DateTime expiredDate; // PAY ATTENTION - DATE!!!

        public void AddItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void ReadItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void UpdateItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void ArchiveItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public FoodItem() {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}