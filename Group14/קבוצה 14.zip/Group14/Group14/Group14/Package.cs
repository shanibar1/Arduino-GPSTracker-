using System;

namespace Group14
{
    public class Package {
        private string packageId;
        private PackageStatus packageStatus;

        public void ViewItems() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool AddReview() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Package() {
            throw new System.NotImplementedException("Not implemented");
        }


    }
}