﻿using System;
using System.ComponentModel;


namespace Group14
{
    public enum VolunteerDrivingLicence
    {
        [Description("Have")] Have,
        [Description("Doesn't Have")] Doesnt_Have,
    }
}
