using System;

namespace Group14
{
    public class Volunteer {
        private string volunteerId;
        private string volunteerName;
        private string volunteerMail;
        private string volunteerPhone;
        private string drivingLicense;
        private VolunteerRole role;

        public void ParticipateInDistribution() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void AssistInFoodPackaging() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void RequestAssistance() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void GetRoute() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool UpdatePackageStatus() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Volunteer() {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}
