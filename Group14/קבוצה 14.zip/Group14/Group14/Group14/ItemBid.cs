using System;

namespace Group14
{
    public class ItemBid
    {
        private float price;

        public void ComparePricesByVendors()
        {
            throw new System.NotImplementedException("Not implemented");
        }
        public void DisplayComparison()
        {
            throw new System.NotImplementedException("Not implemented");
        }
        public void GetBestPrice()
        {
            throw new System.NotImplementedException("Not implemented");
        }
        public ItemBid()
        {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}