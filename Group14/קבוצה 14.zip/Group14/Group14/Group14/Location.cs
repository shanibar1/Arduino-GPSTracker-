using System;

namespace Group14
{
    public class Location {
        private string address;
        private float latitude;
        private float longitude;

        public double CalculateDistance() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Location NearestAddress() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Location() {
            throw new System.NotImplementedException("Not implemented");
        }


    }
}