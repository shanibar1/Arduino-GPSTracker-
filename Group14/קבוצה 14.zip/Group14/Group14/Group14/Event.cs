using System;

namespace Group14
{
    public class Event {
        private string eventId;
        private DateTime eventDate; // PAY ATTENTION - DATE!!!
        private DateTime startTime;
        private DateTime endTime;
        private string eventName;

        public void CreateEvent() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void UpdateEvent() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void CancelEvent() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void SendMessages() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Event() {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}