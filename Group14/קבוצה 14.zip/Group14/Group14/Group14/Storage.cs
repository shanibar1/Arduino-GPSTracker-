using System;

namespace Group14
{

    public class Storage {
        private string storageId;
        private StorageType storageType;

        public void SearchFoodItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool AddFoodItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool RemoveFoodItem() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Storage() {
            throw new System.NotImplementedException("Not implemented");
        }


    }
}
