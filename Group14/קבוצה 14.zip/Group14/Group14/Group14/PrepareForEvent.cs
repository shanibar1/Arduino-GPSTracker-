using System;

namespace Group14
{

    public class PrepareForEvent {
        private int requiredDrivers;
        private int requiredCollectors;
        private int requiredFoodDistributors;
        private int requiredPackers;

        public int CalculateRequiredDrivers() {
            throw new System.NotImplementedException("Not implemented");
        }
        public int CalculateRequiredCollectors() {
            throw new System.NotImplementedException("Not implemented");
        }
        public int CalculateRequiredFoodDistributors() {
            throw new System.NotImplementedException("Not implemented");
        }
        public int CalculateRequiredPackers() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void CaculateQuantityrequiredForEvent() {
            throw new System.NotImplementedException("Not implemented");
        }
        public PrepareForEvent() {
            throw new System.NotImplementedException("Not implemented");
        }
    }
}