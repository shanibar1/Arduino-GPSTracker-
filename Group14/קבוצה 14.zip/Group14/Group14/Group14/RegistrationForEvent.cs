using System;

namespace Group14
{

    public class RegistrationForEvent {
        private bool registeredVolunteer;

        public bool RegisterVolunteer() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool UnregisterVolunteer() {
            throw new System.NotImplementedException("Not implemented");
        }
        public RegistrationForEvent() {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}