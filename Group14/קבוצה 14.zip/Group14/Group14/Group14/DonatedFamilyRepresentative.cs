using System;

namespace Group14
{
public class DonatedFamilyRepresentative {
    private string familyId;
    private string familyName;

    public void GiveFeedback() {
        throw new System.NotImplementedException("Not implemented");
    }
    public void TrackPackage() {
        throw new System.NotImplementedException("Not implemented");
    }
    public DonatedFamilyRepresentative() {
        throw new System.NotImplementedException("Not implemented");
    }

    }
}