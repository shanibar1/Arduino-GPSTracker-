﻿namespace Group14
{
    partial class ItemCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label1;
            this.button_AddNewItem = new System.Windows.Forms.Button();
            this.button_ReadItem = new System.Windows.Forms.Button();
            this.ReturnTo = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_AddNewItem
            // 
            this.button_AddNewItem.Location = new System.Drawing.Point(426, 218);
            this.button_AddNewItem.Name = "button_AddNewItem";
            this.button_AddNewItem.Size = new System.Drawing.Size(114, 23);
            this.button_AddNewItem.TabIndex = 0;
            this.button_AddNewItem.Text = "הוסף מוצר חדש";
            this.button_AddNewItem.UseVisualStyleBackColor = true;
            this.button_AddNewItem.Click += new System.EventHandler(this.button_AddNewItem_Click);
            // 
            // button_ReadItem
            // 
            this.button_ReadItem.Location = new System.Drawing.Point(397, 283);
            this.button_ReadItem.Name = "button_ReadItem";
            this.button_ReadItem.Size = new System.Drawing.Size(143, 23);
            this.button_ReadItem.TabIndex = 1;
            this.button_ReadItem.Text = "צפייה ברשימת מוצרים";
            this.button_ReadItem.UseVisualStyleBackColor = true;
            this.button_ReadItem.Click += new System.EventHandler(this.button_ReadItem_Click);
            // 
            // ReturnTo
            // 
            this.ReturnTo.Location = new System.Drawing.Point(28, 559);
            this.ReturnTo.Name = "ReturnTo";
            this.ReturnTo.Size = new System.Drawing.Size(75, 23);
            this.ReturnTo.TabIndex = 2;
            this.ReturnTo.Text = "חזור";
            this.ReturnTo.UseVisualStyleBackColor = true;
            this.ReturnTo.Click += new System.EventHandler(this.ReturnTo_Click);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            label1.Location = new System.Drawing.Point(145, 64);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(287, 63);
            label1.TabIndex = 3;
            label1.Text = "ניהול מלאי";
            // 
            // ItemCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 614);
            this.Controls.Add(label1);
            this.Controls.Add(this.ReturnTo);
            this.Controls.Add(this.button_ReadItem);
            this.Controls.Add(this.button_AddNewItem);
            this.Name = "ItemCRUD";
            this.Text = "ניהול מלאי";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_AddNewItem;
        private System.Windows.Forms.Button button_ReadItem;
        private System.Windows.Forms.Button ReturnTo;
    }
}