﻿namespace Group14
{
    partial class VendorPrice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lb_vendor_name = new System.Windows.Forms.Label();
            this.item_name = new System.Windows.Forms.Label();
            this.vendor_name = new System.Windows.Forms.TextBox();
            this.lb_email = new System.Windows.Forms.Label();
            this.vendor_email = new System.Windows.Forms.TextBox();
            this.lb_phone = new System.Windows.Forms.Label();
            this.vendor_phone = new System.Windows.Forms.TextBox();
            this.lb_price = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.TextBox();
            this.lb_amount = new System.Windows.Forms.Label();
            this.amount_numeric = new System.Windows.Forms.NumericUpDown();
            this.buttonAddToCart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.amount_numeric)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(314, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vendor\'s quote for ";
            // 
            // lb_vendor_name
            // 
            this.lb_vendor_name.AutoSize = true;
            this.lb_vendor_name.Location = new System.Drawing.Point(195, 111);
            this.lb_vendor_name.Name = "lb_vendor_name";
            this.lb_vendor_name.Size = new System.Drawing.Size(93, 17);
            this.lb_vendor_name.TabIndex = 1;
            this.lb_vendor_name.Text = "Vendor name";
            // 
            // item_name
            // 
            this.item_name.AutoSize = true;
            this.item_name.Location = new System.Drawing.Point(449, 62);
            this.item_name.Name = "item_name";
            this.item_name.Size = new System.Drawing.Size(73, 17);
            this.item_name.TabIndex = 2;
            this.item_name.Text = "item name";
            // 
            // vendor_name
            // 
            this.vendor_name.Location = new System.Drawing.Point(317, 108);
            this.vendor_name.Name = "vendor_name";
            this.vendor_name.Size = new System.Drawing.Size(249, 22);
            this.vendor_name.TabIndex = 3;
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.Location = new System.Drawing.Point(195, 155);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(42, 17);
            this.lb_email.TabIndex = 4;
            this.lb_email.Text = "Email";
            // 
            // vendor_email
            // 
            this.vendor_email.Location = new System.Drawing.Point(317, 155);
            this.vendor_email.Name = "vendor_email";
            this.vendor_email.Size = new System.Drawing.Size(249, 22);
            this.vendor_email.TabIndex = 5;
            // 
            // lb_phone
            // 
            this.lb_phone.AutoSize = true;
            this.lb_phone.Location = new System.Drawing.Point(195, 200);
            this.lb_phone.Name = "lb_phone";
            this.lb_phone.Size = new System.Drawing.Size(101, 17);
            this.lb_phone.TabIndex = 6;
            this.lb_phone.Text = "Phone number";
            // 
            // vendor_phone
            // 
            this.vendor_phone.Location = new System.Drawing.Point(317, 200);
            this.vendor_phone.Name = "vendor_phone";
            this.vendor_phone.Size = new System.Drawing.Size(249, 22);
            this.vendor_phone.TabIndex = 7;
            // 
            // lb_price
            // 
            this.lb_price.AutoSize = true;
            this.lb_price.Location = new System.Drawing.Point(195, 244);
            this.lb_price.Name = "lb_price";
            this.lb_price.Size = new System.Drawing.Size(69, 17);
            this.lb_price.TabIndex = 8;
            this.lb_price.Text = "Item price";
            // 
            // price
            // 
            this.price.Location = new System.Drawing.Point(317, 244);
            this.price.Name = "price";
            this.price.Size = new System.Drawing.Size(83, 22);
            this.price.TabIndex = 9;
            // 
            // lb_amount
            // 
            this.lb_amount.AutoSize = true;
            this.lb_amount.Location = new System.Drawing.Point(344, 334);
            this.lb_amount.Name = "lb_amount";
            this.lb_amount.Size = new System.Drawing.Size(56, 17);
            this.lb_amount.TabIndex = 14;
            this.lb_amount.Text = "Amount";
            // 
            // amount_numeric
            // 
            this.amount_numeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.amount_numeric.Location = new System.Drawing.Point(420, 325);
            this.amount_numeric.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.amount_numeric.Name = "amount_numeric";
            this.amount_numeric.Size = new System.Drawing.Size(52, 30);
            this.amount_numeric.TabIndex = 15;
            // 
            // buttonAddToCart
            // 
            this.buttonAddToCart.Location = new System.Drawing.Point(75, 382);
            this.buttonAddToCart.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddToCart.Name = "buttonAddToCart";
            this.buttonAddToCart.Size = new System.Drawing.Size(116, 55);
            this.buttonAddToCart.TabIndex = 21;
            this.buttonAddToCart.Text = "הוסף לעגלת הקניות";
            this.buttonAddToCart.UseVisualStyleBackColor = true;
            // 
            // VendorPrice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonAddToCart);
            this.Controls.Add(this.amount_numeric);
            this.Controls.Add(this.lb_amount);
            this.Controls.Add(this.price);
            this.Controls.Add(this.lb_price);
            this.Controls.Add(this.vendor_phone);
            this.Controls.Add(this.lb_phone);
            this.Controls.Add(this.vendor_email);
            this.Controls.Add(this.lb_email);
            this.Controls.Add(this.vendor_name);
            this.Controls.Add(this.item_name);
            this.Controls.Add(this.lb_vendor_name);
            this.Controls.Add(this.label1);
            this.Name = "VendorPrice";
            this.Text = "VendorPrice";
            ((System.ComponentModel.ISupportInitialize)(this.amount_numeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_vendor_name;
        private System.Windows.Forms.Label item_name;
        private System.Windows.Forms.TextBox vendor_name;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.TextBox vendor_email;
        private System.Windows.Forms.Label lb_phone;
        private System.Windows.Forms.TextBox vendor_phone;
        private System.Windows.Forms.Label lb_price;
        private System.Windows.Forms.TextBox price;
        private System.Windows.Forms.Label lb_amount;
        private System.Windows.Forms.NumericUpDown amount_numeric;
        private System.Windows.Forms.Button buttonAddToCart;
    }
}