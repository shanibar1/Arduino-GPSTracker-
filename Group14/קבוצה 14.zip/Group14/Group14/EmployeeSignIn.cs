﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class EmployeeSignIn : Form
    {
        public EmployeeSignIn()
        {
            InitializeComponent();
        }

        private void button_EmployeeSignIn_Click(object sender, EventArgs e)
        {
            if (checkDetails(textBox_EmployeeId.Text, textBox_EmployeeFirstName.Text, textBox_EmployeeLastName.Text))
            {
                EmployeeManage em = new EmployeeManage(textBox_EmployeeId.Text);
                em.Show();
                this.Hide();
            }
        }

        private void button_ReturnToEmployeeCrud_Click(object sender, EventArgs e)
        {
            EmployeeCRUD ec = new EmployeeCRUD();
            ec.Show();
            this.Hide();
        }

        private bool checkDetails(string employeeId, string employeeFirstName, string employeeLastName)
        {
            bool correct = false;
            foreach (Employee e in Program.Employees)
            {
                bool id = e.get_employeeId().Equals(employeeId);
                bool firstName = e.get_employeeFirstName().Equals(employeeFirstName);
                bool lastName = e.get_employeeLastName().Equals(employeeLastName);
                if (id && firstName && lastName)
                    correct = true;
            }
            if (correct)
                return true;
            else
            {
                MessageBox.Show("פרטי התחברות לא תקינים");
                return false;
            }
        }

        private void textBox_EmployeeLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_EmployeeFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_EmployeeId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}