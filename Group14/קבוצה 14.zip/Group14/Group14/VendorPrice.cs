﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class VendorPrice : Form
    {
        public VendorPrice()
        {
            InitializeComponent();
        }

        private void changed_num_Click(object sender, EventArgs e)
        {
            //this.changed_num = 1;
        }
    }
}
