﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Group14
{
    public partial class DonatedFamilyRepresentativeGiveFeedback : Form
    {
        private DonatedFamilyRepresentative df;
        private Package package;

        public DonatedFamilyRepresentativeGiveFeedback(DonatedFamilyRepresentative df)
        {
            InitializeComponent();
            this.df = df;
            df.updatePackages();
            updatePackageComboBox();
            updateStarsComboBox();
            this.comboBoxStars.Enabled = false;
            this.textBox_Feedback.Enabled = false;
            this.button_GiveFeedback.Enabled = false;
        }

        private void button_ReturnToSignIn_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeManage dfr = new DonatedFamilyRepresentativeManage(this.df.get_id(), this.df.get_lastName());
            dfr.Show();
            this.Hide();
        }

        private void button_GiveFeedback_Click(object sender, EventArgs e)
        {
            if (this.getStarRating() == 0)
                MessageBox.Show("!חובה לתת דירוג בין 1 ל-5");
            else if (textBox_Feedback.Text.Equals(""))
                MessageBox.Show("!חובה לכתוב משוב");
            else
                df.GiveFeedback(package, Int32.Parse(comboBoxStars.Text), textBox_Feedback.Text);
        }

        private void updatePackageComboBox()
        {
            comboBox_Package.Items.Add("");
            foreach (Package p in this.df.GetPackages())
            {
                comboBox_Package.Items.Add(p);
            }
        }

        private void updateStarsComboBox()
        {
            comboBoxStars.Items.Add("");
            for (int i = 1; i <= 5; i++)
                comboBoxStars.Items.Add(i);
        }

        private int getStarRating()
        {
            if (comboBoxStars.SelectedIndex == -1)
                return 0;
            else if (comboBoxStars.SelectedIndex == 1)
                return 1;
            else if (comboBoxStars.SelectedIndex == 2)
                return 2;
            else if (comboBoxStars.SelectedIndex == 3)
                return 3;
            else if (comboBoxStars.SelectedIndex == 4)
                return 4;
            else
                return 5;
        }

        private void comboBox_Package_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_Package.SelectedIndex == -1)
            {
                this.comboBoxStars.Enabled = false;
                this.textBox_Feedback.Enabled = false;
                this.button_GiveFeedback.Enabled = false;
            }
            else
            {
                this.comboBoxStars.Enabled = true;
                this.textBox_Feedback.Enabled = true;
                this.button_GiveFeedback.Enabled = true;
                if (comboBox_Package.SelectedItem is Package selectedPackage)
                    this.package = selectedPackage;
            }
        }
    }
}
