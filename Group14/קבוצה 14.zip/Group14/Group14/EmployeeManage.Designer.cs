﻿namespace Group14
{
    partial class EmployeeManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelName = new System.Windows.Forms.Label();
            this.button_BackToEmployeeCRUD = new System.Windows.Forms.Button();
            this.button_ManageItems = new System.Windows.Forms.Button();
            this.button_ManageEvent = new System.Windows.Forms.Button();
            this.button_ViewReports = new System.Windows.Forms.Button();
            this.button_FillForms = new System.Windows.Forms.Button();
            this.button_OpenEventReport = new System.Windows.Forms.Button();
            this.labelError = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(568, 83);
            this.labelName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(84, 20);
            this.labelName.TabIndex = 0;
            this.labelName.Text = "!שלום עובד";
            this.labelName.Click += new System.EventHandler(this.labelName_Click);
            // 
            // button_BackToEmployeeCRUD
            // 
            this.button_BackToEmployeeCRUD.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_BackToEmployeeCRUD.Location = new System.Drawing.Point(344, 434);
            this.button_BackToEmployeeCRUD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_BackToEmployeeCRUD.Name = "button_BackToEmployeeCRUD";
            this.button_BackToEmployeeCRUD.Size = new System.Drawing.Size(112, 35);
            this.button_BackToEmployeeCRUD.TabIndex = 1;
            this.button_BackToEmployeeCRUD.Text = "חזור";
            this.button_BackToEmployeeCRUD.UseVisualStyleBackColor = true;
            this.button_BackToEmployeeCRUD.Click += new System.EventHandler(this.button_BackToEmployeeCRUD_Click);
            // 
            // button_ManageItems
            // 
            this.button_ManageItems.Location = new System.Drawing.Point(454, 232);
            this.button_ManageItems.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_ManageItems.Name = "button_ManageItems";
            this.button_ManageItems.Size = new System.Drawing.Size(112, 35);
            this.button_ManageItems.TabIndex = 3;
            this.button_ManageItems.Text = "נהל מלאי";
            this.button_ManageItems.UseVisualStyleBackColor = true;
            this.button_ManageItems.Click += new System.EventHandler(this.button_ManageItems_Click);
            // 
            // button_ManageEvent
            // 
            this.button_ManageEvent.Location = new System.Drawing.Point(231, 232);
            this.button_ManageEvent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_ManageEvent.Name = "button_ManageEvent";
            this.button_ManageEvent.Size = new System.Drawing.Size(136, 35);
            this.button_ManageEvent.TabIndex = 4;
            this.button_ManageEvent.Text = "נהל יום אריזה";
            this.button_ManageEvent.UseVisualStyleBackColor = true;
            this.button_ManageEvent.Click += new System.EventHandler(this.button_ManageEvent_Click);
            // 
            // button_ViewReports
            // 
            this.button_ViewReports.Location = new System.Drawing.Point(573, 338);
            this.button_ViewReports.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_ViewReports.Name = "button_ViewReports";
            this.button_ViewReports.Size = new System.Drawing.Size(118, 35);
            this.button_ViewReports.TabIndex = 5;
            this.button_ViewReports.Text = "צפה בדוחות";
            this.button_ViewReports.UseVisualStyleBackColor = true;
            this.button_ViewReports.Click += new System.EventHandler(this.button_ViewReports_Click);
            // 
            // button_FillForms
            // 
            this.button_FillForms.Location = new System.Drawing.Point(344, 338);
            this.button_FillForms.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_FillForms.Name = "button_FillForms";
            this.button_FillForms.Size = new System.Drawing.Size(112, 35);
            this.button_FillForms.TabIndex = 6;
            this.button_FillForms.Text = "מלא טפסים";
            this.button_FillForms.UseVisualStyleBackColor = true;
            this.button_FillForms.Click += new System.EventHandler(this.button_FillForms_Click);
            // 
            // button_OpenEventReport
            // 
            this.button_OpenEventReport.Location = new System.Drawing.Point(114, 338);
            this.button_OpenEventReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_OpenEventReport.Name = "button_OpenEventReport";
            this.button_OpenEventReport.Size = new System.Drawing.Size(146, 35);
            this.button_OpenEventReport.TabIndex = 7;
            this.button_OpenEventReport.Text = "פתח דוח אירוע";
            this.button_OpenEventReport.UseVisualStyleBackColor = true;
            this.button_OpenEventReport.Click += new System.EventHandler(this.button_OpenEventReport_Click);
            // 
            // labelError
            // 
            this.labelError.AutoSize = true;
            this.labelError.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.labelError.ForeColor = System.Drawing.Color.Firebrick;
            this.labelError.Location = new System.Drawing.Point(606, 378);
            this.labelError.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelError.Name = "labelError";
            this.labelError.Size = new System.Drawing.Size(0, 20);
            this.labelError.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(135, 32);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 35);
            this.button1.TabIndex = 9;
            this.button1.Text = "צפה במשובים";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // EmployeeManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 505);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelError);
            this.Controls.Add(this.button_OpenEventReport);
            this.Controls.Add(this.button_FillForms);
            this.Controls.Add(this.button_ViewReports);
            this.Controls.Add(this.button_ManageEvent);
            this.Controls.Add(this.button_ManageItems);
            this.Controls.Add(this.button_BackToEmployeeCRUD);
            this.Controls.Add(this.labelName);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "EmployeeManage";
            this.Text = "EmployeeManage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Button button_BackToEmployeeCRUD;
        private System.Windows.Forms.Button button_ManageItems;
        private System.Windows.Forms.Button button_ManageEvent;
        private System.Windows.Forms.Button button_ViewReports;
        private System.Windows.Forms.Button button_FillForms;
        private System.Windows.Forms.Button button_OpenEventReport;
        private System.Windows.Forms.Label labelError;
        private System.Windows.Forms.Button button1;
    }
}