﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class DonatedFamilyRepresentativeTrackPackage : Form
    {
        private Volunteer driver;
        private DonatedFamilyRepresentative df;
        private Package package;
        private int driverSpeed;
        private int dist;
        private Location l;
        private bool canGoBack;

        public DonatedFamilyRepresentativeTrackPackage(DonatedFamilyRepresentative df, Package package)
        {
            InitializeComponent();
            this.l = new Location();
            this.driverSpeed = 10;
            this.dist = 10;
            this.canGoBack = false;
            this.df = df;
            df.updatePackages();
            this.package = package;
            while (!driveArrived(dist))
            {
                Thread.Sleep(5000);
                this.driver.Drive(this.driverSpeed);
            }
            this.canGoBack = true;
            MessageBox.Show("!החבילה הגיעה ליעד");
        }

        public void drawLocation(int x, int y)
        {
            this.pictureBox_GoogleMaps.Refresh();
            Bitmap map = (Bitmap)this.pictureBox_GoogleMaps.Image;
            Graphics g = Graphics.FromImage(map);
            Pen p = new Pen(Color.Red, 10);
            g.DrawEllipse(p, new Rectangle(x, y, 12, 12));
            this.pictureBox_GoogleMaps.Image = map;
            p.Dispose();
            g.Dispose();
        }

        public void getDriver(Volunteer v)
        {
            this.driver = v;
        }

        private void button_PackageTracking_Click(object sender, EventArgs e)
        {
            this.drawLocation(this.driver.get_X(), this.driver.get_Y());
        }

        private void button_CurrentLocation_Click(object sender, EventArgs e)
        {
            this.drawLocation(this.l.getXByAddress(this.df.get_address()), this.l.getYByAddress(this.df.get_address()));
        }

        private void button_ReturnToSignIn_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeManage dfr = new DonatedFamilyRepresentativeManage(this.df.get_id(), this.df.get_lastName());
            dfr.Show();
            if (this.canGoBack)
                this.Hide();
        }

        private bool driveArrived(int dist)
        {
            int distX = System.Math.Abs(this.l.getXByAddress(this.df.get_address()) - this.driver.get_X());
            int distY = System.Math.Abs(this.l.getYByAddress(this.df.get_address()) - this.driver.get_Y());
            if (distX < dist && distY < dist)
            {
                return true;
            }
            else
            return false;
        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void pictureBox_GoogleMaps_Click(object sender, EventArgs e)
        {

        }
    }
}
