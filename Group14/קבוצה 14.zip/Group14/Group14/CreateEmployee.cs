﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class CreateEmployee : Form
    {
        public CreateEmployee()
        {
            InitializeComponent();
            comboBox_EmployeeRole.DataSource = Enum.GetValues(typeof(EmployeeRole));//אתחול הקומבובוקס
            setLabelsError();
            makeLabelsErrorInvisible();
        }

        private void button_AddNewEmployee_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
            Employee emp = new Employee(textBox_EmployeeId.Text, textBox_EmployeeFirstName.Text, 
                textBox_EmployeeLastName.Text, textBox_EmployeeMail.Text, textBox_EmployeePhoneNumber.Text,
                (EmployeeRole)Enum.Parse(typeof(EmployeeRole), comboBox_EmployeeRole.Text), true, true);//יצירת עובד חדש

            EmployeeCRUD ec = new EmployeeCRUD();
            ec.Show();
            this.Close();
            }
        }

        private void button_ReturnToEmployeeCRUD_Click(object sender, EventArgs e)
        {
            EmployeeCRUD ec = new EmployeeCRUD();
            ec.Show();
            this.Hide();
        }

        private bool checkInput()
        {
            bool properIdText = !textBox_EmployeeId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_EmployeeId.TextLength == 9);
            bool emptyId = textBox_EmployeeId.Text == "";

            // checking first name value
            bool properFirstNameText = textBox_EmployeeFirstName.Text.All(char.IsNumber);
            bool emptyFirstName = textBox_EmployeeFirstName.Text == "";

            // checking last name value
            bool properLastNameText = textBox_EmployeeLastName.Text.All(char.IsNumber);
            bool emptyLastName = textBox_EmployeeLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_EmployeeMail.Text.Contains('@') || textBox_EmployeeMail.Text.Contains('.'));
            bool properMailLength = !(textBox_EmployeeMail.TextLength >= 5);
            bool emptyMail = textBox_EmployeeMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_EmployeePhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_EmployeePhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_EmployeePhoneNumber.Text == "";


            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorEmployeeId.Visible = true;
            }
            else
            {
                if (Program.seekEmployee(textBox_EmployeeId.Text) != null)
                {
                    label_ErrorEmployeeId.Text = "תעודת הזהות כבר קיימת במערכת";
                }
                else
                {
                    label_ErrorEmployeeId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorEmployeeFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorEmployeeFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorEmployeeFirstName.Visible = true;
            }
            else
            {
                label_ErrorEmployeeFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorEmployeeLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorEmployeeLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorEmployeeLastName.Visible = true;
            }
            else
            {
                label_ErrorEmployeeLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorEmployeeMail.Visible = true;
            }
            else
            {
                label_ErrorEmployeeMail.Visible = false;
            }
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorEmployeePhone.Visible = true;
            }
            else
            {
                label_ErrorEmployeePhone.Visible = false;
            }

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }

        private void setLabelsError()
        {
            label_ErrorEmployeeId.Text = "";
            label_ErrorEmployeeFirstName.Text = "";
            label_ErrorEmployeeLastName.Text = "";
            label_ErrorEmployeeMail.Text = "";
            label_ErrorEmployeePhone.Text = "";
        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorEmployeeId.Visible = false;
            label_ErrorEmployeeFirstName.Visible = false;
            label_ErrorEmployeeLastName.Visible = false;
            label_ErrorEmployeeMail.Visible = false;
            label_ErrorEmployeePhone.Visible = false;
        }

        private void CreateEmployee_Load(object sender, EventArgs e)
        {

        }
    }
}
