﻿namespace Group14
{
    partial class CreateVolunteer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_VolunteerId = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerFirstName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerLastName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerMail = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerPhoneNumber = new System.Windows.Forms.TextBox();
            this.comboBox_VolunteerRole = new System.Windows.Forms.ComboBox();
            this.labelDrivingLicence = new System.Windows.Forms.Label();
            this.checkBox_DrivingLicence = new System.Windows.Forms.CheckBox();
            this.button_AddNewVolunteer = new System.Windows.Forms.Button();
            this.button_ReturnToVolunteerCRUD = new System.Windows.Forms.Button();
            this.label_ErrorVolunteerId = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerFirstName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerLastName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerMail = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerPhone = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(346, 14);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(942, 95);
            this.label2.TabIndex = 1;
            this.label2.Text = ":מלא את הפרטים הבאים";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(1210, 525);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "מייל";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(1161, 302);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = ":שם פרטי";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label4.Location = new System.Drawing.Point(1138, 408);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = ":שם משפחה";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(1134, 163);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = ":תעודת זהות";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label6.Location = new System.Drawing.Point(1144, 629);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "מספר טלפון";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label7.Location = new System.Drawing.Point(1192, 728);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 24);
            this.label7.TabIndex = 8;
            this.label7.Text = "תפקיד";
            // 
            // textBox_VolunteerId
            // 
            this.textBox_VolunteerId.Location = new System.Drawing.Point(939, 163);
            this.textBox_VolunteerId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerId.Name = "textBox_VolunteerId";
            this.textBox_VolunteerId.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerId.TabIndex = 9;
            this.textBox_VolunteerId.TextChanged += new System.EventHandler(this.textBox_VolunteerId_TextChanged);
            // 
            // textBox_VolunteerFirstName
            // 
            this.textBox_VolunteerFirstName.Location = new System.Drawing.Point(939, 295);
            this.textBox_VolunteerFirstName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerFirstName.Name = "textBox_VolunteerFirstName";
            this.textBox_VolunteerFirstName.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerFirstName.TabIndex = 10;
            // 
            // textBox_VolunteerLastName
            // 
            this.textBox_VolunteerLastName.Location = new System.Drawing.Point(939, 402);
            this.textBox_VolunteerLastName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerLastName.Name = "textBox_VolunteerLastName";
            this.textBox_VolunteerLastName.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerLastName.TabIndex = 11;
            // 
            // textBox_VolunteerMail
            // 
            this.textBox_VolunteerMail.Location = new System.Drawing.Point(939, 518);
            this.textBox_VolunteerMail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerMail.Name = "textBox_VolunteerMail";
            this.textBox_VolunteerMail.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerMail.TabIndex = 12;
            // 
            // textBox_VolunteerPhoneNumber
            // 
            this.textBox_VolunteerPhoneNumber.Location = new System.Drawing.Point(939, 623);
            this.textBox_VolunteerPhoneNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerPhoneNumber.Name = "textBox_VolunteerPhoneNumber";
            this.textBox_VolunteerPhoneNumber.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerPhoneNumber.TabIndex = 13;
            // 
            // comboBox_VolunteerRole
            // 
            this.comboBox_VolunteerRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_VolunteerRole.FormattingEnabled = true;
            this.comboBox_VolunteerRole.Location = new System.Drawing.Point(908, 720);
            this.comboBox_VolunteerRole.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox_VolunteerRole.Name = "comboBox_VolunteerRole";
            this.comboBox_VolunteerRole.Size = new System.Drawing.Size(180, 28);
            this.comboBox_VolunteerRole.TabIndex = 14;
            this.comboBox_VolunteerRole.SelectedIndexChanged += new System.EventHandler(this.comboBox_VolunteerRole_SelectedIndexChanged);
            // 
            // labelDrivingLicence
            // 
            this.labelDrivingLicence.AutoSize = true;
            this.labelDrivingLicence.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.labelDrivingLicence.Location = new System.Drawing.Point(1098, 823);
            this.labelDrivingLicence.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDrivingLicence.Name = "labelDrivingLicence";
            this.labelDrivingLicence.Size = new System.Drawing.Size(188, 24);
            this.labelDrivingLicence.TabIndex = 15;
            this.labelDrivingLicence.Text = ":רישיון נהיגה בתוקף";
            // 
            // checkBox_DrivingLicence
            // 
            this.checkBox_DrivingLicence.AutoSize = true;
            this.checkBox_DrivingLicence.Location = new System.Drawing.Point(1066, 823);
            this.checkBox_DrivingLicence.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.checkBox_DrivingLicence.Name = "checkBox_DrivingLicence";
            this.checkBox_DrivingLicence.Size = new System.Drawing.Size(22, 21);
            this.checkBox_DrivingLicence.TabIndex = 16;
            this.checkBox_DrivingLicence.UseVisualStyleBackColor = true;
            // 
            // button_AddNewVolunteer
            // 
            this.button_AddNewVolunteer.Location = new System.Drawing.Point(436, 809);
            this.button_AddNewVolunteer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_AddNewVolunteer.Name = "button_AddNewVolunteer";
            this.button_AddNewVolunteer.Size = new System.Drawing.Size(112, 35);
            this.button_AddNewVolunteer.TabIndex = 17;
            this.button_AddNewVolunteer.Text = "צור מתנדב";
            this.button_AddNewVolunteer.UseVisualStyleBackColor = true;
            this.button_AddNewVolunteer.Click += new System.EventHandler(this.button_AddNewVolunteer_Click);
            // 
            // button_ReturnToVolunteerCRUD
            // 
            this.button_ReturnToVolunteerCRUD.Location = new System.Drawing.Point(64, 809);
            this.button_ReturnToVolunteerCRUD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_ReturnToVolunteerCRUD.Name = "button_ReturnToVolunteerCRUD";
            this.button_ReturnToVolunteerCRUD.Size = new System.Drawing.Size(112, 35);
            this.button_ReturnToVolunteerCRUD.TabIndex = 18;
            this.button_ReturnToVolunteerCRUD.Text = "חזור";
            this.button_ReturnToVolunteerCRUD.UseVisualStyleBackColor = true;
            this.button_ReturnToVolunteerCRUD.Click += new System.EventHandler(this.button_ReturnToVolunteerCRUD_Click);
            // 
            // label_ErrorVolunteerId
            // 
            this.label_ErrorVolunteerId.AutoSize = true;
            this.label_ErrorVolunteerId.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerId.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerId.Location = new System.Drawing.Point(644, 163);
            this.label_ErrorVolunteerId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerId.Name = "label_ErrorVolunteerId";
            this.label_ErrorVolunteerId.Size = new System.Drawing.Size(130, 24);
            this.label_ErrorVolunteerId.TabIndex = 19;
            this.label_ErrorVolunteerId.Text = "קלט ת.ז שגוי";
            // 
            // label_ErrorVolunteerFirstName
            // 
            this.label_ErrorVolunteerFirstName.AutoSize = true;
            this.label_ErrorVolunteerFirstName.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerFirstName.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerFirstName.Location = new System.Drawing.Point(648, 282);
            this.label_ErrorVolunteerFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerFirstName.Name = "label_ErrorVolunteerFirstName";
            this.label_ErrorVolunteerFirstName.Size = new System.Drawing.Size(184, 24);
            this.label_ErrorVolunteerFirstName.TabIndex = 20;
            this.label_ErrorVolunteerFirstName.Text = "קלט שם פרטי שגוי";
            this.label_ErrorVolunteerFirstName.Click += new System.EventHandler(this.label9_Click);
            // 
            // label_ErrorVolunteerLastName
            // 
            this.label_ErrorVolunteerLastName.AutoSize = true;
            this.label_ErrorVolunteerLastName.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerLastName.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerLastName.Location = new System.Drawing.Point(648, 402);
            this.label_ErrorVolunteerLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerLastName.Name = "label_ErrorVolunteerLastName";
            this.label_ErrorVolunteerLastName.Size = new System.Drawing.Size(208, 24);
            this.label_ErrorVolunteerLastName.TabIndex = 21;
            this.label_ErrorVolunteerLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorVolunteerMail
            // 
            this.label_ErrorVolunteerMail.AutoSize = true;
            this.label_ErrorVolunteerMail.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerMail.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerMail.Location = new System.Drawing.Point(648, 518);
            this.label_ErrorVolunteerMail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerMail.Name = "label_ErrorVolunteerMail";
            this.label_ErrorVolunteerMail.Size = new System.Drawing.Size(142, 24);
            this.label_ErrorVolunteerMail.TabIndex = 22;
            this.label_ErrorVolunteerMail.Text = "קלט מייל שגוי";
            // 
            // label_ErrorVolunteerPhone
            // 
            this.label_ErrorVolunteerPhone.AutoSize = true;
            this.label_ErrorVolunteerPhone.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerPhone.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerPhone.Location = new System.Drawing.Point(648, 623);
            this.label_ErrorVolunteerPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerPhone.Name = "label_ErrorVolunteerPhone";
            this.label_ErrorVolunteerPhone.Size = new System.Drawing.Size(142, 24);
            this.label_ErrorVolunteerPhone.TabIndex = 23;
            this.label_ErrorVolunteerPhone.Text = "קלט מייל שגוי";
            // 
            // CreateVolunteer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1304, 920);
            this.Controls.Add(this.label_ErrorVolunteerPhone);
            this.Controls.Add(this.label_ErrorVolunteerMail);
            this.Controls.Add(this.label_ErrorVolunteerLastName);
            this.Controls.Add(this.label_ErrorVolunteerFirstName);
            this.Controls.Add(this.label_ErrorVolunteerId);
            this.Controls.Add(this.button_ReturnToVolunteerCRUD);
            this.Controls.Add(this.button_AddNewVolunteer);
            this.Controls.Add(this.checkBox_DrivingLicence);
            this.Controls.Add(this.labelDrivingLicence);
            this.Controls.Add(this.comboBox_VolunteerRole);
            this.Controls.Add(this.textBox_VolunteerPhoneNumber);
            this.Controls.Add(this.textBox_VolunteerMail);
            this.Controls.Add(this.textBox_VolunteerLastName);
            this.Controls.Add(this.textBox_VolunteerFirstName);
            this.Controls.Add(this.textBox_VolunteerId);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "CreateVolunteer";
            this.Text = "יצירת מתנדב חדש";
            this.Load += new System.EventHandler(this.CreateVolunteer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_VolunteerId;
        private System.Windows.Forms.TextBox textBox_VolunteerFirstName;
        private System.Windows.Forms.TextBox textBox_VolunteerLastName;
        private System.Windows.Forms.TextBox textBox_VolunteerMail;
        private System.Windows.Forms.TextBox textBox_VolunteerPhoneNumber;
        private System.Windows.Forms.ComboBox comboBox_VolunteerRole;
        private System.Windows.Forms.Label labelDrivingLicence;
        private System.Windows.Forms.CheckBox checkBox_DrivingLicence;
        private System.Windows.Forms.Button button_AddNewVolunteer;
        private System.Windows.Forms.Button button_ReturnToVolunteerCRUD;
        private System.Windows.Forms.Label label_ErrorVolunteerId;
        private System.Windows.Forms.Label label_ErrorVolunteerFirstName;
        private System.Windows.Forms.Label label_ErrorVolunteerLastName;
        private System.Windows.Forms.Label label_ErrorVolunteerMail;
        private System.Windows.Forms.Label label_ErrorVolunteerPhone;
    }
}