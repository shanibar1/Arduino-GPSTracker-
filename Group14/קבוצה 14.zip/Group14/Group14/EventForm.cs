﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;
 

//namespace Group14
//{
//    public partial class EventForm : Form
//    {
//        private Event new_Event;
//        private Employee employee;
//        private DateTime date;
//        private RegistrationForEvent registration;
       
//        public EventForm(Employee e, DateTime date)
//        {
//            InitializeComponent();
//            this.employee = e;
//            this.date = date;
//            fillComboBoxStartTime();
//            new_Event = new Event();
//        }

//        private void textBox2_TextChanged(object sender, EventArgs e)
//        {

//        }

//        private void label2_Click(object sender, EventArgs e)
//        {

//        }

//        private void EventForm_Load(object sender, EventArgs e)
//        {
//            textBox_Date.Text =  UserControlDays.static_day  +"/"+ EventHomePage.static_month + "/" + EventHomePage.static_year ;
//        }

//        private void button_Save_Click(object sender, EventArgs e)
//        {
//            new_Event = new Event(new_Event.CreateEventId(), employee.get_employeeId(), this.textBox_Address.Text, this.textBox_Event.Text, this.date, startTime(), endTime(), EventStatus.preperation, true);
//            new_Event.CreateEventId();
//            new_Event.SetAddress(textBox_Address.Text);
//            new_Event.SetName(textBox_Event.Text);
            
//            //exist_Event.SetDate(textBox_Date.);
//            //exist_Event.SetStartTime(textBox_Start_Time.Text);
//            MessageBox.Show("Saved");
            
//        }

//        private void label3_Click(object sender, EventArgs e)
//        {

//        }

//        private void pictureBox1_Click(object sender, EventArgs e)
//        {

//        }

//        private void label5_Click(object sender, EventArgs e)
//        {

//        }

//        private void textBox1_TextChanged(object sender, EventArgs e)
//        {

//        }

//        private void button1_Click(object sender, EventArgs e)
//        {
//            WhatsApp WA = new WhatsApp();
//            WA.Show();
//            this.Close();
//        }

//        private void fillComboBoxStartTime()
//        {
//            for(int i = 10; i <= 19; i++)
//            {
//                string display = i + ":00";
//                this.comboBox_StartTime.Items.Add(display);
//            }
//        }

//        private DateTime startTime()
//        {
//            int hour = Int32.Parse(this.comboBox_StartTime.SelectedText.Substring(0, 2));
//            return new DateTime(this.date.Year, this.date.Month, this.date.Day, hour, 0, 0);
//        }
//        private DateTime endTime()
//        {
//            int hour = 7 / (1.09 ^ getVolunteersAmount());
//            return new DateTime(this.date.Year, this.date.Month, this.date.Day, hour, 0, 0);
//        }

//    }
//}
