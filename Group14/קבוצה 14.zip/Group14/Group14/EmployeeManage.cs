﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class EmployeeManage : Form
    {
        private Employee employee;

        public EmployeeManage(string id)
        {
            InitializeComponent();
            foreach (Employee e in Program.Employees)
            {
                if (e.get_employeeId().Equals(id))
                {
                    this.employee = e;
                    break;
                }
            }
            this.labelName.Text = "!" + "שלום" + " " + this.employee.get_employeeFirstName();
            setButtons();
            this.labelError.Visible = false;
        }

        private void setButtons()
        {
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
                this.button_ManageItems.Location = new Point(300, 150);
                this.button_ManageEvent.Location = new Point(150, 150);
                this.button_ViewReports.Location = new Point(385, 200);
                this.button_FillForms.Location = new Point(230, 200);
                this.button_OpenEventReport.Location = new Point(80, 200);
            }
            else if (employee.get_employeeRole().ToString().Equals("DeputyCEO"))
            {
                this.button_ViewReports.Visible = false;
                this.button_FillForms.Visible = false;
                this.button_OpenEventReport.Visible = false;
                this.button_ManageItems.Location = new Point(300, 175);
                this.button_ManageEvent.Location = new Point(150, 175);
            }
            else if (employee.get_employeeRole().ToString().Equals("Accountant"))
            {
                this.button_ManageItems.Visible = false;
                this.button_ManageEvent.Visible = false;
                this.button_OpenEventReport.Visible = false;
                this.button_ViewReports.Location = new Point(320, 175);
                this.button_FillForms.Location = new Point(135, 175);
            }
            else // Lawyer
            {
                this.button_ManageItems.Visible = false;
                this.button_ManageEvent.Visible = false;
                this.button_ViewReports.Visible = false;
                this.button_FillForms.Visible = false;
                this.button_OpenEventReport.Location = new Point(230, 175);
            }
        }

        private void button_BackToEmployeeCRUD_Click(object sender, EventArgs e)
        {
            EmployeeCRUD ec = new EmployeeCRUD();
            ec.Show();
            this.Hide();
        }

        private void button_ManageItems_Click(object sender, EventArgs e)
        {
            /*ItemCRUD ic = new ItemCRUD();
            ic.Show();
            this.Hide();*/
        }

        private void button_ManageEvent_Click(object sender, EventArgs e)
        {
            EventHomePage evh = new EventHomePage();
            evh.Show();
            this.Hide();
        }

        private void button_ViewReports_Click(object sender, EventArgs e)
        {
            this.labelError.Text = "כפתור לא מוביל לשום מקום";
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
                this.labelError.Visible = true;
                this.labelError.Location = new Point(380, 250);
            }
            else if (employee.get_employeeRole().ToString().Equals("Accountant"))
            {
                this.labelError.Visible = true;
                this.labelError.Location = new Point(320, 250);
            }
        }

        private void button_FillForms_Click(object sender, EventArgs e)
        {
            this.labelError.Text = "כפתור לא מוביל לשום מקום";
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
                this.labelError.Visible = true;
                this.labelError.Location = new Point(230, 250);

            }
            else if (employee.get_employeeRole().ToString().Equals("Accountant"))
            {
                this.labelError.Visible = true;
                this.labelError.Location = new Point(135, 250);
            }
        }

        private void button_OpenEventReport_Click(object sender, EventArgs e)
        {
            this.labelError.Text = "כפתור לא מוביל לשום מקום";
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
                this.labelError.Visible = true;
                this.labelError.Location = new Point(80, 250);
            }
            else if (employee.get_employeeRole().ToString().Equals("Lawyer"))
            {
                this.labelError.Visible = true;
                this.labelError.Location = new Point(230, 250);

            }
        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }
    }
}
