﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class ReadItems : Form
    {
        public ReadItems()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void readItems_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sAD_14DataSet.FoodItems' table. You can move, or remove it, as needed.
            this.foodItemsTableAdapter.Fill(this.sAD_14DataSet.FoodItems);
          

        }

        private void textBox_searchFoodItem_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter){
                if (string.IsNullOrEmpty(textBox_searchFoodItem.Text))
                {
                    NewMethod();
                }
                else
                {
                    //foodItemsTableBindingSource.Filter = String.Format("{0} LIKE '{1}*'", comboBox_SearchFromFoodList.Text, textBox_searchFoodItem.Text);
                }
                    
                }
            }

        private void NewMethod()
        {
            //foodItemsTableAdapter.Filter = string.Empty;
        }

        private void readItems_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sAD_14DataSet1.FoodItems' table. You can move, or remove it, as needed.
            this.foodItemsTableAdapter1.Fill(this.sAD_14DataSet1.FoodItems);

        }

        private void sAD14DataSet1BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonReturnToItemCrud_Click(object sender, EventArgs e)
        {
            ItemCRUD ic = new ItemCRUD();
            ic.Show();
            this.Close();
        }
    }

    
}
