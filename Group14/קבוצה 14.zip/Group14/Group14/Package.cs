using System;
using System.Data.SqlClient;

namespace Group14
{
    public class Package {

        private string packageId;
        private string volunteerId;
        private string address;

        public Package(string packageId, string volunteerId, string address)
        {
            this.packageId = packageId;
            this.volunteerId = volunteerId;
            this.address = address;
        }

        public void CreatePackage()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Package @packageId, @volunteerId_Volunteers, @Address_Locations";
            c.Parameters.AddWithValue("@packageId", this.packageId);
            c.Parameters.AddWithValue("@volunteerId_Volunteers", this.volunteerId);
            c.Parameters.AddWithValue("@Address_Locations", this.address);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public string get_packageId()
        {
            return this.packageId;
        }

        public void set_packageId(string packageId)
        {
            this.packageId = packageId;
        }

        public string get_volunteerId()
        {
            return this.volunteerId;
        }

        public void set_volunteerId(string volunteerId)
        {
            this.volunteerId = volunteerId;
        }

        public string get_address()
        {
            return this.address;
        }

        public void set_address(string address)
        {
            this.address = address;
        }
    }
}