﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class ItemCRUD : Form
    {
        public ItemCRUD()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button_AddNewItem_Click(object sender, EventArgs e)
        {
            //AddNewItem cv = new AddNewItem();
            //cv.Show();
            this.Hide();
        }

        private void button_ReadItem_Click(object sender, EventArgs e)
        {
            ReadItems ic = new ReadItems();
            ic.Show();
            this.Close();
        }

        private void ReturnTo_Click(object sender, EventArgs e)
        {

        }
    }
}
