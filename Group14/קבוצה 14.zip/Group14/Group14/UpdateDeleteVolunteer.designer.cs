﻿namespace Group14
{
    partial class UpdateDeleteVolunteer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_VolunteerId = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerFirstName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerLastName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerMail = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerPhoneNumber = new System.Windows.Forms.TextBox();
            this.comboBox_VolunteerRole = new System.Windows.Forms.ComboBox();
            this.button_UpdateVolunteer = new System.Windows.Forms.Button();
            this.button_DeleteVolunteer = new System.Windows.Forms.Button();
            this.button_ReturnToVolunteerCRUD = new System.Windows.Forms.Button();
            this.label_ErrorVolunteerId = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerFirstName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerLastName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerMail = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerPhone = new System.Windows.Forms.Label();
            this.button_Search = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(528, 194);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = ":הכנס ת.ז מתנדב";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(582, 303);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = ":שם פרטי";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(564, 394);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = ":שם משפחה";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label4.Location = new System.Drawing.Point(612, 483);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = ":מייל";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(544, 558);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = ":מספר פלאפון";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label6.Location = new System.Drawing.Point(598, 648);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = ":תפקיד";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // textBox_VolunteerId
            // 
            this.textBox_VolunteerId.Location = new System.Drawing.Point(312, 194);
            this.textBox_VolunteerId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerId.Name = "textBox_VolunteerId";
            this.textBox_VolunteerId.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerId.TabIndex = 6;
            this.textBox_VolunteerId.TextChanged += new System.EventHandler(this.textBox_VolunteerId_TextChanged);
            // 
            // textBox_VolunteerFirstName
            // 
            this.textBox_VolunteerFirstName.Location = new System.Drawing.Point(312, 298);
            this.textBox_VolunteerFirstName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerFirstName.Name = "textBox_VolunteerFirstName";
            this.textBox_VolunteerFirstName.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerFirstName.TabIndex = 7;
            // 
            // textBox_VolunteerLastName
            // 
            this.textBox_VolunteerLastName.Location = new System.Drawing.Point(312, 383);
            this.textBox_VolunteerLastName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerLastName.Name = "textBox_VolunteerLastName";
            this.textBox_VolunteerLastName.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerLastName.TabIndex = 8;
            // 
            // textBox_VolunteerMail
            // 
            this.textBox_VolunteerMail.Location = new System.Drawing.Point(312, 472);
            this.textBox_VolunteerMail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerMail.Name = "textBox_VolunteerMail";
            this.textBox_VolunteerMail.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerMail.TabIndex = 9;
            // 
            // textBox_VolunteerPhoneNumber
            // 
            this.textBox_VolunteerPhoneNumber.Location = new System.Drawing.Point(312, 554);
            this.textBox_VolunteerPhoneNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox_VolunteerPhoneNumber.Name = "textBox_VolunteerPhoneNumber";
            this.textBox_VolunteerPhoneNumber.Size = new System.Drawing.Size(148, 26);
            this.textBox_VolunteerPhoneNumber.TabIndex = 10;
            // 
            // comboBox_VolunteerRole
            // 
            this.comboBox_VolunteerRole.FormattingEnabled = true;
            this.comboBox_VolunteerRole.Location = new System.Drawing.Point(280, 643);
            this.comboBox_VolunteerRole.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox_VolunteerRole.Name = "comboBox_VolunteerRole";
            this.comboBox_VolunteerRole.Size = new System.Drawing.Size(180, 28);
            this.comboBox_VolunteerRole.TabIndex = 11;
            this.comboBox_VolunteerRole.SelectedIndexChanged += new System.EventHandler(this.comboBox_VolunteerRole_SelectedIndexChanged);
            // 
            // button_UpdateVolunteer
            // 
            this.button_UpdateVolunteer.Location = new System.Drawing.Point(549, 763);
            this.button_UpdateVolunteer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_UpdateVolunteer.Name = "button_UpdateVolunteer";
            this.button_UpdateVolunteer.Size = new System.Drawing.Size(112, 35);
            this.button_UpdateVolunteer.TabIndex = 12;
            this.button_UpdateVolunteer.Text = "עדכן";
            this.button_UpdateVolunteer.UseVisualStyleBackColor = true;
            this.button_UpdateVolunteer.Click += new System.EventHandler(this.button_UpdateVolunteer_Click);
            // 
            // button_DeleteVolunteer
            // 
            this.button_DeleteVolunteer.Location = new System.Drawing.Point(312, 763);
            this.button_DeleteVolunteer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_DeleteVolunteer.Name = "button_DeleteVolunteer";
            this.button_DeleteVolunteer.Size = new System.Drawing.Size(112, 35);
            this.button_DeleteVolunteer.TabIndex = 13;
            this.button_DeleteVolunteer.Text = "מחק";
            this.button_DeleteVolunteer.UseVisualStyleBackColor = true;
            this.button_DeleteVolunteer.Click += new System.EventHandler(this.button_DeleteVolunteer_Click);
            // 
            // button_ReturnToVolunteerCRUD
            // 
            this.button_ReturnToVolunteerCRUD.Location = new System.Drawing.Point(76, 763);
            this.button_ReturnToVolunteerCRUD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_ReturnToVolunteerCRUD.Name = "button_ReturnToVolunteerCRUD";
            this.button_ReturnToVolunteerCRUD.Size = new System.Drawing.Size(112, 35);
            this.button_ReturnToVolunteerCRUD.TabIndex = 14;
            this.button_ReturnToVolunteerCRUD.Text = "חזור";
            this.button_ReturnToVolunteerCRUD.UseVisualStyleBackColor = true;
            this.button_ReturnToVolunteerCRUD.Click += new System.EventHandler(this.button_ReturnToVolunteerCRUD_Click);
            // 
            // label_ErrorVolunteerId
            // 
            this.label_ErrorVolunteerId.AutoSize = true;
            this.label_ErrorVolunteerId.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerId.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerId.Location = new System.Drawing.Point(352, 229);
            this.label_ErrorVolunteerId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerId.Name = "label_ErrorVolunteerId";
            this.label_ErrorVolunteerId.Size = new System.Drawing.Size(109, 20);
            this.label_ErrorVolunteerId.TabIndex = 15;
            this.label_ErrorVolunteerId.Text = "קלט ת.ז שגוי";
            this.label_ErrorVolunteerId.Click += new System.EventHandler(this.label7_Click);
            // 
            // label_ErrorVolunteerFirstName
            // 
            this.label_ErrorVolunteerFirstName.AutoSize = true;
            this.label_ErrorVolunteerFirstName.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerFirstName.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerFirstName.Location = new System.Drawing.Point(310, 334);
            this.label_ErrorVolunteerFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerFirstName.Name = "label_ErrorVolunteerFirstName";
            this.label_ErrorVolunteerFirstName.Size = new System.Drawing.Size(152, 20);
            this.label_ErrorVolunteerFirstName.TabIndex = 16;
            this.label_ErrorVolunteerFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // label_ErrorVolunteerLastName
            // 
            this.label_ErrorVolunteerLastName.AutoSize = true;
            this.label_ErrorVolunteerLastName.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerLastName.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerLastName.Location = new System.Drawing.Point(290, 418);
            this.label_ErrorVolunteerLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerLastName.Name = "label_ErrorVolunteerLastName";
            this.label_ErrorVolunteerLastName.Size = new System.Drawing.Size(173, 20);
            this.label_ErrorVolunteerLastName.TabIndex = 17;
            this.label_ErrorVolunteerLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorVolunteerMail
            // 
            this.label_ErrorVolunteerMail.AutoSize = true;
            this.label_ErrorVolunteerMail.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerMail.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerMail.Location = new System.Drawing.Point(310, 508);
            this.label_ErrorVolunteerMail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerMail.Name = "label_ErrorVolunteerMail";
            this.label_ErrorVolunteerMail.Size = new System.Drawing.Size(119, 20);
            this.label_ErrorVolunteerMail.TabIndex = 18;
            this.label_ErrorVolunteerMail.Text = "קלט מייל שגוי";
            // 
            // label_ErrorVolunteerPhone
            // 
            this.label_ErrorVolunteerPhone.AutoSize = true;
            this.label_ErrorVolunteerPhone.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerPhone.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerPhone.Location = new System.Drawing.Point(310, 589);
            this.label_ErrorVolunteerPhone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ErrorVolunteerPhone.Name = "label_ErrorVolunteerPhone";
            this.label_ErrorVolunteerPhone.Size = new System.Drawing.Size(183, 20);
            this.label_ErrorVolunteerPhone.TabIndex = 19;
            this.label_ErrorVolunteerPhone.Text = "קלט מספר פלאפון שגוי";
            // 
            // button_Search
            // 
            this.button_Search.Location = new System.Drawing.Point(218, 191);
            this.button_Search.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(66, 35);
            this.button_Search.TabIndex = 20;
            this.button_Search.Text = "חפש";
            this.button_Search.UseVisualStyleBackColor = true;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // UpdateDeleteVolunteer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 946);
            this.Controls.Add(this.button_Search);
            this.Controls.Add(this.label_ErrorVolunteerPhone);
            this.Controls.Add(this.label_ErrorVolunteerMail);
            this.Controls.Add(this.label_ErrorVolunteerLastName);
            this.Controls.Add(this.label_ErrorVolunteerFirstName);
            this.Controls.Add(this.label_ErrorVolunteerId);
            this.Controls.Add(this.button_ReturnToVolunteerCRUD);
            this.Controls.Add(this.button_DeleteVolunteer);
            this.Controls.Add(this.button_UpdateVolunteer);
            this.Controls.Add(this.comboBox_VolunteerRole);
            this.Controls.Add(this.textBox_VolunteerPhoneNumber);
            this.Controls.Add(this.textBox_VolunteerMail);
            this.Controls.Add(this.textBox_VolunteerLastName);
            this.Controls.Add(this.textBox_VolunteerFirstName);
            this.Controls.Add(this.textBox_VolunteerId);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "UpdateDeleteVolunteer";
            this.Text = "ניהול מתנדב קיים";
            this.Load += new System.EventHandler(this.UpdateDeleteVolunteer_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_VolunteerId;
        private System.Windows.Forms.TextBox textBox_VolunteerFirstName;
        private System.Windows.Forms.TextBox textBox_VolunteerLastName;
        private System.Windows.Forms.TextBox textBox_VolunteerMail;
        private System.Windows.Forms.TextBox textBox_VolunteerPhoneNumber;
        private System.Windows.Forms.ComboBox comboBox_VolunteerRole;
        private System.Windows.Forms.Button button_UpdateVolunteer;
        private System.Windows.Forms.Button button_DeleteVolunteer;
        private System.Windows.Forms.Button button_ReturnToVolunteerCRUD;
        private System.Windows.Forms.Label label_ErrorVolunteerId;
        private System.Windows.Forms.Label label_ErrorVolunteerFirstName;
        private System.Windows.Forms.Label label_ErrorVolunteerLastName;
        private System.Windows.Forms.Label label_ErrorVolunteerMail;
        private System.Windows.Forms.Label label_ErrorVolunteerPhone;
        private System.Windows.Forms.Button button_Search;
    }
}