﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class ShoppingCart : Form
    {
        SqlConnection con = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True");
        public ShoppingCart()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            con.Open();
            string tempId = dataGridView1.Rows[e.RowIndex].Cells["Id"].FormattedValue.ToString();
            SqlCommand com = new SqlCommand("Delete UserInfo_Tab Where ID = '" + tempId + "'", con);
            com.ExecuteNonQuery();
            MessageBox.Show("deleted");
            con.Close();
        }
    }
}
