﻿namespace Group14
{
    partial class EmployeeSignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button_EmployeeSignIn = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeCrud = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_EmployeeId = new System.Windows.Forms.TextBox();
            this.textBox_EmployeeFirstName = new System.Windows.Forms.TextBox();
            this.textBox_EmployeeLastName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AccessibleName = "";
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(313, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "התחברות עובד";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button_EmployeeSignIn
            // 
            this.button_EmployeeSignIn.AccessibleName = "";
            this.button_EmployeeSignIn.Location = new System.Drawing.Point(259, 329);
            this.button_EmployeeSignIn.Name = "button_EmployeeSignIn";
            this.button_EmployeeSignIn.Size = new System.Drawing.Size(75, 23);
            this.button_EmployeeSignIn.TabIndex = 1;
            this.button_EmployeeSignIn.Text = "התחבר";
            this.button_EmployeeSignIn.UseVisualStyleBackColor = true;
            this.button_EmployeeSignIn.Click += new System.EventHandler(this.button_EmployeeSignIn_Click);
            // 
            // button_ReturnToEmployeeCrud
            // 
            this.button_ReturnToEmployeeCrud.AccessibleName = "";
            this.button_ReturnToEmployeeCrud.Location = new System.Drawing.Point(126, 329);
            this.button_ReturnToEmployeeCrud.Name = "button_ReturnToEmployeeCrud";
            this.button_ReturnToEmployeeCrud.Size = new System.Drawing.Size(75, 23);
            this.button_ReturnToEmployeeCrud.TabIndex = 2;
            this.button_ReturnToEmployeeCrud.Text = "חזור";
            this.button_ReturnToEmployeeCrud.UseVisualStyleBackColor = true;
            this.button_ReturnToEmployeeCrud.Click += new System.EventHandler(this.button_ReturnToEmployeeCrud_Click);
            // 
            // label2
            // 
            this.label2.AccessibleName = "";
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(345, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = ":תעודת זהות";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AccessibleName = "";
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(361, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = ":שם פרטי";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AccessibleName = "";
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(349, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = ":שם משפחה";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // textBox_EmployeeId
            // 
            this.textBox_EmployeeId.AccessibleName = "";
            this.textBox_EmployeeId.Location = new System.Drawing.Point(221, 104);
            this.textBox_EmployeeId.Name = "textBox_EmployeeId";
            this.textBox_EmployeeId.Size = new System.Drawing.Size(100, 20);
            this.textBox_EmployeeId.TabIndex = 6;
            this.textBox_EmployeeId.TextChanged += new System.EventHandler(this.textBox_EmployeeId_TextChanged);
            // 
            // textBox_EmployeeFirstName
            // 
            this.textBox_EmployeeFirstName.AccessibleName = "";
            this.textBox_EmployeeFirstName.Location = new System.Drawing.Point(221, 158);
            this.textBox_EmployeeFirstName.Name = "textBox_EmployeeFirstName";
            this.textBox_EmployeeFirstName.Size = new System.Drawing.Size(100, 20);
            this.textBox_EmployeeFirstName.TabIndex = 7;
            this.textBox_EmployeeFirstName.TextChanged += new System.EventHandler(this.textBox_EmployeeFirstName_TextChanged);
            // 
            // textBox_EmployeeLastName
            // 
            this.textBox_EmployeeLastName.AccessibleName = "";
            this.textBox_EmployeeLastName.Location = new System.Drawing.Point(221, 209);
            this.textBox_EmployeeLastName.Name = "textBox_EmployeeLastName";
            this.textBox_EmployeeLastName.Size = new System.Drawing.Size(100, 20);
            this.textBox_EmployeeLastName.TabIndex = 8;
            this.textBox_EmployeeLastName.TextChanged += new System.EventHandler(this.textBox_EmployeeLastName_TextChanged);
            // 
            // EmployeeSignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 399);
            this.Controls.Add(this.textBox_EmployeeLastName);
            this.Controls.Add(this.textBox_EmployeeFirstName);
            this.Controls.Add(this.textBox_EmployeeId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_ReturnToEmployeeCrud);
            this.Controls.Add(this.button_EmployeeSignIn);
            this.Controls.Add(this.label1);
            this.Name = "EmployeeSignIn";
            this.Text = "מסך התחברות עובד";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_EmployeeSignIn;
        private System.Windows.Forms.Button button_ReturnToEmployeeCrud;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_EmployeeId;
        private System.Windows.Forms.TextBox textBox_EmployeeFirstName;
        private System.Windows.Forms.TextBox textBox_EmployeeLastName;
    }
}