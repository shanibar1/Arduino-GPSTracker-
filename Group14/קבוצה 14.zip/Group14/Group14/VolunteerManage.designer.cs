﻿namespace Group14
{
    partial class VolunteerManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_register = new System.Windows.Forms.Button();
            this.button_watchEvents = new System.Windows.Forms.Button();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.button_return = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_register
            // 
            this.button_register.Location = new System.Drawing.Point(237, 110);
            this.button_register.Name = "button_register";
            this.button_register.Size = new System.Drawing.Size(81, 44);
            this.button_register.TabIndex = 0;
            this.button_register.Text = "הרשם לאירוע";
            this.button_register.UseVisualStyleBackColor = true;
            this.button_register.Click += new System.EventHandler(this.button_register_Click);
            // 
            // button_watchEvents
            // 
            this.button_watchEvents.Location = new System.Drawing.Point(43, 110);
            this.button_watchEvents.Name = "button_watchEvents";
            this.button_watchEvents.Size = new System.Drawing.Size(75, 44);
            this.button_watchEvents.TabIndex = 1;
            this.button_watchEvents.Text = "צפה באירועים ";
            this.button_watchEvents.UseVisualStyleBackColor = true;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.Location = new System.Drawing.Point(244, 21);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(74, 13);
            this.labelWelcome.TabIndex = 4;
            this.labelWelcome.Text = "!שלום מתנדב";
            // 
            // button_return
            // 
            this.button_return.Location = new System.Drawing.Point(149, 232);
            this.button_return.Name = "button_return";
            this.button_return.Size = new System.Drawing.Size(75, 23);
            this.button_return.TabIndex = 5;
            this.button_return.Text = "חזור";
            this.button_return.UseVisualStyleBackColor = true;
            this.button_return.Click += new System.EventHandler(this.button_return_Click);
            // 
            // VolunteerManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 270);
            this.Controls.Add(this.button_return);
            this.Controls.Add(this.labelWelcome);
            this.Controls.Add(this.button_watchEvents);
            this.Controls.Add(this.button_register);
            this.Name = "VolunteerManage";
            this.Text = "VolunteerManage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_register;
        private System.Windows.Forms.Button button_watchEvents;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Button button_return;
    }
}