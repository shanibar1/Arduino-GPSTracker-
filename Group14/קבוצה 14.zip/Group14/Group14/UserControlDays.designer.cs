﻿namespace Group14
{
    partial class UserControlDays
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Ibdays = new System.Windows.Forms.Label();
            this.ibEvent = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Ibdays
            // 
            this.Ibdays.AutoSize = true;
            this.Ibdays.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Ibdays.Location = new System.Drawing.Point(3, 10);
            this.Ibdays.Name = "Ibdays";
            this.Ibdays.Size = new System.Drawing.Size(25, 19);
            this.Ibdays.TabIndex = 0;
            this.Ibdays.Text = "00";
            // 
            // ibEvent
            // 
            this.ibEvent.Location = new System.Drawing.Point(10, 46);
            this.ibEvent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ibEvent.Name = "ibEvent";
            this.ibEvent.Size = new System.Drawing.Size(85, 31);
            this.ibEvent.TabIndex = 1;
            this.ibEvent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ibEvent.Click += new System.EventHandler(this.ibEvent_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // UserControlDays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ibEvent);
            this.Controls.Add(this.Ibdays);
            this.Name = "UserControlDays";
            this.Size = new System.Drawing.Size(109, 77);
            this.Load += new System.EventHandler(this.UserControlDays_Load);
            this.Click += new System.EventHandler(this.UserControlDays_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Ibdays;
        private System.Windows.Forms.Label ibEvent;
        private System.Windows.Forms.Timer timer1;
    }
}
