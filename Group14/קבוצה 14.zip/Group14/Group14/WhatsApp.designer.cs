﻿namespace Group14
{
    partial class WhatsApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WhatsApp));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPhone_Number = new System.Windows.Forms.TextBox();
            this.textBox_Message = new System.Windows.Forms.TextBox();
            this.buttonSend_Message = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_return = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxVolunteers_Name = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(675, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "מספר טלפון";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(668, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "תוכן ההודעה";
            // 
            // textBoxPhone_Number
            // 
            this.textBoxPhone_Number.Location = new System.Drawing.Point(271, 159);
            this.textBoxPhone_Number.Name = "textBoxPhone_Number";
            this.textBoxPhone_Number.Size = new System.Drawing.Size(366, 31);
            this.textBoxPhone_Number.TabIndex = 2;
            this.textBoxPhone_Number.TextChanged += new System.EventHandler(this.textBoxPhone_Number_TextChanged);
            // 
            // textBox_Message
            // 
            this.textBox_Message.Location = new System.Drawing.Point(271, 221);
            this.textBox_Message.Multiline = true;
            this.textBox_Message.Name = "textBox_Message";
            this.textBox_Message.Size = new System.Drawing.Size(366, 124);
            this.textBox_Message.TabIndex = 3;
            // 
            // buttonSend_Message
            // 
            this.buttonSend_Message.Location = new System.Drawing.Point(22, 356);
            this.buttonSend_Message.Name = "buttonSend_Message";
            this.buttonSend_Message.Size = new System.Drawing.Size(141, 42);
            this.buttonSend_Message.TabIndex = 4;
            this.buttonSend_Message.Text = "שלח הודעה";
            this.buttonSend_Message.UseVisualStyleBackColor = true;
            this.buttonSend_Message.Click += new System.EventHandler(this.buttonSend_Message_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("David", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(366, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(271, 47);
            this.label3.TabIndex = 6;
            this.label3.Text = "שליחת הודעה";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(191, 185);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // button_return
            // 
            this.button_return.Location = new System.Drawing.Point(722, 12);
            this.button_return.Name = "button_return";
            this.button_return.Size = new System.Drawing.Size(83, 42);
            this.button_return.TabIndex = 8;
            this.button_return.Text = "חזור";
            this.button_return.UseVisualStyleBackColor = true;
            this.button_return.Click += new System.EventHandler(this.Buttonreturn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(706, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 24);
            this.label4.TabIndex = 9;
            this.label4.Text = "שם מלא";
            // 
            // comboBoxVolunteers_Name
            // 
            this.comboBoxVolunteers_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxVolunteers_Name.FormattingEnabled = true;
            this.comboBoxVolunteers_Name.Location = new System.Drawing.Point(271, 97);
            this.comboBoxVolunteers_Name.Name = "comboBoxVolunteers_Name";
            this.comboBoxVolunteers_Name.Size = new System.Drawing.Size(366, 32);
            this.comboBoxVolunteers_Name.TabIndex = 10;
            this.comboBoxVolunteers_Name.SelectedIndexChanged += new System.EventHandler(this.comboBoxVolunteers_Name_SelectedIndexChanged);
            // 
            // whatsApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(821, 410);
            this.Controls.Add(this.comboBoxVolunteers_Name);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_return);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonSend_Message);
            this.Controls.Add(this.textBox_Message);
            this.Controls.Add(this.textBoxPhone_Number);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "whatsApp";
            this.Text = "whatsApp";
            this.Load += new System.EventHandler(this.whatsApp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPhone_Number;
        private System.Windows.Forms.TextBox textBox_Message;
        private System.Windows.Forms.Button buttonSend_Message;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_return;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxVolunteers_Name;
    }
}