﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class UpdateDeleteVolunteer : Form
    {
        private Volunteer exist_Volunteer;

        public UpdateDeleteVolunteer()
        {
        
            InitializeComponent();
            comboBox_VolunteerRole.DataSource = Enum.GetValues(typeof(VolunteerRole));
            //נטרול תיבות הטקסט כך שלא ניתן יהיה לרשום בהן
            textBox_VolunteerFirstName.Enabled = false;
            textBox_VolunteerLastName.Enabled = false;
            textBox_VolunteerMail.Enabled = false;
            textBox_VolunteerPhoneNumber.Enabled = false;
            comboBox_VolunteerRole.Enabled = false;
            //הסתרת הכפתורים
            makeLabelsErrorInvisible();
            button_DeleteVolunteer.Hide();
            button_UpdateVolunteer.Hide();
        }


        private void button_UpdateVolunteer_Click(object sender, EventArgs e)
        {
            checkInput();
            makeLabelsErrorInvisible();
            exist_Volunteer.set_volunteerFirstName(textBox_VolunteerFirstName.Text);
            exist_Volunteer.set_volunteerLastName(textBox_VolunteerLastName.Text);
            exist_Volunteer.set_volunteerMail(textBox_VolunteerMail.Text);
            exist_Volunteer.set_volunteerPhone(textBox_VolunteerPhoneNumber.Text);
            exist_Volunteer.set_volunteerRole((VolunteerRole)Enum.Parse(typeof(VolunteerRole), comboBox_VolunteerRole.Text));
            exist_Volunteer.UpdateVolunteer();

            VolunteerCRUD vcrud = new VolunteerCRUD();
            vcrud.Show();
            this.Close();
        }

        private void button_DeleteVolunteer_Click(object sender, EventArgs e)
        {
            checkInput();
            makeLabelsErrorInvisible();
            exist_Volunteer.set_volunteerFirstName(textBox_VolunteerFirstName.Text);
            exist_Volunteer.set_volunteerLastName(textBox_VolunteerLastName.Text);
            exist_Volunteer.set_volunteerMail(textBox_VolunteerMail.Text);
            exist_Volunteer.set_volunteerPhone(textBox_VolunteerPhoneNumber.Text);
            exist_Volunteer.set_volunteerRole((VolunteerRole)Enum.Parse(typeof(VolunteerRole), comboBox_VolunteerRole.Text));
            exist_Volunteer.UpdateVolunteer();

            VolunteerCRUD vcrud = new VolunteerCRUD();
            vcrud.Show();
            this.Close();
        }

        private void button_ReturnToVolunteerCRUD_Click(object sender, EventArgs e)
        {
            VolunteerCRUD vc = new VolunteerCRUD();
            vc.Show();
            this.Hide();
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void button_Search_Click(object sender, EventArgs e)
        {

            if (checkIdInput())
            {
                makeLabelsErrorInvisible();
                if (textBox_VolunteerId != null)
                {
                    label_ErrorVolunteerId.Visible = false;
                    //הצגת הכפתורים
                    button_DeleteVolunteer.Show();
                    button_UpdateVolunteer.Show();
                    //איתור המופע המתאים והצגת הפרטים
                    exist_Volunteer = Program.seekVolunteer(textBox_VolunteerId.Text);
                    textBox_VolunteerFirstName.Enabled = true;
                    textBox_VolunteerLastName.Enabled = true;
                    textBox_VolunteerMail.Enabled = true;
                    textBox_VolunteerPhoneNumber.Enabled = true;
                    comboBox_VolunteerRole.Enabled = true;
                    textBox_VolunteerFirstName.Text = exist_Volunteer.get_volunteerFirstName();
                    textBox_VolunteerLastName.Text = exist_Volunteer.get_volunteerLastName();
                    textBox_VolunteerMail.Text = exist_Volunteer.get_volunteerMail();
                    textBox_VolunteerPhoneNumber.Text = exist_Volunteer.get_volunteerPhone();
                    comboBox_VolunteerRole.DataSource = Enum.GetValues(typeof(VolunteerRole));
                    comboBox_VolunteerRole.Text = exist_Volunteer.get_volunteerRole().ToString();
                }
            }
        }

        private bool checkIdInput()
        {
            bool properIdText = textBox_VolunteerId.Text.All(char.IsDigit);
            bool properIdLength = textBox_VolunteerId.TextLength == 9;
            bool emptyId = textBox_VolunteerId.Text == "";
            if (emptyId || !properIdText || !properIdLength)
            {
                MessageBox.Show("קלט לא תקין");
                if (emptyId)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס ערך";
                }
                else if (!properIdText)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (!properIdLength)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerId.Visible = true;
                return false;
            }
            else
            {
                if (Program.seekVolunteer(textBox_VolunteerId.Text) == null)
                {
                    label_ErrorVolunteerId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorVolunteerId.Visible = true;
                    return false;
                }
                else
                {
                    label_ErrorVolunteerId.Visible = false;
                    return true;
                }
            }
        }
        private bool checkInput()
        {
            bool properIdText = !textBox_VolunteerId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_VolunteerId.TextLength == 9);
            bool emptyId = textBox_VolunteerId.Text == "";

            // checking first name value
            bool properFirstNameText = !textBox_VolunteerFirstName.Text.All(char.IsLetter);
            bool emptyFirstName = textBox_VolunteerFirstName.Text == "";

            // checking last name value
            bool properLastNameText = !textBox_VolunteerLastName.Text.All(char.IsLetter);
            bool emptyLastName = textBox_VolunteerLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_VolunteerMail.Text.Contains('@') || textBox_VolunteerMail.Text.Contains('.'));
            bool properMailLength = !(textBox_VolunteerMail.TextLength >= 5);
            bool emptyMail = textBox_VolunteerMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_VolunteerPhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_VolunteerPhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_VolunteerPhoneNumber.Text == "";


            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerId.Visible = true;
            }
            else
            {
                if (Program.seekEmployee(textBox_VolunteerId.Text) != null)
                {
                    label_ErrorVolunteerId.Text = "תעודת הזהות כבר קיימת במערכת";
                }
                else
                {
                    label_ErrorVolunteerId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerFirstName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerLastName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorVolunteerMail.Visible = true;
            }
            else
            {
                label_ErrorVolunteerMail.Visible = false;
            }
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerPhone.Visible = true;
            }
            else
            {
                label_ErrorVolunteerPhone.Visible = false;
            }

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }
        private void makeLabelsErrorInvisible()
        {
            label_ErrorVolunteerId.Visible = false;
            label_ErrorVolunteerFirstName.Visible = false;
            label_ErrorVolunteerLastName.Visible = false;
            label_ErrorVolunteerMail.Visible = false;
            label_ErrorVolunteerPhone.Visible = false;
        }
        private void UpdateDeleteVolunteer_Load(object sender, EventArgs e)
        {

        }

        private void comboBox_VolunteerRole_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


     
        private void textBox_VolunteerId_TextChanged(object sender, EventArgs e)
        {

        }
       

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void UpdateDeleteVolunteer_Load_1(object sender, EventArgs e)
        {

        }
    }
}
