﻿namespace Group14
{
    partial class VolunteerSignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_VolunteerLastName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerFirstName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerId = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button_ReturnToVolunteerCrud = new System.Windows.Forms.Button();
            this.button_VolunteerSignIn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox_VolunteerLastName
            // 
            this.textBox_VolunteerLastName.Location = new System.Drawing.Point(219, 185);
            this.textBox_VolunteerLastName.Name = "textBox_VolunteerLastName";
            this.textBox_VolunteerLastName.Size = new System.Drawing.Size(100, 20);
            this.textBox_VolunteerLastName.TabIndex = 17;
            //this.textBox_VolunteerLastName.TextChanged += new System.EventHandler(this.textBox_EmployeeLastName_TextChanged);
            // 
            // textBox_VolunteerFirstName
            // 
            this.textBox_VolunteerFirstName.Location = new System.Drawing.Point(219, 134);
            this.textBox_VolunteerFirstName.Name = "textBox_VolunteerFirstName";
            this.textBox_VolunteerFirstName.Size = new System.Drawing.Size(100, 20);
            this.textBox_VolunteerFirstName.TabIndex = 16;
            // 
            // textBox_VolunteerId
            // 
            this.textBox_VolunteerId.Location = new System.Drawing.Point(219, 80);
            this.textBox_VolunteerId.Name = "textBox_VolunteerId";
            this.textBox_VolunteerId.Size = new System.Drawing.Size(100, 20);
            this.textBox_VolunteerId.TabIndex = 15;
            this.textBox_VolunteerId.TextChanged += new System.EventHandler(this.textBox_VolunteerId_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(347, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = ":שם משפחה";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(359, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = ":שם פרטי";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(343, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = ":תעודת זהות";
            // 
            // button_ReturnToVolunteerCrud
            // 
            this.button_ReturnToVolunteerCrud.Location = new System.Drawing.Point(124, 305);
            this.button_ReturnToVolunteerCrud.Name = "button_ReturnToVolunteerCrud";
            this.button_ReturnToVolunteerCrud.Size = new System.Drawing.Size(75, 23);
            this.button_ReturnToVolunteerCrud.TabIndex = 11;
            this.button_ReturnToVolunteerCrud.Text = "חזור";
            this.button_ReturnToVolunteerCrud.UseVisualStyleBackColor = true;
            this.button_ReturnToVolunteerCrud.Click += new System.EventHandler(this.button_ReturnToVolunteerCrud_Click);
            // 
            // button_VolunteerSignIn
            // 
            this.button_VolunteerSignIn.Location = new System.Drawing.Point(257, 305);
            this.button_VolunteerSignIn.Name = "button_VolunteerSignIn";
            this.button_VolunteerSignIn.Size = new System.Drawing.Size(75, 23);
            this.button_VolunteerSignIn.TabIndex = 10;
            this.button_VolunteerSignIn.Text = "התחבר";
            this.button_VolunteerSignIn.UseVisualStyleBackColor = true;
            this.button_VolunteerSignIn.Click += new System.EventHandler(this.button_VolunteerSignIn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(185, -30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "התחברות עובד";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(324, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "התחברות מתנדב";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // VolunteerSignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 402);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_VolunteerLastName);
            this.Controls.Add(this.textBox_VolunteerFirstName);
            this.Controls.Add(this.textBox_VolunteerId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_ReturnToVolunteerCrud);
            this.Controls.Add(this.button_VolunteerSignIn);
            this.Controls.Add(this.label1);
            this.Name = "VolunteerSignIn";
            this.Text = "VolunteerSignIn";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_VolunteerLastName;
        private System.Windows.Forms.TextBox textBox_VolunteerFirstName;
        private System.Windows.Forms.TextBox textBox_VolunteerId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_ReturnToVolunteerCrud;
        private System.Windows.Forms.Button button_VolunteerSignIn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
    }
}