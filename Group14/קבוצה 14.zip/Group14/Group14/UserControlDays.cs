﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class UserControlDays : UserControl
    {
        private Event exist_Event;
        public static string static_day;
        public UserControlDays()
        {
            InitializeComponent();
        }

        private void UserControlDays_Load(object sender, EventArgs e)
        {

        }
        public void days (int numdays)
        {
            DateTime today = DateTime.Now;
            Ibdays.Text = numdays + "";
        }

        private void UserControlDays_Click(object sender, EventArgs e)
        {
            static_day = Ibdays.Text;
            timer1.Start();
            EventForm Event_Form = new EventForm();
            Event_Form.Show();
        }
        public void displayEvent(int day, int month, int year)
        {
            foreach(Event e in Program.Events)
            {
                DateTime d = new DateTime(year, month, day);
                if(e.GetDate() == d)
                {
                    this.exist_Event = e;
                    break;
                }
            }
            if (this.exist_Event != null)
                ibEvent.Text = exist_Event.GetName();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //displayEvent();
        }

        private void ibEvent_Click(object sender, EventArgs e)
        {
            static_day = Ibdays.Text;
            timer1.Start();
            if (ibEvent.Text.Equals(""))
            {
                EventForm Event_Form = new EventForm();
                Event_Form.Show();
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("?האם מעוניין למחוק אירוע", "מחיקת אירוע קיים", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    this.exist_Event.Delete_Event();
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do nothing
                }
            }
        }
    }
}
