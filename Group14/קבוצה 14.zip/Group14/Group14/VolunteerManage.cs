﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class VolunteerManage : Form
    {
        private Volunteer volunteer;
        public VolunteerManage(String id)
        {
            InitializeComponent();
            foreach (Volunteer v in Program.Volunteers)
            {
                if (v.get_volunteerId().Equals(id))
                {
                    this.volunteer = v;
                    break;
                }
            }
            this.labelWelcome.Text = "!" + "שלום" + " " + volunteer.get_volunteerFirstName(); // עברית

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button_return_Click(object sender, EventArgs e)
        {

            VolunteerSignIn vsi = new VolunteerSignIn();
            vsi.Show();
            this.Hide();
        }

        private void button_register_Click(object sender, EventArgs e)
        {
            //RegistrationToEvent vsi = new RegistrationToEvent(volunteer);
           // vsi.Show();
            this.Hide();
        }
    }
}
