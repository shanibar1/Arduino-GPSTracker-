﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeTrackPackage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.button_PackageTracking = new System.Windows.Forms.Button();
            this.button_CurrentLocation = new System.Windows.Forms.Button();
            this.labelTrackPackage = new System.Windows.Forms.Label();
            this.button_ReturnToSignIn = new System.Windows.Forms.Button();
            this.pictureBox_GoogleMaps = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_GoogleMaps)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(222, 1319);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            this.splitter1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitter1_SplitterMoved);
            // 
            // button_PackageTracking
            // 
            this.button_PackageTracking.Location = new System.Drawing.Point(30, 268);
            this.button_PackageTracking.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_PackageTracking.Name = "button_PackageTracking";
            this.button_PackageTracking.Size = new System.Drawing.Size(165, 35);
            this.button_PackageTracking.TabIndex = 1;
            this.button_PackageTracking.Text = "מעקב אחר החבילה";
            this.button_PackageTracking.UseVisualStyleBackColor = true;
            this.button_PackageTracking.Click += new System.EventHandler(this.button_PackageTracking_Click);
            // 
            // button_CurrentLocation
            // 
            this.button_CurrentLocation.Location = new System.Drawing.Point(45, 346);
            this.button_CurrentLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button_CurrentLocation.Name = "button_CurrentLocation";
            this.button_CurrentLocation.Size = new System.Drawing.Size(134, 35);
            this.button_CurrentLocation.TabIndex = 2;
            this.button_CurrentLocation.Text = "מיקום נוכחי";
            this.button_CurrentLocation.UseVisualStyleBackColor = true;
            this.button_CurrentLocation.Click += new System.EventHandler(this.button_CurrentLocation_Click);
            // 
            // labelTrackPackage
            // 
            this.labelTrackPackage.AutoSize = true;
            this.labelTrackPackage.Location = new System.Drawing.Point(40, 66);
            this.labelTrackPackage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTrackPackage.Name = "labelTrackPackage";
            this.labelTrackPackage.Size = new System.Drawing.Size(130, 20);
            this.labelTrackPackage.TabIndex = 3;
            this.labelTrackPackage.Text = "עקוב אחר החבילה";
            // 
            // button_ReturnToSignIn
            // 
            this.button_ReturnToSignIn.Location = new System.Drawing.Point(69, 1231);
            this.button_ReturnToSignIn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_ReturnToSignIn.Name = "button_ReturnToSignIn";
            this.button_ReturnToSignIn.Size = new System.Drawing.Size(84, 29);
            this.button_ReturnToSignIn.TabIndex = 5;
            this.button_ReturnToSignIn.Text = "חזור";
            this.button_ReturnToSignIn.UseVisualStyleBackColor = true;
            this.button_ReturnToSignIn.Click += new System.EventHandler(this.button_ReturnToSignIn_Click);
            // 
            // pictureBox_GoogleMaps
            // 
            this.pictureBox_GoogleMaps.Image = global::Group14.Properties.Resources.GoogleMaps;
            this.pictureBox_GoogleMaps.Location = new System.Drawing.Point(222, 0);
            this.pictureBox_GoogleMaps.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox_GoogleMaps.Name = "pictureBox_GoogleMaps";
            this.pictureBox_GoogleMaps.Size = new System.Drawing.Size(1169, 1320);
            this.pictureBox_GoogleMaps.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_GoogleMaps.TabIndex = 4;
            this.pictureBox_GoogleMaps.TabStop = false;
            this.pictureBox_GoogleMaps.Click += new System.EventHandler(this.pictureBox_GoogleMaps_Click);
            // 
            // DonatedFamilyRepresentativeTrackPackage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1390, 1319);
            this.Controls.Add(this.button_ReturnToSignIn);
            this.Controls.Add(this.pictureBox_GoogleMaps);
            this.Controls.Add(this.labelTrackPackage);
            this.Controls.Add(this.button_CurrentLocation);
            this.Controls.Add(this.button_PackageTracking);
            this.Controls.Add(this.splitter1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "DonatedFamilyRepresentativeTrackPackage";
            this.Text = "מעקב אחר חבילה";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_GoogleMaps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Button button_PackageTracking;
        private System.Windows.Forms.Button button_CurrentLocation;
        private System.Windows.Forms.Label labelTrackPackage;
        private System.Windows.Forms.Button button_ReturnToSignIn;
        private System.Windows.Forms.PictureBox pictureBox_GoogleMaps;
    }
}