using System;

namespace Group14
{
    public class Donation {
        private string donationID;
        private string donationDescription;
        private float donationAmount;
        private DateTime donationDate;
        private PaymentMethod paymentMethod;

        public bool SendApproval() {
            throw new System.NotImplementedException("Not implemented");
        }
        public void UpdateBudget() {
            throw new System.NotImplementedException("Not implemented");
        }
        public Donation() {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}
