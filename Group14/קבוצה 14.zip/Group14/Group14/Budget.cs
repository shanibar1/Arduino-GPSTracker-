using System;

namespace Group14
{
    public class Budget
    {
        private int balance;

        public float GetBalanceAfterOrder()
        {
            throw new System.NotImplementedException("Not implemented");
        }
        public Budget()
        {
            throw new System.NotImplementedException("Not implemented");
        }

    }
}
