using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Group14
{

    public class RegistrationForEvent {

        private Event e;
        private List<Volunteer> volunteers;
        private List<Volunteer> drivers;

        public RegistrationForEvent(Event e, Volunteer v)
        {
            this.e = e;
            if (v.get_volunteerRole().Equals(VolunteerRole.Driver))
                this.drivers.Add(v);
            else
                this.volunteers.Add(v);
        }

        public int getVolunteersAmount()
        {
            int count = 0;
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();

                string query = @"
            SELECT COUNT(*) 
            FROM Registarations AS R
            WHERE R.registered = 1 AND R.eventId_Events = @eventId";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@eventId", e.GetEventId());

                    object result = command.ExecuteScalar();
                    count = Convert.ToInt32(result);
                }
            }
            return count;
        }
    }
}