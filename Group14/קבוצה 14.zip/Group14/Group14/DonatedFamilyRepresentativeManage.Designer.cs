﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_GiveFeedback = new System.Windows.Forms.Button();
            this.button_TrackPackage = new System.Windows.Forms.Button();
            this.button_BackToHomePage = new System.Windows.Forms.Button();
            this.labelFamily = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_GiveFeedback
            // 
            this.button_GiveFeedback.Location = new System.Drawing.Point(229, 110);
            this.button_GiveFeedback.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_GiveFeedback.Name = "button_GiveFeedback";
            this.button_GiveFeedback.Size = new System.Drawing.Size(100, 28);
            this.button_GiveFeedback.TabIndex = 0;
            this.button_GiveFeedback.Text = "מילוי משוב";
            this.button_GiveFeedback.UseVisualStyleBackColor = true;
            this.button_GiveFeedback.Click += new System.EventHandler(this.button_GiveFeedback_Click);
            // 
            // button_TrackPackage
            // 
            this.button_TrackPackage.Location = new System.Drawing.Point(43, 110);
            this.button_TrackPackage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_TrackPackage.Name = "button_TrackPackage";
            this.button_TrackPackage.Size = new System.Drawing.Size(143, 28);
            this.button_TrackPackage.TabIndex = 1;
            this.button_TrackPackage.Text = "מעקב אחר חבילה";
            this.button_TrackPackage.UseVisualStyleBackColor = true;
            this.button_TrackPackage.Click += new System.EventHandler(this.button_TrackPackage_Click);
            // 
            // button_BackToHomePage
            // 
            this.button_BackToHomePage.Location = new System.Drawing.Point(151, 213);
            this.button_BackToHomePage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_BackToHomePage.Name = "button_BackToHomePage";
            this.button_BackToHomePage.Size = new System.Drawing.Size(100, 28);
            this.button_BackToHomePage.TabIndex = 2;
            this.button_BackToHomePage.Text = "חזור";
            this.button_BackToHomePage.UseVisualStyleBackColor = true;
            this.button_BackToHomePage.Click += new System.EventHandler(this.button_BackToHomePage_Click);
            // 
            // labelFamily
            // 
            this.labelFamily.AutoSize = true;
            this.labelFamily.Location = new System.Drawing.Point(148, 52);
            this.labelFamily.Name = "labelFamily";
            this.labelFamily.Size = new System.Drawing.Size(136, 17);
            this.labelFamily.TabIndex = 3;
            this.labelFamily.Text = "שלום למשפחה הנתרמת";
            // 
            // DonatedFamilyRepresentativeManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 321);
            this.Controls.Add(this.labelFamily);
            this.Controls.Add(this.button_BackToHomePage);
            this.Controls.Add(this.button_TrackPackage);
            this.Controls.Add(this.button_GiveFeedback);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "DonatedFamilyRepresentativeManage";
            this.Text = "מסך משפחה";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_GiveFeedback;
        private System.Windows.Forms.Button button_TrackPackage;
        private System.Windows.Forms.Button button_BackToHomePage;
        private System.Windows.Forms.Label labelFamily;
    }
}