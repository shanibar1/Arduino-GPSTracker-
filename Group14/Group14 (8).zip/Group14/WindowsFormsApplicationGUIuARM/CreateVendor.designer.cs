﻿namespace Group14
{
    partial class CreateVendor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateVendor));
            this.label_ErrorVendorPhone = new System.Windows.Forms.Label();
            this.label_ErrorVendorMail = new System.Windows.Forms.Label();
            this.label_ErrorVendorLastName = new System.Windows.Forms.Label();
            this.label_ErrorVendorFirstName = new System.Windows.Forms.Label();
            this.label_ErrorVendorId = new System.Windows.Forms.Label();
            this.button_AddNewVendor = new System.Windows.Forms.Button();
            this.button_Return = new System.Windows.Forms.Button();
            this.textBox_VendorPhoneNumber = new System.Windows.Forms.TextBox();
            this.textBox_VendorMail = new System.Windows.Forms.TextBox();
            this.textBox_VendorLastName = new System.Windows.Forms.TextBox();
            this.textBox_VendorFirstName = new System.Windows.Forms.TextBox();
            this.textBox_VendorId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label_ErrorVendorPhone
            // 
            this.label_ErrorVendorPhone.AutoSize = true;
            this.label_ErrorVendorPhone.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorPhone.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ErrorVendorPhone.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorPhone.Location = new System.Drawing.Point(571, 430);
            this.label_ErrorVendorPhone.Name = "label_ErrorVendorPhone";
            this.label_ErrorVendorPhone.Size = new System.Drawing.Size(262, 28);
            this.label_ErrorVendorPhone.TabIndex = 39;
            this.label_ErrorVendorPhone.Text = "קלט מספר פלאפון שגוי";
            // 
            // label_ErrorVendorMail
            // 
            this.label_ErrorVendorMail.AutoSize = true;
            this.label_ErrorVendorMail.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorMail.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ErrorVendorMail.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorMail.Location = new System.Drawing.Point(571, 363);
            this.label_ErrorVendorMail.Name = "label_ErrorVendorMail";
            this.label_ErrorVendorMail.Size = new System.Drawing.Size(170, 28);
            this.label_ErrorVendorMail.TabIndex = 38;
            this.label_ErrorVendorMail.Text = "קלט מייל שגוי";
            // 
            // label_ErrorVendorLastName
            // 
            this.label_ErrorVendorLastName.AutoSize = true;
            this.label_ErrorVendorLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorLastName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ErrorVendorLastName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorLastName.Location = new System.Drawing.Point(571, 299);
            this.label_ErrorVendorLastName.Name = "label_ErrorVendorLastName";
            this.label_ErrorVendorLastName.Size = new System.Drawing.Size(248, 28);
            this.label_ErrorVendorLastName.TabIndex = 37;
            this.label_ErrorVendorLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorVendorFirstName
            // 
            this.label_ErrorVendorFirstName.AutoSize = true;
            this.label_ErrorVendorFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorFirstName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ErrorVendorFirstName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorFirstName.Location = new System.Drawing.Point(571, 240);
            this.label_ErrorVendorFirstName.Name = "label_ErrorVendorFirstName";
            this.label_ErrorVendorFirstName.Size = new System.Drawing.Size(220, 28);
            this.label_ErrorVendorFirstName.TabIndex = 36;
            this.label_ErrorVendorFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // label_ErrorVendorId
            // 
            this.label_ErrorVendorId.AutoSize = true;
            this.label_ErrorVendorId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorId.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ErrorVendorId.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorId.Location = new System.Drawing.Point(571, 181);
            this.label_ErrorVendorId.Name = "label_ErrorVendorId";
            this.label_ErrorVendorId.Size = new System.Drawing.Size(155, 28);
            this.label_ErrorVendorId.TabIndex = 35;
            this.label_ErrorVendorId.Text = "קלט ת.ז שגוי";
            // 
            // button_AddNewVendor
            // 
            this.button_AddNewVendor.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button_AddNewVendor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_AddNewVendor.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_AddNewVendor.Location = new System.Drawing.Point(0, 474);
            this.button_AddNewVendor.Name = "button_AddNewVendor";
            this.button_AddNewVendor.Size = new System.Drawing.Size(223, 71);
            this.button_AddNewVendor.TabIndex = 34;
            this.button_AddNewVendor.Text = "צור ספק";
            this.button_AddNewVendor.UseVisualStyleBackColor = false;
            this.button_AddNewVendor.Click += new System.EventHandler(this.button_AddNewVendor_Click_1);
            // 
            // button_Return
            // 
            this.button_Return.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button_Return.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Return.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_Return.Location = new System.Drawing.Point(0, 397);
            this.button_Return.Name = "button_Return";
            this.button_Return.Size = new System.Drawing.Size(223, 71);
            this.button_Return.TabIndex = 33;
            this.button_Return.Text = "חזור לדף ספק";
            this.button_Return.UseVisualStyleBackColor = false;
            this.button_Return.Click += new System.EventHandler(this.button_Return_Click);
            // 
            // textBox_VendorPhoneNumber
            // 
            this.textBox_VendorPhoneNumber.Location = new System.Drawing.Point(860, 425);
            this.textBox_VendorPhoneNumber.Name = "textBox_VendorPhoneNumber";
            this.textBox_VendorPhoneNumber.Size = new System.Drawing.Size(264, 20);
            this.textBox_VendorPhoneNumber.TabIndex = 31;
            // 
            // textBox_VendorMail
            // 
            this.textBox_VendorMail.Location = new System.Drawing.Point(860, 358);
            this.textBox_VendorMail.Name = "textBox_VendorMail";
            this.textBox_VendorMail.Size = new System.Drawing.Size(264, 20);
            this.textBox_VendorMail.TabIndex = 30;
            // 
            // textBox_VendorLastName
            // 
            this.textBox_VendorLastName.Location = new System.Drawing.Point(860, 294);
            this.textBox_VendorLastName.Name = "textBox_VendorLastName";
            this.textBox_VendorLastName.Size = new System.Drawing.Size(264, 20);
            this.textBox_VendorLastName.TabIndex = 29;
            // 
            // textBox_VendorFirstName
            // 
            this.textBox_VendorFirstName.Location = new System.Drawing.Point(860, 235);
            this.textBox_VendorFirstName.Name = "textBox_VendorFirstName";
            this.textBox_VendorFirstName.Size = new System.Drawing.Size(264, 20);
            this.textBox_VendorFirstName.TabIndex = 28;
            // 
            // textBox_VendorId
            // 
            this.textBox_VendorId.Location = new System.Drawing.Point(860, 176);
            this.textBox_VendorId.Name = "textBox_VendorId";
            this.textBox_VendorId.Size = new System.Drawing.Size(264, 20);
            this.textBox_VendorId.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(1153, 425);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(165, 28);
            this.label7.TabIndex = 25;
            this.label7.Text = ":מספר פלאפון";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(1229, 359);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 28);
            this.label6.TabIndex = 24;
            this.label6.Text = ":מייל";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(1176, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 28);
            this.label5.TabIndex = 23;
            this.label5.Text = ":שם משפחה";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(1195, 235);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 28);
            this.label4.TabIndex = 22;
            this.label4.Text = ":שם פרטי";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(1178, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 28);
            this.label3.TabIndex = 21;
            this.label3.Text = ":תעודת זהות";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(749, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(626, 63);
            this.label2.TabIndex = 20;
            this.label2.Text = ":מלא את הפרטים הבאים";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(223, 660);
            this.splitter1.TabIndex = 40;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(223, 205);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // CreateVendor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1375, 660);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label_ErrorVendorPhone);
            this.Controls.Add(this.label_ErrorVendorMail);
            this.Controls.Add(this.label_ErrorVendorLastName);
            this.Controls.Add(this.label_ErrorVendorFirstName);
            this.Controls.Add(this.label_ErrorVendorId);
            this.Controls.Add(this.button_AddNewVendor);
            this.Controls.Add(this.button_Return);
            this.Controls.Add(this.textBox_VendorPhoneNumber);
            this.Controls.Add(this.textBox_VendorMail);
            this.Controls.Add(this.textBox_VendorLastName);
            this.Controls.Add(this.textBox_VendorFirstName);
            this.Controls.Add(this.textBox_VendorId);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.splitter1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "CreateVendor";
            this.Text = "יצירת ספק חדש";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_ErrorVendorPhone;
        private System.Windows.Forms.Label label_ErrorVendorMail;
        private System.Windows.Forms.Label label_ErrorVendorLastName;
        private System.Windows.Forms.Label label_ErrorVendorFirstName;
        private System.Windows.Forms.Label label_ErrorVendorId;
        private System.Windows.Forms.Button button_AddNewVendor;
        private System.Windows.Forms.Button button_Return;
        private System.Windows.Forms.TextBox textBox_VendorPhoneNumber;
        private System.Windows.Forms.TextBox textBox_VendorMail;
        private System.Windows.Forms.TextBox textBox_VendorLastName;
        private System.Windows.Forms.TextBox textBox_VendorFirstName;
        private System.Windows.Forms.TextBox textBox_VendorId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}