﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class CreateVolunteer : Form
    {
        private Employee employee;
        public CreateVolunteer(Employee e)
        {
            InitializeComponent();
            comboBox_VolunteerRole.DataSource = Enum.GetValues(typeof(VolunteerRole));
            checkBox_DrivingLicence.Enabled = false;
            makeLabelsErrorInvisible();
            this.employee = e;
        }

        private void button_AddNewVolunteer_Click(object sender, EventArgs e)
        {
            bool driver = comboBox_VolunteerRole.Text.Equals("Driver") && checkBox_DrivingLicence.Checked && checkInput();
            bool other = !comboBox_VolunteerRole.Text.Equals("Driver") && checkInput();
            if (driver || other)
            {
                Volunteer vol = Program.seekVolunteer(textBox_VolunteerId.Text);
                if (vol == null)
                {
                    button_AddNewVolunteer.BackColor = Color.Green;
                    Volunteer v = new Volunteer(textBox_VolunteerId.Text, textBox_VolunteerFirstName.Text, textBox_VolunteerLastName.Text,
                        textBox_VolunteerMail.Text, textBox_VolunteerPhoneNumber.Text, checkBox_DrivingLicence.Checked, (VolunteerRole)Enum.Parse(typeof(VolunteerRole), comboBox_VolunteerRole.Text), true, true);//יצירת עובד חדש

                    CreateVolunteer em = new CreateVolunteer(this.employee);
                    em.Show();
                    this.Close();
                    // זה אומר שגם סומן שהוא נהג וגם סומן שיש לו רישיון
                }
                else
                {
                    vol.set_volunteerFirstName(textBox_VolunteerFirstName.Text);
                    vol.set_volunteerLastName(textBox_VolunteerLastName.Text);
                    vol.set_volunteerMail(textBox_VolunteerMail.Text);
                    vol.set_volunteerPhone(textBox_VolunteerPhoneNumber.Text);
                    vol.set_volunteerRole((VolunteerRole)Enum.Parse(typeof(VolunteerRole), comboBox_VolunteerRole.Text));
                    vol.set_isVolunteerActive(true);
                    vol.UpdateVolunteer();
                    CreateVolunteer em = new CreateVolunteer(this.employee);
                    em.Show();
                    this.Close();
                }

            }
            else
            {
                button_AddNewVolunteer.BackColor = Color.Red;
                lable_drivingLicence.Visible = true;
            }
        }
    
        private void button_ReturnToEmployeeManage_Click(object sender, EventArgs e)
        {
            VolunteerCRUD em = new VolunteerCRUD(this.employee);
            em.Show();
            this.Close();
        }

        private bool checkInput()
        {
            bool properIdText = !textBox_VolunteerId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_VolunteerId.TextLength == 9);
            bool emptyId = textBox_VolunteerId.Text == "";
            bool ceo = false;

            // checking first name value
            string name = textBox_VolunteerFirstName.Text.Replace(" ", "");
            bool properFirstNameText = !name.All(char.IsLetter);
            bool emptyFirstName = textBox_VolunteerFirstName.Text == "";

            // checking last name value 
            name = textBox_VolunteerLastName.Text.Replace(" ", "");
            bool properLastNameText = !name.All(char.IsLetter);
            bool emptyLastName = textBox_VolunteerLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_VolunteerMail.Text.Contains('@') || textBox_VolunteerMail.Text.Contains('.'));
            bool properMailLength = !(textBox_VolunteerMail.TextLength >= 5);
            bool emptyMail = textBox_VolunteerMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_VolunteerPhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_VolunteerPhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_VolunteerPhoneNumber.Text == "";


            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerId.Visible = true;
            }
            else
            {
                if (Program.seekVolunteer(textBox_VolunteerId.Text) != null)
                {
                    if (Program.seekVolunteer(textBox_VolunteerId.Text).get_isVolunteerActive())
                    {
                        label_ErrorVolunteerId.Text = "תעודת הזהות כבר קיימת במערכת";
                        label_ErrorVolunteerId.Visible = true;

                    }
                } 
                else if (Program.seekEmployee(textBox_VolunteerId.Text) != null)
                {
                    if (Program.seekEmployee(textBox_VolunteerId.Text).get_employeeRole() == EmployeeRole.CEO)
                    {
                        label_ErrorVolunteerId.Text = "תעודת הזהות כבר קיימת במערכת";
                        ceo = true;
                    }
                    else ceo = false;

                }
                else
                {
                    label_ErrorVolunteerId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerFirstName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerLastName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorVolunteerMail.Visible = true;
            }
            else
            {
                label_ErrorVolunteerMail.Visible = false;
            }
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerPhone.Visible = true;
            }
            else
            {
                label_ErrorVolunteerPhone.Visible = false;
            }

            if (label_ErrorVolunteerId.Visible || properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone || ceo)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }

        private void comboBox_VolunteerRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox_VolunteerRole.Text.Equals("Driver"))
                checkBox_DrivingLicence.Enabled = true;
            else
            {
                checkBox_DrivingLicence.Checked = false;
                checkBox_DrivingLicence.Enabled = false;
            }
        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorVolunteerId.Visible = false;
            label_ErrorVolunteerFirstName.Visible = false;
            label_ErrorVolunteerLastName.Visible = false;
            label_ErrorVolunteerMail.Visible = false;
            label_ErrorVolunteerPhone.Visible = false;
            lable_drivingLicence.Visible = false;
            
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void label_ErrorVolunteerId_Click(object sender, EventArgs e)
        {

        }
    }
}
