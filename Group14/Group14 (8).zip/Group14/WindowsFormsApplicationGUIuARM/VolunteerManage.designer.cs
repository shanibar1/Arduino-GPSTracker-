﻿namespace Group14
{
    partial class VolunteerManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VolunteerManage));
            this.button_register = new System.Windows.Forms.Button();
            this.button_watchEvents = new System.Windows.Forms.Button();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.button_return = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_register
            // 
            this.button_register.BackColor = System.Drawing.Color.Teal;
            this.button_register.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_register.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_register.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_register.Location = new System.Drawing.Point(0, 153);
            this.button_register.Name = "button_register";
            this.button_register.Size = new System.Drawing.Size(309, 84);
            this.button_register.TabIndex = 0;
            this.button_register.Text = "הרשם לאירוע";
            this.button_register.UseVisualStyleBackColor = false;
            this.button_register.Click += new System.EventHandler(this.button_register_Click);
            // 
            // button_watchEvents
            // 
            this.button_watchEvents.BackColor = System.Drawing.Color.Teal;
            this.button_watchEvents.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_watchEvents.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_watchEvents.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_watchEvents.Location = new System.Drawing.Point(0, 79);
            this.button_watchEvents.Name = "button_watchEvents";
            this.button_watchEvents.Size = new System.Drawing.Size(309, 74);
            this.button_watchEvents.TabIndex = 1;
            this.button_watchEvents.Text = "צפה באירועים ";
            this.button_watchEvents.UseVisualStyleBackColor = false;
            this.button_watchEvents.Click += new System.EventHandler(this.button_watchEvents_Click);
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("David", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.labelWelcome.Location = new System.Drawing.Point(527, 302);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(192, 35);
            this.labelWelcome.TabIndex = 4;
            this.labelWelcome.Text = "!שלום מתנדב";
            // 
            // button_return
            // 
            this.button_return.BackColor = System.Drawing.Color.Teal;
            this.button_return.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_return.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_return.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_return.Location = new System.Drawing.Point(0, 0);
            this.button_return.Name = "button_return";
            this.button_return.Size = new System.Drawing.Size(309, 79);
            this.button_return.TabIndex = 5;
            this.button_return.Text = "חזור";
            this.button_return.UseVisualStyleBackColor = false;
            this.button_return.Click += new System.EventHandler(this.button_return_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Turquoise;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1081, 100);
            this.panel1.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(723, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(358, 63);
            this.label5.TabIndex = 16;
            this.label5.Text = "דף בית מתנדב";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.button_register);
            this.panel2.Controls.Add(this.button_watchEvents);
            this.panel2.Controls.Add(this.button_return);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(309, 499);
            this.panel2.TabIndex = 7;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::WindowsFormsApplicationGUIuARM.Properties.Resources.My_project;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(0, 237);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(309, 182);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // VolunteerManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1081, 599);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labelWelcome);
            this.Name = "VolunteerManage";
            this.Text = "ניהול מתנדבים";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_register;
        private System.Windows.Forms.Button button_watchEvents;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Button button_return;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}