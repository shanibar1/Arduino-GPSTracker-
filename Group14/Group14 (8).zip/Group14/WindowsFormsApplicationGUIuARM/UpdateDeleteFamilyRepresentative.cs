﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Group14
{
    public partial class UpdateDeleteFamilyRepresentative : Form
    {
        private Employee employee;
        private DonatedFamilyRepresentative exist_Family;
        public UpdateDeleteFamilyRepresentative(Employee e)
        {
            InitializeComponent();
            textBox_FamilyFirstName.Enabled = false;
            textBox_FamilyLastName.Enabled = false;
            textBox_FamilyPhoneNumber.Enabled = false;
            textBox_FamilyAddress.Enabled = false;
            makeLabelsErrorInvisible();
            button_DeleteFamily.Hide();
            button_UpdateFamily.Hide();
            this.employee = e;
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            if (checkIdInput())
            {
                makeLabelsErrorInvisible();
                if (textBox_FamilyId != null)
                {
                    label_ErrorFamilyId.Visible = false;
                    button_DeleteFamily.Show();
                    button_UpdateFamily.Show();
                    exist_Family = Program.seekFamily(textBox_FamilyId.Text);
                    textBox_FamilyFirstName.Enabled = true;
                    textBox_FamilyLastName.Enabled = true;
                    textBox_FamilyPhoneNumber.Enabled = true;
                    textBox_FamilyAddress.Enabled = true;
                    textBox_FamilyId.Enabled = false;
                    textBox_FamilyFirstName.Text = exist_Family.get_firstName();
                    textBox_FamilyLastName.Text = exist_Family.get_lastName();
                    textBox_FamilyPhoneNumber.Text = exist_Family.get_phoneNumber();
                    textBox_FamilyAddress.Text = exist_Family.get_address();
                }
            }
        }

        private void button_UpdateFamily_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                makeLabelsErrorInvisible();
                exist_Family.set_firstName(this.textBox_FamilyFirstName.Text);
                exist_Family.set_lastName(this.textBox_FamilyLastName.Text);
                exist_Family.set_address(this.textBox_FamilyAddress.Text);
                exist_Family.set_phoneNumber(this.textBox_FamilyPhoneNumber.Text);
                exist_Family.UpdateFamiliesRepresentatives();

                UpdateDeleteFamilyRepresentative em = new UpdateDeleteFamilyRepresentative(this.employee);
                em.Show();
                this.Close();
            }
        }

        private void button_DeleteFamily_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                makeLabelsErrorInvisible();
                exist_Family.Delete_Family();

                UpdateDeleteFamilyRepresentative em = new UpdateDeleteFamilyRepresentative(this.employee);
                em.Show();
                this.Hide();
            }
        }

        private void button_ReturnToEmployeeManage_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeCRUD em = new DonatedFamilyRepresentativeCRUD(this.employee);
            em.Show();
            this.Close();
        }

        private bool checkIdInput()
        {
            bool properIdText = textBox_FamilyId.Text.All(char.IsDigit);
            bool properIdLength = textBox_FamilyId.TextLength == 9;
            bool emptyId = textBox_FamilyId.Text == "";
            if (emptyId || !properIdText || !properIdLength)
            {
                MessageBox.Show("קלט לא תקין");
                if (emptyId)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס ערך";
                }
                else if (!properIdText)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (!properIdLength)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorFamilyId.Visible = true;
                return false;
            }
            else
            {
                if (Program.seekFamily(textBox_FamilyId.Text) == null)
                {
                    label_ErrorFamilyId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorFamilyId.Visible = true;
                    return false;
                }
                else if (!Program.seekFamily(textBox_FamilyId.Text).get_isActive())
                {
                    label_ErrorFamilyId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorFamilyId.Visible = true;
                    return false;
                }
                else
                {
                    label_ErrorFamilyId.Visible = false;
                    return true;
                }
            }
        }
        private bool checkInput()
        {
            bool properIdText = !textBox_FamilyId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_FamilyId.TextLength == 9);
            bool emptyId = textBox_FamilyId.Text == "";

            // checking first name value
            string name = textBox_FamilyFirstName.Text.Replace(" ", "");
            bool properFirstNameText = !name.All(char.IsLetter);
            bool emptyFirstName = textBox_FamilyFirstName.Text == "";

            // checking last name value
            name = textBox_FamilyLastName.Text.Replace(" ", "");
            bool properLastNameText = !name.All(char.IsLetter);
            bool emptyLastName = textBox_FamilyLastName.Text == "";


            // checking phone value
            bool properPhoneText = !textBox_FamilyPhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_FamilyPhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_FamilyPhoneNumber.Text == "";

            // checking address value
            bool emptyAddress = textBox_FamilyAddress.Text == "";


            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorFamilyId.Visible = true;
            }
            else
            {
                if (Program.seekFamily(textBox_FamilyId.Text) != null)
                {
                    label_ErrorFamilyId.Text = "תעודת הזהות כבר קיימת במערכת";
                }
                else
                {
                    label_ErrorFamilyId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorFamilyFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorFamilyFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorFamilyFirstName.Visible = true;
            }
            else
            {
                label_ErrorFamilyFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorFamilyLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorFamilyLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorFamilyLastName.Visible = true;
            }
            else
            {
                label_ErrorFamilyLastName.Visible = false;
            }

            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorFamilyPhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorFamilyPhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorFamilyPhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorFamilyPhone.Visible = true;
            }
            else
            {
                label_ErrorFamilyPhone.Visible = false;
            }
            if (emptyAddress)
            {
                label_ErrorFamilyAddress.Text = "בבקשה הכנס ערך";
                label_ErrorFamilyAddress.Visible = true;
            }
            else
            {
                label_ErrorFamilyAddress.Visible = false;
            }

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properPhoneText || properPhoneLength || emptyPhone || emptyAddress)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }
        private void makeLabelsErrorInvisible()
        {
            label_ErrorFamilyId.Visible = false;
            label_ErrorFamilyFirstName.Visible = false;
            label_ErrorFamilyLastName.Visible = false;
            label_ErrorFamilyPhone.Visible = false;
            label_ErrorFamilyAddress.Visible = false;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
    }
}
