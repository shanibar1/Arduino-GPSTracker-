﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeWaitingRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWaiting = new System.Windows.Forms.Label();
            this.pictureBoxWaiting = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWaiting)).BeginInit();
            this.SuspendLayout();
            // 
            // labelWaiting
            // 
            this.labelWaiting.AutoSize = true;
            this.labelWaiting.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.labelWaiting.ForeColor = System.Drawing.Color.Teal;
            this.labelWaiting.Location = new System.Drawing.Point(193, 89);
            this.labelWaiting.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelWaiting.Name = "labelWaiting";
            this.labelWaiting.Size = new System.Drawing.Size(198, 26);
            this.labelWaiting.TabIndex = 1;
            this.labelWaiting.Text = "המתן למציאת חבילה";
            // 
            // pictureBoxWaiting
            // 
            this.pictureBoxWaiting.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxWaiting.Image = global::WindowsFormsApplicationGUIuARM.Properties.Resources.loading_slow_net;
            this.pictureBoxWaiting.Location = new System.Drawing.Point(184, 118);
            this.pictureBoxWaiting.Name = "pictureBoxWaiting";
            this.pictureBoxWaiting.Size = new System.Drawing.Size(207, 208);
            this.pictureBoxWaiting.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxWaiting.TabIndex = 2;
            this.pictureBoxWaiting.TabStop = false;
            // 
            // DonatedFamilyRepresentativeWaitingRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.pictureBoxWaiting);
            this.Controls.Add(this.labelWaiting);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "DonatedFamilyRepresentativeWaitingRoom";
            this.Text = "מסך המתנה";
            this.Load += new System.EventHandler(this.DonatedFamilyRepresentativeWaitingRoom_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWaiting)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelWaiting;
        private System.Windows.Forms.PictureBox pictureBoxWaiting;
    }
}