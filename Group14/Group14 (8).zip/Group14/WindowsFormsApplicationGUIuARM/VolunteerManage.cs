﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class VolunteerManage : Form
    {
        private Volunteer volunteer;
        public VolunteerManage(Volunteer v)
        {
            InitializeComponent();

            this.volunteer = v;
            this.labelWelcome.Text = "!" + "שלום" + " " + volunteer.get_volunteerFirstName(); // עברית

        }
        private void button_return_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }

        private void button_register_Click(object sender, EventArgs e)
        {
            RegistrationToEvent vsi = new RegistrationToEvent(volunteer);
            vsi.Show();
            this.Hide();
        }

        private void button_watchEvents_Click(object sender, EventArgs e)
        {
            WatchDeleteRegistrations wdr = new WatchDeleteRegistrations(volunteer);
            wdr.Show();
            this.Hide();
        }
    }
}
