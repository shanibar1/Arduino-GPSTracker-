﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Group14
{
    public partial class DonatedFamilyRepresentativeCRUD : Form
    {
        private Employee employee;
        public DonatedFamilyRepresentativeCRUD(Employee e)
        {
            InitializeComponent();
            this.employee = e;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button_ReturnToEmployeeManage_Click(object sender, EventArgs e)
        {
            EmployeeManage em = new EmployeeManage(this.employee);
            em.Show();
            this.Hide();
        }

        private void button_WatchExistFamily_Click(object sender, EventArgs e)
        {
            UpdateDeleteFamilyRepresentative upF = new UpdateDeleteFamilyRepresentative(this.employee);
            upF.Show();
            this.Hide();
        }

        private void button_CreateNewFamily_Click(object sender, EventArgs e)
        {
            CreateFamilyRepresentative cF = new CreateFamilyRepresentative(this.employee);
            cF.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            UpdateDeleteFamilyRepresentative upF = new UpdateDeleteFamilyRepresentative(this.employee);
            upF.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            CreateFamilyRepresentative cF = new CreateFamilyRepresentative(this.employee);
            cF.Show();
            this.Hide();
        }
    }
}
