﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Group14
{
    public partial class CreateFamilyRepresentative : Form
    {
        private Employee employee;
        public CreateFamilyRepresentative(Employee e)
        {
            InitializeComponent();
            makeLabelsErrorInvisible();
            this.employee = e;
        }
        private void button_AddNewFamily_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                DonatedFamilyRepresentative dfrm = Program.seekFamily(textBox_FamilyId.Text);
                if (dfrm == null)
                {
                    DonatedFamilyRepresentative dfr = new DonatedFamilyRepresentative(this.textBox_FamilyId.Text, this.textBox_FamilyAddress.Text, this.textBox_FamilyFirstName.Text,
                        this.textBox_FamilyLastName.Text, this.textBox_FamilyPhoneNumber.Text, true, true); //יצירת משפחה חדשה

                    CreateFamilyRepresentative em = new CreateFamilyRepresentative(this.employee);
                    em.Show();
                    this.Close();
                }
                else
                {
                    dfrm.set_firstName(this.textBox_FamilyFirstName.Text);
                    dfrm.set_lastName(this.textBox_FamilyLastName.Text);
                    dfrm.set_address(this.textBox_FamilyAddress.Text);
                    dfrm.set_phoneNumber(this.textBox_FamilyPhoneNumber.Text);
                    dfrm.set_isActive(true);
                    dfrm.UpdateFamiliesRepresentatives();
                    CreateFamilyRepresentative em = new CreateFamilyRepresentative(this.employee);
                    em.Show();
                    this.Close();
                }
            }
        }

        private void button_ReturnToEmployeeManage_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeCRUD em = new DonatedFamilyRepresentativeCRUD(this.employee);
            em.Show();
            this.Close();
        }

        private bool checkInput()
        {
            // checking id value
            bool properIdText = !textBox_FamilyId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_FamilyId.TextLength == 9);
            bool emptyId = textBox_FamilyId.Text == "";

            // checking first name value
            string name = textBox_FamilyFirstName.Text.Replace(" ", "");
            bool properFirstNameText = !name.All(char.IsLetter);
            bool emptyFirstName = textBox_FamilyFirstName.Text == "";

            // checking last name value
            name = textBox_FamilyLastName.Text.Replace(" ", "");
            bool properLastNameText = !name.All(char.IsLetter);
            bool emptyLastName = textBox_FamilyLastName.Text == "";

          
            // checking phone value
            bool properPhoneText = !textBox_FamilyPhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_FamilyPhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_FamilyPhoneNumber.Text == "";

            // checking address value
            bool emptyAddress = textBox_FamilyAddress.Text == "";
            

            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorFamilyId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorFamilyId.Visible = true;
            }
            else
            {
                if (Program.seekFamily(textBox_FamilyId.Text) != null)
                {
                    if (Program.seekFamily(textBox_FamilyId.Text).get_isActive())
                    {
                        label_ErrorFamilyId.Text = "תעודת הזהות כבר קיימת במערכת";
                        label_ErrorFamilyId.Visible = true;
                      
                    }
                }
                else
                {
                    label_ErrorFamilyId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorFamilyFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorFamilyFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorFamilyFirstName.Visible = true;
            }
            else
            {
                label_ErrorFamilyFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorFamilyLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorFamilyLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorFamilyLastName.Visible = true;
            }
            else
            {
                label_ErrorFamilyLastName.Visible = false;
            }
         
          
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorFamilyPhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorFamilyPhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorFamilyPhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorFamilyPhone.Visible = true;
            }
            else
            {
                label_ErrorFamilyPhone.Visible = false;
            }
            if (emptyAddress)
            {
                label_ErrorFamilyAddress.Text = "בבקשה הכנס ערך";
                label_ErrorFamilyAddress.Visible = true;
            }
            else
            {
                label_ErrorFamilyAddress.Visible = false;
            }

            if (label_ErrorFamilyId.Visible ||  properFirstNameText || emptyFirstName || properLastNameText || emptyLastName  || properPhoneText || properPhoneLength || emptyPhone || emptyAddress)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorFamilyId.Visible = false;
            label_ErrorFamilyFirstName.Visible = false;
            label_ErrorFamilyLastName.Visible = false;
            label_ErrorFamilyPhone.Visible = false;
            label_ErrorFamilyAddress.Visible = false;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
    }
}
