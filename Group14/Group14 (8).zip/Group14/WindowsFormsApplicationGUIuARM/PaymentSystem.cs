using System;

namespace Group14
{

    public interface PaymentSystem
    {
    }
}
