﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class EmployeeCRUD : Form
    {
        private Employee employee;
        public EmployeeCRUD(Employee e)
        {
            InitializeComponent();
            this.employee = e;
        }

        private void button_WatchExistEmployee_Click(object sender, EventArgs e)
        {
            UpdateDeleteEmployee upE = new UpdateDeleteEmployee(this.employee);
            upE.Show();
            this.Hide();
        }
        private void button_CreateNewEmployee_Click(object sender, EventArgs e)
        {
            CreateEmployee cE = new CreateEmployee(this.employee);
            cE.Show();
            this.Hide();
        }

        private void button_ReturnToEmployeeManage_Click(object sender, EventArgs e)
        {
            EmployeeManage em = new EmployeeManage(this.employee);
            em.Show();
            this.Hide();
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            UpdateDeleteEmployee upE = new UpdateDeleteEmployee(this.employee);
            upE.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            CreateEmployee cE = new CreateEmployee(this.employee);
            cE.Show();
            this.Hide();
        }
    }
}
