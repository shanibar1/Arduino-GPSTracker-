﻿using WindowsFormsApplicationGUIuARM;

namespace Group14
{
    partial class ReadItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReadItems));
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sAD14DataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sAD_14DataSet1 = new WindowsFormsApplicationGUIuARM.SAD_14DataSet();
            this.foodItemsTableAdapter1 = new WindowsFormsApplicationGUIuARM.SAD_14DataSetTableAdapters.FoodItemsTableAdapter();
            this.bindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.buttonReturnToItemCrud = new System.Windows.Forms.Button();
            this.updateItem = new System.Windows.Forms.Button();
            this.addItem = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD14DataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD_14DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewCheckBoxColumn1});
            this.dataGridView2.DataSource = this.bindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(398, 261);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(584, 196);
            this.dataGridView2.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "foodId";
            this.dataGridViewTextBoxColumn1.HeaderText = "food Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "UnitsInStock";
            this.dataGridViewTextBoxColumn3.HeaderText = "Units In Stock";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ExpiredDate";
            this.dataGridViewTextBoxColumn4.HeaderText = "Expired Date";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "IsInStock";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Is In Stock";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "FoodItems";
            this.bindingSource1.DataSource = this.sAD14DataSet1BindingSource;
            // 
            // sAD14DataSet1BindingSource
            // 
            this.sAD14DataSet1BindingSource.DataSource = this.sAD_14DataSet1;
            this.sAD14DataSet1BindingSource.Position = 0;
            this.sAD14DataSet1BindingSource.CurrentChanged += new System.EventHandler(this.sAD14DataSet1BindingSource_CurrentChanged);
            // 
            // sAD_14DataSet1
            // 
            this.sAD_14DataSet1.DataSetName = "SAD_14DataSet";
            this.sAD_14DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodItemsTableAdapter1
            // 
            this.foodItemsTableAdapter1.ClearBeforeFill = true;
            // 
            // bindingSource2
            // 
            this.bindingSource2.DataMember = "FoodItems";
            this.bindingSource2.DataSource = this.sAD14DataSet1BindingSource;
            // 
            // bindingSource3
            // 
            this.bindingSource3.DataMember = "FoodItems";
            this.bindingSource3.DataSource = this.sAD14DataSet1BindingSource;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(479, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(593, 63);
            this.label5.TabIndex = 5;
            this.label5.Text = "צפיה ברשימת הפריטים";
            // 
            // buttonReturnToItemCrud
            // 
            this.buttonReturnToItemCrud.BackColor = System.Drawing.Color.Gray;
            this.buttonReturnToItemCrud.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.buttonReturnToItemCrud.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonReturnToItemCrud.Location = new System.Drawing.Point(0, 261);
            this.buttonReturnToItemCrud.Name = "buttonReturnToItemCrud";
            this.buttonReturnToItemCrud.Size = new System.Drawing.Size(235, 69);
            this.buttonReturnToItemCrud.TabIndex = 6;
            this.buttonReturnToItemCrud.Text = "חזור";
            this.buttonReturnToItemCrud.UseVisualStyleBackColor = false;
            this.buttonReturnToItemCrud.Click += new System.EventHandler(this.buttonReturnToItemCrud_Click);
            // 
            // updateItem
            // 
            this.updateItem.BackColor = System.Drawing.Color.Gray;
            this.updateItem.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.updateItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.updateItem.Location = new System.Drawing.Point(0, 86);
            this.updateItem.Name = "updateItem";
            this.updateItem.Size = new System.Drawing.Size(235, 63);
            this.updateItem.TabIndex = 36;
            this.updateItem.Text = "עדכון מוצר קיים";
            this.updateItem.UseVisualStyleBackColor = false;
            this.updateItem.Click += new System.EventHandler(this.updateItem_Click);
            // 
            // addItem
            // 
            this.addItem.BackColor = System.Drawing.Color.Gray;
            this.addItem.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.addItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addItem.Location = new System.Drawing.Point(0, 173);
            this.addItem.Name = "addItem";
            this.addItem.Size = new System.Drawing.Size(235, 65);
            this.addItem.TabIndex = 35;
            this.addItem.Text = "הוספת מוצר חדש";
            this.addItem.UseVisualStyleBackColor = false;
            this.addItem.Click += new System.EventHandler(this.addItem_Click);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.Black;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(235, 525);
            this.splitter1.TabIndex = 37;
            this.splitter1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(241, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(186, 167);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 38;
            this.pictureBox4.TabStop = false;
            // 
            // ReadItems
            // 
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1111, 525);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.updateItem);
            this.Controls.Add(this.addItem);
            this.Controls.Add(this.buttonReturnToItemCrud);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.splitter1);
            this.Name = "ReadItems";
            this.Text = "רשימת הפריטים במלאי";
            this.Load += new System.EventHandler(this.readItems_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD14DataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD_14DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_SearchFromList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox_searchByName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource sAD14DataSetBindingSource;
        private SAD_14DataSet sAD_14DataSet;
        private System.Windows.Forms.BindingSource foodItemsBindingSource;
        private WindowsFormsApplicationGUIuARM.SAD_14DataSetTableAdapters.FoodItemsTableAdapter foodItemsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitsInStockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expiredDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isInStockDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource sAD14DataSet1BindingSource;
        private SAD_14DataSet sAD_14DataSet1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private WindowsFormsApplicationGUIuARM.SAD_14DataSetTableAdapters.FoodItemsTableAdapter foodItemsTableAdapter1;
        private System.Windows.Forms.BindingSource bindingSource2;
        private System.Windows.Forms.BindingSource bindingSource3;
        private System.Windows.Forms.Label label5;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button buttonReturnToItemCrud;
        private System.Windows.Forms.Button updateItem;
        private System.Windows.Forms.Button addItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}