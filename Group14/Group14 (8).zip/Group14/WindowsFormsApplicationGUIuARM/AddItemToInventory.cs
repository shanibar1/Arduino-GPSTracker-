﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class AddItemToInventory : Form
    {
        private Employee employee;
        public AddItemToInventory(Employee employee)
        {
            InitializeComponent();
            label1.Visible = false;
            this.employee = employee;
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            ReadItems r = new ReadItems(employee);
            r.Show();
            this.Hide();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                if (!checkDetails(tx_name.Text, dateTimePicker1.Value))
                {

                    DateTime date = dateTimePicker1.Value;
                    FoodItem f = new FoodItem(randomFunId(), tx_name.Text.ToString(), Convert.ToInt32(num_quan.Value), date.Date, true, true);
                    Program.FoodItems.Add(f);
                    ReadItems r = new ReadItems(employee);
                    r.Show();
                    this.Hide();
                    ReadItems rr = new ReadItems(employee);
                    rr.Show();
                    rr.Hide();
                }
            }
        }
        public Boolean checkInput()
        {
            label1.Visible = false;
            bool properNameText = !tx_name.Text.All(char.IsLetter);
            bool emptyName = tx_name.Text == "";

            if (properNameText || emptyName)
            {
                if (emptyName)

                    label1.Text = "בבקשה הכנס ערך";

                else if (properNameText)
                    label1.Text = "בבקשה הכנס קלט לא מספרי";
                label1.Visible = true;
                if (properNameText || emptyName)
                {
                    MessageBox.Show("קלט לא תקין");
                    return false;
                }

            }
            return true;
        }
        public string randomFunId()
        {
            Random random = new Random();
            return "F" + random.Next(100000, 1000000);
        }


        private bool checkDetails(string itemName, DateTime expirydate)
        {
            foreach (FoodItem f in Program.FoodItems)
            {
                bool name = f.GetItemName().Equals(itemName);
                DateTime x = f.GetExpiredDate().Date;
                DateTime y = expirydate.Date;
                string a = x.Date.ToString("dd/MM/yyyy");
                string b = y.Date.ToString("dd/MM/yyyy");
                bool date = (a.Equals(b));
                if (name && date)
                {
                    f.addUnitsToStock(Convert.ToInt32(num_quan.Value));
                    ReadItems r = new ReadItems(employee);
                    r.Show();
                    this.Hide();
                    return true;
                }

            }
            return false;
        }
    }
}
