﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//חשוב!

namespace Group14
{
    public partial class WatchDeleteRegistrations : Form
    {
        SqlConnection con = new SqlConnection("Data Source = IEMDBS; Initial Catalog = SAD_14; Integrated Security = True");
       private  Volunteer v;
        public WatchDeleteRegistrations(Volunteer v)
        {
            InitializeComponent();
            this.v = v;
        }




        private void WatchDeleteRegistrations_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sAD_14DataSet.Events' table. You can move, or remove it, as needed.
            grid();
        }
        private void grid()
        {
            string query = "SELECT  eventId, employeeId_Employees, Address, Name, Date, startTime, endTime, Status FROM dbo.Events WHERE(Date >= GETDATE()) AND(eventId IN (SELECT eventId_Events FROM   dbo.Registrations  WHERE(volunteerId_Volunteers = "+ v.get_volunteerId()+") AND(registered = 1)))";
           
            SqlDataAdapter dba = new SqlDataAdapter(query, con);

            SqlCommandBuilder gridTable = new SqlCommandBuilder(dba);
            var ds = new DataSet();
            dba.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }

        public void Remove_Registration_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection rtd = dataGridView1.SelectedRows;
            foreach ( DataGridViewRow row in rtd)
            {
                string eventid = row.Cells["eventId"].Value.ToString();
                Event ev = Program.seekEvent(eventid);
               v.unregistrar(ev);
            }
                MessageBox.Show("ההרשמה הוסרה בהצלחה");

                WatchDeleteRegistrations rtE = new WatchDeleteRegistrations(v);
                rtE.Show();
                this.Hide();

            
        }

        private void button_return_Click(object sender, EventArgs e)
        {
            VolunteerManage hp = new VolunteerManage(this.v);
            hp.Show();
            this.Hide();
        }
    }
}
