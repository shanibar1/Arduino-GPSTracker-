using System;
using System.ComponentModel;

namespace Group14
{
    public enum StorageType
    {
        [Description("Dry Food")] DryFood,
        [Description("Beverages")] Beverages,
    }
}