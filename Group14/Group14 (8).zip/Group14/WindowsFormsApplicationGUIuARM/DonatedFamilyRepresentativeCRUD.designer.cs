﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DonatedFamilyRepresentativeCRUD));
            this.button_Exit = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.button_CreateNewFamily = new System.Windows.Forms.Button();
            this.button_WatchExistFamily = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button_Exit
            // 
            this.button_Exit.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(1051, 581);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 9;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.Color.Gray;
            this.button_ReturnToEmployeeManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 321);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(314, 88);
            this.button_ReturnToEmployeeManage.TabIndex = 8;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // button_CreateNewFamily
            // 
            this.button_CreateNewFamily.BackColor = System.Drawing.Color.LightCoral;
            this.button_CreateNewFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_CreateNewFamily.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_CreateNewFamily.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_CreateNewFamily.Location = new System.Drawing.Point(782, 411);
            this.button_CreateNewFamily.Name = "button_CreateNewFamily";
            this.button_CreateNewFamily.Size = new System.Drawing.Size(269, 88);
            this.button_CreateNewFamily.TabIndex = 7;
            this.button_CreateNewFamily.Text = "צור משפחה חדשה";
            this.button_CreateNewFamily.UseVisualStyleBackColor = false;
            this.button_CreateNewFamily.Click += new System.EventHandler(this.button_CreateNewFamily_Click);
            // 
            // button_WatchExistFamily
            // 
            this.button_WatchExistFamily.BackColor = System.Drawing.Color.LightCoral;
            this.button_WatchExistFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WatchExistFamily.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_WatchExistFamily.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_WatchExistFamily.Location = new System.Drawing.Point(402, 411);
            this.button_WatchExistFamily.Name = "button_WatchExistFamily";
            this.button_WatchExistFamily.Size = new System.Drawing.Size(269, 88);
            this.button_WatchExistFamily.TabIndex = 6;
            this.button_WatchExistFamily.Text = "צפה במשפחה קיימת";
            this.button_WatchExistFamily.UseVisualStyleBackColor = false;
            this.button_WatchExistFamily.Click += new System.EventHandler(this.button_WatchExistFamily_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(575, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(563, 63);
            this.label1.TabIndex = 5;
            this.label1.Text = "ניהול משפחות נתרמות";
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.Black;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(314, 616);
            this.splitter1.TabIndex = 10;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(314, 265);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(437, 180);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(186, 167);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 20;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(819, 180);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(186, 167);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // DonatedFamilyRepresentativeCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1138, 616);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.button_ReturnToEmployeeManage);
            this.Controls.Add(this.button_CreateNewFamily);
            this.Controls.Add(this.button_WatchExistFamily);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.splitter1);
            this.Name = "DonatedFamilyRepresentativeCRUD";
            this.Text = "ניהול משפחות נתרמות";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.Button button_CreateNewFamily;
        private System.Windows.Forms.Button button_WatchExistFamily;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}