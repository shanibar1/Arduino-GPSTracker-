using System;
using System.Data.SqlClient;

namespace Group14
{
    public class Vendor
    {
        private string vendorId;
        private string vendorFirstName;
        private string vendorLastName;
        private string vendorMail;
        private string vendorPhone;
        private bool isActive;

        public Vendor(string vendorId, string vendorFirstName, string vendorLastName, string vendorMail, string vendorPhone, bool isActive, bool is_new)
        {
            this.vendorId = vendorId;
            this.vendorFirstName = vendorFirstName;
            this.vendorLastName = vendorLastName;
            this.vendorMail = vendorMail;
            this.vendorPhone = vendorPhone;
            this.isActive = isActive;
            if (is_new)
            {
                this.CreateVendor();
                Program.Vendors.Add(this);
            }
        }

        private void CreateVendor()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Vendor @Id, @firstName, @lastName, @Email, @Phone, @isActive";
            c.Parameters.AddWithValue("@Id", this.vendorId);
            c.Parameters.AddWithValue("@firstName", this.vendorFirstName);
            c.Parameters.AddWithValue("@lastName", this.vendorLastName);
            c.Parameters.AddWithValue("@Email", this.vendorMail);
            c.Parameters.AddWithValue("@Phone", this.vendorPhone);
            c.Parameters.AddWithValue("@isActive", this.isActive);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        internal string GetName()
        {
            return this.vendorFirstName + " " + vendorLastName;
        }

        public void setIsActive(bool v)
        {
            isActive = v;
        }

        public void Delete_Vendor()
        {
            isActive = false;
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE  [dbo].[DeleteVendor] @vendorId";
            c.Parameters.AddWithValue("@vendorId", vendorId);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }
        public void UpdateVendor()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.UpdateVendor @Id, @firstName, @lastName, @Email, @Phone, @isActive";
            c.Parameters.AddWithValue("@Id", this.vendorId);
            c.Parameters.AddWithValue("@firstName", this.vendorFirstName);
            c.Parameters.AddWithValue("@lastName", this.vendorLastName);
            c.Parameters.AddWithValue("@Email", this.vendorMail);
            c.Parameters.AddWithValue("@Phone", this.vendorPhone);
            c.Parameters.AddWithValue("@isActive", this.isActive);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }


        public string GetId()
        {
            return this.vendorId;
        }

        public string GetFirstName()
        {
            return this.vendorFirstName;
        }
        public string GetLastName()
        {
            return this.vendorLastName;

        }

        public string GetMail()
        {
            return this.vendorMail;
        }

        public string GetPhone()
        {
            return this.vendorPhone;
        }

        internal void set_VendorLastName(string lastname)
        {
            vendorLastName = lastname;
        }

        internal void set_VendorPhone(string phone)
        {
            vendorPhone = phone;

        }
        public Boolean GetIsActive()
        {
            return isActive;
        }

        internal void set_VendorMail(string mail)
        {
            vendorMail = mail;
        }
        internal void set_VendorFirstName(string firstname)
        {
            vendorFirstName = firstname;
        }
    }
}
