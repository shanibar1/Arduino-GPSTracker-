using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace Group14
{
    public class Event {
        private string eventId;
        private string employeeId_Employees;
        private string Address;
        private string Name;
        private DateTime Date;
        private DateTime startTime;
        private DateTime endTime;
        private EventStatus Status;
        private List<Volunteer> volunteers;
        private List<RegistrationForEvent> registrations;


        public Event(string eventId, string employeeId_Employees, string Address, string Name, DateTime Date, DateTime startTime, DateTime endTime, EventStatus Status, bool is_new)
        {
            this.registrations = new List<RegistrationForEvent>();
            this.eventId = eventId;
            this.employeeId_Employees = employeeId_Employees;
            this.Address = Address;
            this.Name = Name;
            this.Date = Date;
            this.startTime = startTime;
            this.endTime = endTime;
            this.Status = Status;
            if (is_new)
            {
                this.CreateEvent();
                Program.Events.Add(this);
            }
            Employee e = Program.seekEmployee(employeeId_Employees);
            this.updatePackages(e);
        }
        public Event()
        {
        }
        public void CreateEvent()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Event @eventId, @employeeId_Employees, @Address, @Name, @Date, @startTime, @endTime, @Status";
            c.Parameters.AddWithValue("@eventId", this.eventId);
            c.Parameters.AddWithValue("@employeeId_Employees", this.employeeId_Employees);
            c.Parameters.AddWithValue("@Address", this.Address);
            c.Parameters.AddWithValue("@Name", this.Name);
            c.Parameters.AddWithValue("@Date", this.Date);
            c.Parameters.AddWithValue("@startTime", this.startTime);
            c.Parameters.AddWithValue("@endTime", this.endTime);
            c.Parameters.AddWithValue("@Status", this.Status.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void UpdateEvent()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.UpdateEvent @eventId, @employeeId_Employees, @Address, @Name, @Date, @startTime, @endTime, @Status";
            c.Parameters.AddWithValue("@eventId", this.eventId);
            c.Parameters.AddWithValue("@employeeId_Employees", this.employeeId_Employees);
            c.Parameters.AddWithValue("@Address", this.Address);
            c.Parameters.AddWithValue("@Name", this.Name);
            c.Parameters.AddWithValue("@Date", this.Date);
            c.Parameters.AddWithValue("@startTime", this.startTime);
            c.Parameters.AddWithValue("@endTime", this.endTime);
            c.Parameters.AddWithValue("@Status", this.Status.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Event()
        {
        
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.DeleteEvent @eventId";
            c.Parameters.AddWithValue("@eventId", this.eventId);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
            Status = EventStatus.canceled;
        }

        public string CreateEventId()
        {
            string digits = "0123456789";

            Random random = new Random();
            StringBuilder catalogNumber = new StringBuilder();

            for (int i = 0; i < 8; i++)
            {
                int randomIndex = random.Next(0, digits.Length);
                catalogNumber.Append(digits[randomIndex]);
            }
            foreach(Event e in Program.Events)
            {
                if(catalogNumber.ToString().Equals(e.GetEventId()))
                    CreateEventId();
            }
            return catalogNumber.ToString();
        }

        public string GetEventId()
        {
            return this.eventId;
        }

        public void SetEventId(string eventId)
        {
            this.eventId = eventId;
        }

        public string GetEmployeeId()
        {
            return this.employeeId_Employees;
        }

        public bool isRegistered(Volunteer volunteer)
        {
            foreach(Volunteer v in this.volunteers)
            {
                if (v.get_volunteerId().Equals(volunteer.get_volunteerId()))
                    return true;
            }
            return false;
        }

        public void SetEmployeeId(string employeeId)
        {
            this.employeeId_Employees = employeeId;
        }

        public string GetAddress()
        {
            return this.Address;
        }

        public void SetAddress(string address)
        {
            this.Address = address;
        }

        public string GetName()
        {
            return this.Name;
        }

        public void SetName(string name)
        {
            this.Name = name;
        }

        public DateTime GetDate()
        {
            return this.Date;
        }

        public void SetDate(DateTime date)
        {
            this.Date = date;
        }

        public DateTime GetStartTime()
        {
            return this.startTime;
        }

        public void SetStartTime(DateTime startTime)
        {
            this.startTime = startTime;
        }

        public DateTime GetEndTime()
        {
            return this.endTime;
        }

        public void SetEndTime(DateTime endTime)
        {
            this.endTime = endTime;
        }

        public EventStatus GetStatus()
        {
            return this.Status;
        }

        public void SetStatus(EventStatus status)
        {
            this.Status = status;
        }

        public void addRegistration(RegistrationForEvent a)
        {
            registrations.Add(a);
        }
        public List<Volunteer> getVolunteers()
        {
            List<Volunteer> vol = new List<Volunteer>();
            if(this.registrations == null)
                return null;
            foreach (RegistrationForEvent r in this.registrations)
            {
                if (r.GetRegistered())
                    vol.Add(r.GetVolunteer());
            }
            return vol;


        }
        private void updatePackages(Employee e)
        {
            DateTime dt = this.GetDate();
            if (this.GetDate() == DateTime.Today)
            {
                int numDrivers;
                using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
                {
                    conn.Open();
                    string query = @"
                                    SELECT COUNT(*)
                                    FROM Events JOIN Registrations ON Events.eventId = Registrations.eventId_Events JOIN Volunteers ON Registrations.volunteerId_Volunteers = Volunteers.volunteerId 
                                    WHERE Volunteers.[Type] = 'Driver' AND Registrations.registered = 1 AND Registrations.eventId_Events = @eventId";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@eventId", this.eventId);

                        object result = command.ExecuteScalar();
                        numDrivers =  Convert.ToInt32(result);
                    }
                }
                int numFamilies = Program.DonatedFamilyRepresentatives.Count;
                int index = 0;
                DonatedFamilyRepresentative[] families = Program.DonatedFamilyRepresentatives.ToArray();
                if (numDrivers != 0)
                {
                      int numOfDeliveries = (int)(numFamilies / numDrivers);
                    int spare = numFamilies % numDrivers;
                    numOfDeliveries += spare;
                    foreach (Volunteer v in getVolunteers())
                    {
                        if (v.get_volunteerRole().Equals("Driver"))
                        {
                            for (int i = 0; i < numOfDeliveries; i++)
                            {
                                v.Deliver(families[index], this);
                                index++;
                            }

                        }
                    }
                }
            }
        }
    }
}