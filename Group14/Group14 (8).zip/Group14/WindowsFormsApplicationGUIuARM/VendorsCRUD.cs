﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class VendorCRUD : Form
    {
    private Employee employee;
        public VendorCRUD(Employee e)
        {
            InitializeComponent();
            employee = e;
        }

       
        private void button_CreateNewVendor_Click(object sender, EventArgs e)
        {
            CreateVendor cE = new CreateVendor(employee);
            cE.Show();
            this.Hide();
        }

        private void button_ReturnToHomePage_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button_WatchExistVendor_Click(object sender, EventArgs e)
        {
            UpdateDeleteVendor upE = new UpdateDeleteVendor(employee);
            upE.Show();
            this.Hide();
        }
    }
}
