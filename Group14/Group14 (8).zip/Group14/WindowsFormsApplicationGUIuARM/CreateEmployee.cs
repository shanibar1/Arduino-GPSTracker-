﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class CreateEmployee : Form
    {
        private Employee employee;
        public CreateEmployee(Employee e)
        {
            InitializeComponent();
            comboBox_EmployeeRole.DisplayMember = "Description";
            comboBox_EmployeeRole.ValueMember = "Value";
            comboBox_EmployeeRole.DataSource = Enum.GetValues(typeof(EmployeeRole)).Cast<Enum>().Select(value => new
            {(Attribute.GetCustomAttribute(value.GetType().GetField(value.ToString()), typeof(DescriptionAttribute)) as DescriptionAttribute).Description, value }).OrderBy(item => item.value).ToList();
            makeLabelsErrorInvisible();
            this.employee = e;
        }


        private void button_AddNewEmployee_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                Employee empl = Program.seekEmployee(textBox_EmployeeId.Text);
                string s = comboBox_EmployeeRole.Text;
                if (s.IndexOf(" ") != -1)
                    s = s.Remove(s.IndexOf(" "), 1);
                EmployeeRole er = (EmployeeRole)Enum.Parse(typeof(EmployeeRole), s);
                if (empl == null)
                {
                    Employee emp = new Employee(textBox_EmployeeId.Text, textBox_EmployeeFirstName.Text,
                        textBox_EmployeeLastName.Text, textBox_EmployeeMail.Text, textBox_EmployeePhoneNumber.Text, er, true, true);
                    CreateEmployee em = new CreateEmployee(this.employee);
                    em.Show();
                    this.Close();
                }
                else
                {
                    empl.set_employeeFirstName(textBox_EmployeeFirstName.Text);
                    empl.set_employeeLastName(textBox_EmployeeLastName.Text);
                    empl.set_employeeMail(textBox_EmployeeMail.Text);
                    empl.set_employeePhone(textBox_EmployeePhoneNumber.Text);
                    empl.set_employeeRole(er);
                    empl.set_isEmployeeActive(true);
                    empl.UpdateEmployee();
                    CreateEmployee em = new CreateEmployee(this.employee);
                    em.Show();
                    this.Close();
                }
                if (er == EmployeeRole.CEO)
                {
                    Volunteer v;
                    if (Program.seekVolunteer(empl.get_employeeId()) == null)
                        v = new Volunteer(empl.get_employeeId(), empl.get_employeeFirstName(), empl.get_employeeLastName(), empl.get_employeeMail(), empl.get_employeePhone(), true, VolunteerRole.Driver, true, true);
                    else if (!Program.seekVolunteer(empl.get_employeeId()).get_isVolunteerActive())
                        Program.seekVolunteer(empl.get_employeeId()).set_isVolunteerActive(true);
                    else
                    {
                        v = Program.seekVolunteer(empl.get_employeeId());
                        v.set_volunteerFirstName(textBox_EmployeeFirstName.Text);
                        v.set_volunteerLastName(textBox_EmployeeLastName.Text);
                        v.set_volunteerMail(textBox_EmployeeMail.Text);
                        v.set_volunteerPhone(textBox_EmployeePhoneNumber.Text);
                        v.set_volunteerRole(VolunteerRole.Driver);
                        v.set_drivingLicense(true);
                        v.set_isVolunteerActive(true);
                    }
                }
            }
        }

        private void button_ReturnToEmployeeManage_Click(object sender, EventArgs e)
        {
            EmployeeCRUD em = new EmployeeCRUD(this.employee);
            em.Show();
            this.Hide();
        }

        private bool checkInput()
        {
            bool properIdText = !textBox_EmployeeId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_EmployeeId.TextLength == 9);
            bool emptyId = textBox_EmployeeId.Text == "";

            // checking first name value
            string name = textBox_EmployeeFirstName.Text.Replace(" ", "");
            bool properFirstNameText = !name.All(char.IsLetter);
            bool emptyFirstName = textBox_EmployeeFirstName.Text == "";

            // checking last name value
            name = textBox_EmployeeLastName.Text.Replace(" ", "");
            bool properLastNameText = !name.All(char.IsLetter);
            bool emptyLastName = textBox_EmployeeLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_EmployeeMail.Text.Contains('@') || textBox_EmployeeMail.Text.Contains('.'));
            bool properMailLength = !(textBox_EmployeeMail.TextLength >= 5);
            bool emptyMail = textBox_EmployeeMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_EmployeePhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_EmployeePhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_EmployeePhoneNumber.Text == "";

            // checking role value
            bool haveCEO = false;

            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorEmployeeId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorEmployeeId.Visible = true;
            }
            else if (Program.seekEmployee(textBox_EmployeeId.Text) != null)
                {
                    if (Program.seekEmployee(textBox_EmployeeId.Text).get_isEmployeeActive())
                    {
                        label_ErrorEmployeeId.Text = "תעודת הזהות כבר קיימת במערכת";
                    label_ErrorEmployeeId.Visible = true;
                  
                }

                else
                {
                    label_ErrorEmployeeId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorEmployeeFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorEmployeeFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorEmployeeFirstName.Visible = true;
            }
            else
            {
                label_ErrorEmployeeFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorEmployeeLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorEmployeeLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorEmployeeLastName.Visible = true;
            }
            else
            {
                label_ErrorEmployeeLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorEmployeeMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorEmployeeMail.Visible = true;
            }
            else
            {
                label_ErrorEmployeeMail.Visible = false;
            }
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorEmployeePhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorEmployeePhone.Visible = true;
            }
            else
            {
                label_ErrorEmployeePhone.Visible = false;
            }

            if (comboBox_EmployeeRole.SelectedValue.ToString().Equals("CEO"))
            {
                foreach (Employee em in Program.Employees)
                {
                    if (em.get_employeeRole().ToString().Equals("CEO")) // ceo already exists in organization
                        haveCEO = true;
                }
                if (haveCEO)
                {
                    this.label_ErrorEmployeeRole.Text = "כבר קיים מנכ''ל בארגון. בחר תפקיד אחר בבקשה";
                    this.label_ErrorEmployeeRole.Visible = true;
                }
            }
            else
            {
                label_ErrorEmployeeRole.Visible = false;
            }

            if (label_ErrorEmployeeId.Visible || properIdText || properIdLength || emptyId || properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone || haveCEO)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorEmployeeId.Visible = false;
            label_ErrorEmployeeFirstName.Visible = false;
            label_ErrorEmployeeLastName.Visible = false;
            label_ErrorEmployeeMail.Visible = false;
            label_ErrorEmployeePhone.Visible = false;
            label_ErrorEmployeeRole.Visible = false;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
    }
}
