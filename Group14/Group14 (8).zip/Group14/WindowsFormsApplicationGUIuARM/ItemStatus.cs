﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group14
{
    public enum ItemStatus
    {
        [Description("In stock")] InStock,
        [Description("Not in stock")] OutOfStock,
    }
}
