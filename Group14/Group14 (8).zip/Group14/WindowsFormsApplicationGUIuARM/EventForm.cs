﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 

namespace Group14
{
    public partial class EventForm : Form
    {
        List<Event> events;
        private Event new_Event;
        private Employee employee;
        public EventForm(Employee employee)
        {
            InitializeComponent();
            events = Program.Events;
            this.employee = employee;
            fillComboBoxStartTime();
            new_Event = new Event();
            makeLabelsErrorInvisible();
        }

        private void EventForm_Load(object sender, EventArgs e)
        {
            textBox_Date.Text =  UserControlDays.static_day  +"/"+ EventHomePage.static_month + "/" + EventHomePage.static_year ;
        }
        private void makeLabelsErrorInvisible()
        {
            label_ErroremptyEventName.Visible = false;
            label_ErroremptyEventAddress.Visible = false;
            label_ErroremptyStartTime.Visible = false;
        }
        private bool checkInput()
        {
            bool emptyEventName = this.textBox_Event.Text == "";
            bool emptyEventAddress = this.textBox_Address.Text == "";
            bool emptyEventStartTime = this.comboBox_StartTime.SelectedItem == null;

            //print error message
            if (emptyEventName)
            {
                label_ErroremptyEventName.Text = "בבקשה הכנס שם אירוע";
                label_ErroremptyEventName.Visible = true;
            }
            else
                label_ErroremptyEventName.Visible = false;
            if (emptyEventAddress)
            {
                label_ErroremptyEventAddress.Text = "בבקשה הכנס כתובת";
                label_ErroremptyEventAddress.Visible = true;
            }
            else
                label_ErroremptyEventAddress.Visible = false;
            if (emptyEventStartTime)
            {
                label_ErroremptyStartTime.Text = "בבקשה הכנס שעת התחלה";
                label_ErroremptyStartTime.Visible = true;
            }
            else
                label_ErroremptyStartTime.Visible = false;

            if (emptyEventAddress || emptyEventName|| emptyEventStartTime)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;
        }
        private void button_Save_Click(object sender, EventArgs e)
        {
            if (checkInput()) {
                if (!isExist(this.textBox_Address.Text, Convert.ToDateTime(this.textBox_Date.Text)))
                {
                    DateTime dt = Convert.ToDateTime(this.textBox_Date.Text);
                    new_Event = new Event(new_Event.CreateEventId(), employee.get_employeeId(), this.textBox_Address.Text, this.textBox_Event.Text, Convert.ToDateTime(this.textBox_Date.Text), startTime(), endTime(), EventStatus.preperation, true);
                    this.Hide();
                    EventHomePage ev = new EventHomePage(this.employee);
                    ev.Show();
                }
                else
                {
                    MessageBox.Show("אירוע זה כבר קיים במערכת");
                    this.Hide();
                    EventHomePage evh = new EventHomePage(this.employee);
                    evh.Show();
                }
            }
           
        }

        private bool isExist(string address, DateTime date)
        {
          foreach(Event e in events)
            {
                if (e.GetAddress().Equals(address) && e.GetDate().Equals(date)&&!e.GetStatus().Equals(EventStatus.canceled))
                    return true;
            }
            return false;
        }

      
        private void fillComboBoxStartTime()
        {
            for(int i = 10; i <= 19; i++)
            {
                    string display = i + ":00";
                    this.comboBox_StartTime.Items.Add(display);
            }
        }

        private DateTime startTime()
        {
            int hour = Int32.Parse(this.comboBox_StartTime.SelectedItem.ToString().Substring(0, 2));
            return new DateTime(Convert.ToDateTime(this.textBox_Date.Text).Year, Convert.ToDateTime(this.textBox_Date.Text).Month, Convert.ToDateTime(this.textBox_Date.Text).Day, hour, 0, 0);
        }

        private DateTime endTime()
        {
            double hour;
            if (new_Event.getVolunteers() != null)
                hour = 7 / Math.Pow(1.09, Convert.ToDouble(new_Event.getVolunteers().Count));
            else
                hour = 17;
            return new DateTime(Convert.ToDateTime(this.textBox_Date.Text).Year, Convert.ToDateTime(this.textBox_Date.Text).Month, Convert.ToDateTime(this.textBox_Date.Text).Day, Convert.ToInt32(hour), 0, 0);
        }

        private void button_return_Click(object sender, EventArgs e)
        {
            EventHomePage ev = new EventHomePage(this.employee);
            ev.Show();
            this.Hide();
        }
    }
}
