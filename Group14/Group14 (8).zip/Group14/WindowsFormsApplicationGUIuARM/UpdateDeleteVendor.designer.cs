﻿namespace Group14
{
    partial class UpdateDeleteVendor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateDeleteVendor));
            this.label_ErrorVendorId = new System.Windows.Forms.Label();
            this.label_ErrorVendorPhone = new System.Windows.Forms.Label();
            this.label_ErrorVendorMail = new System.Windows.Forms.Label();
            this.label_ErrorVendorLastName = new System.Windows.Forms.Label();
            this.label_ErrorVendorFirstName = new System.Windows.Forms.Label();
            this.textBox_VendorLastName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_VendorPhoneNumber = new System.Windows.Forms.TextBox();
            this.textBox_VendorMail = new System.Windows.Forms.TextBox();
            this.textBox_VendorFirstName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_VendorId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Search = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_Exit = new System.Windows.Forms.Button();
            this.button_ReturnToVendorCRUD = new System.Windows.Forms.Button();
            this.button_DeleteVendor = new System.Windows.Forms.Button();
            this.button_UpdateVendor = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_ErrorVendorId
            // 
            this.label_ErrorVendorId.AutoSize = true;
            this.label_ErrorVendorId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorId.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVendorId.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorId.Location = new System.Drawing.Point(595, 134);
            this.label_ErrorVendorId.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorVendorId.Name = "label_ErrorVendorId";
            this.label_ErrorVendorId.Size = new System.Drawing.Size(77, 13);
            this.label_ErrorVendorId.TabIndex = 41;
            this.label_ErrorVendorId.Text = "קלט ת.ז שגוי";
            // 
            // label_ErrorVendorPhone
            // 
            this.label_ErrorVendorPhone.AutoSize = true;
            this.label_ErrorVendorPhone.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorPhone.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVendorPhone.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorPhone.Location = new System.Drawing.Point(588, 406);
            this.label_ErrorVendorPhone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorVendorPhone.Name = "label_ErrorVendorPhone";
            this.label_ErrorVendorPhone.Size = new System.Drawing.Size(130, 13);
            this.label_ErrorVendorPhone.TabIndex = 40;
            this.label_ErrorVendorPhone.Text = "קלט מספר פלאפון שגוי";
            // 
            // label_ErrorVendorMail
            // 
            this.label_ErrorVendorMail.AutoSize = true;
            this.label_ErrorVendorMail.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorMail.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVendorMail.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorMail.Location = new System.Drawing.Point(588, 352);
            this.label_ErrorVendorMail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorVendorMail.Name = "label_ErrorVendorMail";
            this.label_ErrorVendorMail.Size = new System.Drawing.Size(84, 13);
            this.label_ErrorVendorMail.TabIndex = 39;
            this.label_ErrorVendorMail.Text = "קלט מייל שגוי";
            // 
            // label_ErrorVendorLastName
            // 
            this.label_ErrorVendorLastName.AutoSize = true;
            this.label_ErrorVendorLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorLastName.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVendorLastName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorLastName.Location = new System.Drawing.Point(588, 290);
            this.label_ErrorVendorLastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorVendorLastName.Name = "label_ErrorVendorLastName";
            this.label_ErrorVendorLastName.Size = new System.Drawing.Size(123, 13);
            this.label_ErrorVendorLastName.TabIndex = 38;
            this.label_ErrorVendorLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorVendorFirstName
            // 
            this.label_ErrorVendorFirstName.AutoSize = true;
            this.label_ErrorVendorFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVendorFirstName.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVendorFirstName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorVendorFirstName.Location = new System.Drawing.Point(588, 229);
            this.label_ErrorVendorFirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorVendorFirstName.Name = "label_ErrorVendorFirstName";
            this.label_ErrorVendorFirstName.Size = new System.Drawing.Size(110, 13);
            this.label_ErrorVendorFirstName.TabIndex = 37;
            this.label_ErrorVendorFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // textBox_VendorLastName
            // 
            this.textBox_VendorLastName.Location = new System.Drawing.Point(448, 267);
            this.textBox_VendorLastName.Name = "textBox_VendorLastName";
            this.textBox_VendorLastName.Size = new System.Drawing.Size(243, 20);
            this.textBox_VendorLastName.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(774, 267);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(151, 28);
            this.label6.TabIndex = 35;
            this.label6.Text = ":שם משפחה";
            // 
            // textBox_VendorPhoneNumber
            // 
            this.textBox_VendorPhoneNumber.Location = new System.Drawing.Point(448, 383);
            this.textBox_VendorPhoneNumber.Name = "textBox_VendorPhoneNumber";
            this.textBox_VendorPhoneNumber.Size = new System.Drawing.Size(243, 20);
            this.textBox_VendorPhoneNumber.TabIndex = 30;
            // 
            // textBox_VendorMail
            // 
            this.textBox_VendorMail.Location = new System.Drawing.Point(448, 329);
            this.textBox_VendorMail.Name = "textBox_VendorMail";
            this.textBox_VendorMail.Size = new System.Drawing.Size(243, 20);
            this.textBox_VendorMail.TabIndex = 29;
            // 
            // textBox_VendorFirstName
            // 
            this.textBox_VendorFirstName.Location = new System.Drawing.Point(448, 206);
            this.textBox_VendorFirstName.Name = "textBox_VendorFirstName";
            this.textBox_VendorFirstName.Size = new System.Drawing.Size(243, 20);
            this.textBox_VendorFirstName.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(760, 375);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 28);
            this.label4.TabIndex = 26;
            this.label4.Text = ":מספר פלאפון";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(850, 321);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 28);
            this.label3.TabIndex = 25;
            this.label3.Text = ":מייל";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(800, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 28);
            this.label2.TabIndex = 24;
            this.label2.Text = ":שם פרטי";
            // 
            // textBox_VendorId
            // 
            this.textBox_VendorId.Location = new System.Drawing.Point(448, 114);
            this.textBox_VendorId.Name = "textBox_VendorId";
            this.textBox_VendorId.Size = new System.Drawing.Size(243, 20);
            this.textBox_VendorId.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(721, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 28);
            this.label1.TabIndex = 21;
            this.label1.Text = ":הכנס מזהה ספק";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Dock = System.Windows.Forms.DockStyle.Right;
            this.label7.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(348, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(626, 63);
            this.label7.TabIndex = 48;
            this.label7.Text = ":מלא את הפרטים הבאים";
            // 
            // button_Search
            // 
            this.button_Search.BackColor = System.Drawing.Color.Crimson;
            this.button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Search.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Search.Location = new System.Drawing.Point(338, 99);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(74, 38);
            this.button_Search.TabIndex = 49;
            this.button_Search.Text = "חפש";
            this.button_Search.UseVisualStyleBackColor = false;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.button_DeleteVendor);
            this.panel1.Controls.Add(this.button_UpdateVendor);
            this.panel1.Controls.Add(this.button_Exit);
            this.panel1.Controls.Add(this.button_ReturnToVendorCRUD);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(230, 629);
            this.panel1.TabIndex = 50;
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.Color.Yellow;
            this.button_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Exit.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(0, 502);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(230, 73);
            this.button_Exit.TabIndex = 78;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_ReturnToVendorCRUD
            // 
            this.button_ReturnToVendorCRUD.BackColor = System.Drawing.Color.Yellow;
            this.button_ReturnToVendorCRUD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnToVendorCRUD.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToVendorCRUD.Location = new System.Drawing.Point(0, 394);
            this.button_ReturnToVendorCRUD.Name = "button_ReturnToVendorCRUD";
            this.button_ReturnToVendorCRUD.Size = new System.Drawing.Size(230, 73);
            this.button_ReturnToVendorCRUD.TabIndex = 52;
            this.button_ReturnToVendorCRUD.Text = "חזור";
            this.button_ReturnToVendorCRUD.UseVisualStyleBackColor = false;
            this.button_ReturnToVendorCRUD.Click += new System.EventHandler(this.button_ReturnToVendorCRUD_Click_1);
            // 
            // button_DeleteVendor
            // 
            this.button_DeleteVendor.BackColor = System.Drawing.Color.Yellow;
            this.button_DeleteVendor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_DeleteVendor.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_DeleteVendor.Location = new System.Drawing.Point(0, 278);
            this.button_DeleteVendor.Name = "button_DeleteVendor";
            this.button_DeleteVendor.Size = new System.Drawing.Size(230, 73);
            this.button_DeleteVendor.TabIndex = 79;
            this.button_DeleteVendor.Text = "מחק";
            this.button_DeleteVendor.UseVisualStyleBackColor = false;
            this.button_DeleteVendor.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_UpdateVendor
            // 
            this.button_UpdateVendor.BackColor = System.Drawing.Color.Yellow;
            this.button_UpdateVendor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_UpdateVendor.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_UpdateVendor.Location = new System.Drawing.Point(0, 144);
            this.button_UpdateVendor.Name = "button_UpdateVendor";
            this.button_UpdateVendor.Size = new System.Drawing.Size(230, 73);
            this.button_UpdateVendor.TabIndex = 80;
            this.button_UpdateVendor.Text = "עדכן";
            this.button_UpdateVendor.UseVisualStyleBackColor = false;
            this.button_UpdateVendor.Click += new System.EventHandler(this.button_UpdateVendor_Click_1);
            // 
            // UpdateDeleteVendor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(974, 629);
            this.Controls.Add(this.button_Search);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label_ErrorVendorId);
            this.Controls.Add(this.label_ErrorVendorPhone);
            this.Controls.Add(this.label_ErrorVendorMail);
            this.Controls.Add(this.label_ErrorVendorLastName);
            this.Controls.Add(this.label_ErrorVendorFirstName);
            this.Controls.Add(this.textBox_VendorLastName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_VendorPhoneNumber);
            this.Controls.Add(this.textBox_VendorMail);
            this.Controls.Add(this.textBox_VendorFirstName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_VendorId);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Name = "UpdateDeleteVendor";
            this.Text = "ניהול ספק קיים";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_ErrorVendorId;
        private System.Windows.Forms.Label label_ErrorVendorPhone;
        private System.Windows.Forms.Label label_ErrorVendorMail;
        private System.Windows.Forms.Label label_ErrorVendorLastName;
        private System.Windows.Forms.Label label_ErrorVendorFirstName;
        private System.Windows.Forms.TextBox textBox_VendorLastName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_VendorPhoneNumber;
        private System.Windows.Forms.TextBox textBox_VendorMail;
        private System.Windows.Forms.TextBox textBox_VendorFirstName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_VendorId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_ReturnToVendorCRUD;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Button button_UpdateVendor;
        private System.Windows.Forms.Button button_DeleteVendor;
    }
}