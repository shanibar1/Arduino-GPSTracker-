﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeTrackPackage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.button_PackageTracking = new System.Windows.Forms.Button();
            this.button_CurrentLocation = new System.Windows.Forms.Button();
            this.labelTrackPackage = new System.Windows.Forms.Label();
            this.button_ReturnToManage = new System.Windows.Forms.Button();
            this.gMapControl1 = new GMap.NET.WindowsForms.GMapControl();
            this.button_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(191, 857);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // button_PackageTracking
            // 
            this.button_PackageTracking.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_PackageTracking.Font = new System.Drawing.Font("David", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_PackageTracking.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_PackageTracking.Location = new System.Drawing.Point(0, 194);
            this.button_PackageTracking.Name = "button_PackageTracking";
            this.button_PackageTracking.Size = new System.Drawing.Size(191, 57);
            this.button_PackageTracking.TabIndex = 1;
            this.button_PackageTracking.Text = "מעקב אחר החבילה";
            this.button_PackageTracking.UseVisualStyleBackColor = false;
            this.button_PackageTracking.Click += new System.EventHandler(this.button_PackageTracking_Click);
            // 
            // button_CurrentLocation
            // 
            this.button_CurrentLocation.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_CurrentLocation.Font = new System.Drawing.Font("David", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_CurrentLocation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_CurrentLocation.Location = new System.Drawing.Point(0, 279);
            this.button_CurrentLocation.Name = "button_CurrentLocation";
            this.button_CurrentLocation.Size = new System.Drawing.Size(191, 59);
            this.button_CurrentLocation.TabIndex = 2;
            this.button_CurrentLocation.Text = "מיקום נוכחי";
            this.button_CurrentLocation.UseVisualStyleBackColor = false;
            this.button_CurrentLocation.Click += new System.EventHandler(this.button_CurrentLocation_Click);
            // 
            // labelTrackPackage
            // 
            this.labelTrackPackage.AutoSize = true;
            this.labelTrackPackage.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelTrackPackage.Font = new System.Drawing.Font("David", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.labelTrackPackage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelTrackPackage.Location = new System.Drawing.Point(16, 29);
            this.labelTrackPackage.Name = "labelTrackPackage";
            this.labelTrackPackage.Size = new System.Drawing.Size(153, 20);
            this.labelTrackPackage.TabIndex = 3;
            this.labelTrackPackage.Text = "עקוב אחר החבילה";
            // 
            // button_ReturnToManage
            // 
            this.button_ReturnToManage.Location = new System.Drawing.Point(46, 770);
            this.button_ReturnToManage.Margin = new System.Windows.Forms.Padding(2);
            this.button_ReturnToManage.Name = "button_ReturnToManage";
            this.button_ReturnToManage.Size = new System.Drawing.Size(56, 19);
            this.button_ReturnToManage.TabIndex = 5;
            this.button_ReturnToManage.Text = "חזור";
            this.button_ReturnToManage.UseVisualStyleBackColor = true;
            this.button_ReturnToManage.Click += new System.EventHandler(this.button_ReturnToManage_Click);
            // 
            // gMapControl1
            // 
            this.gMapControl1.Bearing = 0F;
            this.gMapControl1.CanDragMap = true;
            this.gMapControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gMapControl1.EmptyTileColor = System.Drawing.Color.Navy;
            this.gMapControl1.GrayScaleMode = false;
            this.gMapControl1.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gMapControl1.LevelsKeepInMemmory = 5;
            this.gMapControl1.Location = new System.Drawing.Point(191, 0);
            this.gMapControl1.MarkersEnabled = true;
            this.gMapControl1.MaxZoom = 2;
            this.gMapControl1.MinZoom = 2;
            this.gMapControl1.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gMapControl1.Name = "gMapControl1";
            this.gMapControl1.NegativeMode = false;
            this.gMapControl1.PolygonsEnabled = true;
            this.gMapControl1.RetryLoadTile = 0;
            this.gMapControl1.RoutesEnabled = true;
            this.gMapControl1.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gMapControl1.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gMapControl1.ShowTileGridLines = false;
            this.gMapControl1.Size = new System.Drawing.Size(736, 857);
            this.gMapControl1.TabIndex = 6;
            this.gMapControl1.Zoom = 0D;
            // 
            // button_Exit
            // 
            this.button_Exit.Location = new System.Drawing.Point(46, 806);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(56, 19);
            this.button_Exit.TabIndex = 12;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // DonatedFamilyRepresentativeTrackPackage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 857);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.gMapControl1);
            this.Controls.Add(this.button_ReturnToManage);
            this.Controls.Add(this.labelTrackPackage);
            this.Controls.Add(this.button_CurrentLocation);
            this.Controls.Add(this.button_PackageTracking);
            this.Controls.Add(this.splitter1);
            this.Name = "DonatedFamilyRepresentativeTrackPackage";
            this.Text = "מעקב אחר חבילה";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.DonatedFamilyRepresentativeTrackPackage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Button button_PackageTracking;
        private System.Windows.Forms.Button button_CurrentLocation;
        private System.Windows.Forms.Label labelTrackPackage;
        private System.Windows.Forms.Button button_ReturnToManage;
        private GMap.NET.WindowsForms.GMapControl gMapControl1;
        private System.Windows.Forms.Button button_Exit;
    }
}