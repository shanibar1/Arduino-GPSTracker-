using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Group14
{

    public class RegistrationForEvent {

        private Event e;
        private Volunteer v;
        private bool registeredVolunteer;

        public RegistrationForEvent(Volunteer v, Event e)
        {
            this.e = e;
            this.v = v;
            registeredVolunteer = true;
        }

        public RegistrationForEvent(Volunteer v, Event e, Boolean registeredVolunteer)
        {
            this.v = v;
            this.e = e;
            this.registeredVolunteer = registeredVolunteer;
        }

        //*****************************************************************************
        public int getVolunteersAmount()
        {
            int count = 0;
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();

                string query = @"
            SELECT COUNT(*) 
            FROM Registarations AS R
            WHERE R.registered = 1 AND R.eventId_Events = @eventId";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@eventId", e.GetEventId());

                    object result = command.ExecuteScalar();
                    count = Convert.ToInt32(result);
                }
            }
            return count;
        }
        //*****************************************************************************

        public Event GetEvent()
        {
            return this.e;
        }
        public Volunteer GetVolunteer()
        {
            return v;
        }

        public Boolean GetRegistered()
        {
            return registeredVolunteer;
        }
        public void setRegistered(bool v)
        {
            this.registeredVolunteer = v;
        }
    }
}