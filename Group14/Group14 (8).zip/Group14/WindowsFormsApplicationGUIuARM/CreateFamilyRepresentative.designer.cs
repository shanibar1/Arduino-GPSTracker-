﻿namespace Group14
{
    partial class CreateFamilyRepresentative
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateFamilyRepresentative));
            this.label_ErrorFamilyPhone = new System.Windows.Forms.Label();
            this.label_ErrorFamilyLastName = new System.Windows.Forms.Label();
            this.label_ErrorFamilyFirstName = new System.Windows.Forms.Label();
            this.label_ErrorFamilyId = new System.Windows.Forms.Label();
            this.button_AddNewFamily = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.textBox_FamilyPhoneNumber = new System.Windows.Forms.TextBox();
            this.textBox_FamilyLastName = new System.Windows.Forms.TextBox();
            this.textBox_FamilyFirstName = new System.Windows.Forms.TextBox();
            this.textBox_FamilyId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_ErrorFamilyAddress = new System.Windows.Forms.Label();
            this.textBox_FamilyAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button_Exit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.registrationsTableAdapter1 = new WindowsFormsApplicationGUIuARM.SAD_14DataSetTableAdapters.RegistrationsTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_ErrorFamilyPhone
            // 
            this.label_ErrorFamilyPhone.AutoSize = true;
            this.label_ErrorFamilyPhone.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyPhone.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyPhone.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyPhone.Location = new System.Drawing.Point(414, 330);
            this.label_ErrorFamilyPhone.Name = "label_ErrorFamilyPhone";
            this.label_ErrorFamilyPhone.Size = new System.Drawing.Size(262, 28);
            this.label_ErrorFamilyPhone.TabIndex = 39;
            this.label_ErrorFamilyPhone.Text = "קלט מספר פלאפון שגוי";
            // 
            // label_ErrorFamilyLastName
            // 
            this.label_ErrorFamilyLastName.AutoSize = true;
            this.label_ErrorFamilyLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyLastName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyLastName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyLastName.Location = new System.Drawing.Point(414, 261);
            this.label_ErrorFamilyLastName.Name = "label_ErrorFamilyLastName";
            this.label_ErrorFamilyLastName.Size = new System.Drawing.Size(248, 28);
            this.label_ErrorFamilyLastName.TabIndex = 37;
            this.label_ErrorFamilyLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorFamilyFirstName
            // 
            this.label_ErrorFamilyFirstName.AutoSize = true;
            this.label_ErrorFamilyFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyFirstName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyFirstName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyFirstName.Location = new System.Drawing.Point(426, 197);
            this.label_ErrorFamilyFirstName.Name = "label_ErrorFamilyFirstName";
            this.label_ErrorFamilyFirstName.Size = new System.Drawing.Size(220, 28);
            this.label_ErrorFamilyFirstName.TabIndex = 36;
            this.label_ErrorFamilyFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // label_ErrorFamilyId
            // 
            this.label_ErrorFamilyId.AutoSize = true;
            this.label_ErrorFamilyId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyId.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyId.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyId.Location = new System.Drawing.Point(414, 127);
            this.label_ErrorFamilyId.Name = "label_ErrorFamilyId";
            this.label_ErrorFamilyId.Size = new System.Drawing.Size(155, 28);
            this.label_ErrorFamilyId.TabIndex = 35;
            this.label_ErrorFamilyId.Text = "קלט ת.ז שגוי";
            // 
            // button_AddNewFamily
            // 
            this.button_AddNewFamily.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_AddNewFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_AddNewFamily.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_AddNewFamily.Location = new System.Drawing.Point(0, 127);
            this.button_AddNewFamily.Name = "button_AddNewFamily";
            this.button_AddNewFamily.Size = new System.Drawing.Size(221, 65);
            this.button_AddNewFamily.TabIndex = 34;
            this.button_AddNewFamily.Text = "צור משפחה";
            this.button_AddNewFamily.UseVisualStyleBackColor = false;
            this.button_AddNewFamily.Click += new System.EventHandler(this.button_AddNewFamily_Click);
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_ReturnToEmployeeManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 216);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(221, 65);
            this.button_ReturnToEmployeeManage.TabIndex = 33;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // textBox_FamilyPhoneNumber
            // 
            this.textBox_FamilyPhoneNumber.Location = new System.Drawing.Point(689, 330);
            this.textBox_FamilyPhoneNumber.Name = "textBox_FamilyPhoneNumber";
            this.textBox_FamilyPhoneNumber.Size = new System.Drawing.Size(300, 20);
            this.textBox_FamilyPhoneNumber.TabIndex = 31;
            // 
            // textBox_FamilyLastName
            // 
            this.textBox_FamilyLastName.Location = new System.Drawing.Point(689, 261);
            this.textBox_FamilyLastName.Name = "textBox_FamilyLastName";
            this.textBox_FamilyLastName.Size = new System.Drawing.Size(300, 20);
            this.textBox_FamilyLastName.TabIndex = 29;
            // 
            // textBox_FamilyFirstName
            // 
            this.textBox_FamilyFirstName.Location = new System.Drawing.Point(689, 197);
            this.textBox_FamilyFirstName.Name = "textBox_FamilyFirstName";
            this.textBox_FamilyFirstName.Size = new System.Drawing.Size(300, 20);
            this.textBox_FamilyFirstName.TabIndex = 28;
            // 
            // textBox_FamilyId
            // 
            this.textBox_FamilyId.Location = new System.Drawing.Point(689, 127);
            this.textBox_FamilyId.Name = "textBox_FamilyId";
            this.textBox_FamilyId.Size = new System.Drawing.Size(300, 20);
            this.textBox_FamilyId.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(1019, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(165, 28);
            this.label7.TabIndex = 25;
            this.label7.Text = ":מספר פלאפון";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(1032, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 28);
            this.label5.TabIndex = 23;
            this.label5.Text = ":שם משפחה";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(1056, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 28);
            this.label4.TabIndex = 22;
            this.label4.Text = ":שם פרטי";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(1028, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 28);
            this.label3.TabIndex = 21;
            this.label3.Text = ":תעודת זהות";
            // 
            // label_ErrorFamilyAddress
            // 
            this.label_ErrorFamilyAddress.AutoSize = true;
            this.label_ErrorFamilyAddress.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyAddress.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyAddress.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyAddress.Location = new System.Drawing.Point(452, 392);
            this.label_ErrorFamilyAddress.Name = "label_ErrorFamilyAddress";
            this.label_ErrorFamilyAddress.Size = new System.Drawing.Size(190, 28);
            this.label_ErrorFamilyAddress.TabIndex = 42;
            this.label_ErrorFamilyAddress.Text = "קלט כתובת שגוי";
            // 
            // textBox_FamilyAddress
            // 
            this.textBox_FamilyAddress.Location = new System.Drawing.Point(689, 392);
            this.textBox_FamilyAddress.Name = "textBox_FamilyAddress";
            this.textBox_FamilyAddress.Size = new System.Drawing.Size(300, 20);
            this.textBox_FamilyAddress.TabIndex = 41;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(1093, 392);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 28);
            this.label8.TabIndex = 40;
            this.label8.Text = ":כתובת";
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Exit.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(0, 307);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(221, 65);
            this.button_Exit.TabIndex = 43;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(577, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(626, 63);
            this.label1.TabIndex = 44;
            this.label1.Text = ":מלא את הפרטים הבאים";
            // 
            // registrationsTableAdapter1
            // 
            this.registrationsTableAdapter1.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.button_ReturnToEmployeeManage);
            this.panel1.Controls.Add(this.button_AddNewFamily);
            this.panel1.Controls.Add(this.button_Exit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(224, 571);
            this.panel1.TabIndex = 45;
            // 
            // CreateFamilyRepresentative
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1203, 571);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_ErrorFamilyAddress);
            this.Controls.Add(this.textBox_FamilyAddress);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label_ErrorFamilyPhone);
            this.Controls.Add(this.label_ErrorFamilyLastName);
            this.Controls.Add(this.label_ErrorFamilyFirstName);
            this.Controls.Add(this.label_ErrorFamilyId);
            this.Controls.Add(this.textBox_FamilyPhoneNumber);
            this.Controls.Add(this.textBox_FamilyLastName);
            this.Controls.Add(this.textBox_FamilyFirstName);
            this.Controls.Add(this.textBox_FamilyId);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "CreateFamilyRepresentative";
            this.Text = "יצירת משפחה חדשה";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_ErrorFamilyPhone;
        private System.Windows.Forms.Label label_ErrorFamilyLastName;
        private System.Windows.Forms.Label label_ErrorFamilyFirstName;
        private System.Windows.Forms.Label label_ErrorFamilyId;
        private System.Windows.Forms.Button button_AddNewFamily;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.TextBox textBox_FamilyPhoneNumber;
        private System.Windows.Forms.TextBox textBox_FamilyLastName;
        private System.Windows.Forms.TextBox textBox_FamilyFirstName;
        private System.Windows.Forms.TextBox textBox_FamilyId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_ErrorFamilyAddress;
        private System.Windows.Forms.TextBox textBox_FamilyAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Label label1;
        private WindowsFormsApplicationGUIuARM.SAD_14DataSetTableAdapters.RegistrationsTableAdapter registrationsTableAdapter1;
        private System.Windows.Forms.Panel panel1;
    }
}