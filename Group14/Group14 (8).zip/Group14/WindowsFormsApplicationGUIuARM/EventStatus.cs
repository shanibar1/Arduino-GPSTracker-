﻿using System;
using System.ComponentModel;


namespace Group14
{
    public enum EventStatus
    {
        [Description("finished")] finished,
        [Description("preperation")] preperation,
        [Description("canceled")] canceled,
        [Description("Pending")] Pending
    }
}

