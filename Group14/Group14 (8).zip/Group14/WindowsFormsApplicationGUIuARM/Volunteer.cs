using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Group14
{
    public class Volunteer
    {
        private string volunteerId;
        private string volunteerFirstName;
        private string volunteerLastName;
        private string volunteerMail;
        private string volunteerPhone;
        private VolunteerRole volunteerRole;
        private bool volunteerDrivingLicence;
        private bool isVolunteerActive;
        private List<RegistrationForEvent> registrations;
        private double driverLocationX;
        private double driverLocationY;
        private double deliveryLocationX;
        private double deliveryLocationY;

        public Volunteer(string volunteerId, string volunteerFirstName, string volunteerLastName, string volunteerMail, string volunteerPhone, bool VolunteerDrivingLicence, VolunteerRole volunteerRole, bool isVolunteerActive, bool is_new)
        {
            this.volunteerId = volunteerId;
            this.volunteerFirstName = volunteerFirstName;
            this.volunteerLastName = volunteerLastName;
            this.volunteerMail = volunteerMail;
            this.volunteerPhone = volunteerPhone;
            this.volunteerRole = volunteerRole;
            this.registrations = new List<RegistrationForEvent>();
            // Only driver needs a licence
            if (this.volunteerRole.Equals("Driver"))
                this.volunteerDrivingLicence = true;
            else
                this.volunteerDrivingLicence = false;

            this.isVolunteerActive = isVolunteerActive;
            if (is_new)
            {
                this.CreateVolunteer();
                Program.Volunteers.Add(this);
            }
        }

     
        public void CreateVolunteer()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Volunteer @volunteerId, @firstName, @lastName, @Email, @Phone, @drivingLiscence, @Type, @IsActive";
            c.Parameters.AddWithValue("@volunteerId", this.volunteerId);
            c.Parameters.AddWithValue("@firstName", this.volunteerFirstName);
            c.Parameters.AddWithValue("@lastName", this.volunteerLastName);
            c.Parameters.AddWithValue("@Email", this.volunteerMail);
            c.Parameters.AddWithValue("@Phone", this.volunteerPhone);
            c.Parameters.AddWithValue("@drivingLiscence", this.volunteerDrivingLicence.ToString());
            c.Parameters.AddWithValue("@Type", this.volunteerRole.ToString());
            c.Parameters.AddWithValue("@IsActive", this.isVolunteerActive);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void UpdateVolunteer()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE [dbo].[UpdateVolunteers] @Id, @firstName, @lastName, @Email, @Phone,@drivingLiscence,@Type, @isActive";
            c.Parameters.AddWithValue("@Id", this.volunteerId);
            c.Parameters.AddWithValue("@firstName", this.volunteerFirstName);
            c.Parameters.AddWithValue("@lastName", this.volunteerLastName);
            c.Parameters.AddWithValue("@Email", this.volunteerMail);
            c.Parameters.AddWithValue("@Phone", this.volunteerPhone);
            c.Parameters.AddWithValue("@drivingLiscence", this.volunteerDrivingLicence.ToString());
            c.Parameters.AddWithValue("@Type", this.volunteerRole.ToString());
            c.Parameters.AddWithValue("@isActive", this.isVolunteerActive);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }
        public void Delete_Volunteer()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE [dbo].[DeleteVolunteer] @Id";
            c.Parameters.AddWithValue("@Id", this.volunteerId);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
            isVolunteerActive = false;
        }
        public void setupDrive(Event e, Package p)
        {
            this.getInitX(e);
            this.getInitY(e);
            this.getFinalX(p);
            this.getFinalY(p);
        }

        private void getInitX(Event e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open(); 
                string query = @"
                                 SELECT L.longtitude
                                 FROM Events AS E JOIN Locations AS L ON E.Address = L.Address
                                 WHERE E.eventId = @eventId";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@eventId", e.GetEventId());

                    object result = command.ExecuteScalar();
                    this.driverLocationX = Convert.ToDouble(result);
                }
            }
        }

        private void getInitY(Event e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();
                string query = @"
                                 SELECT L.latitude
                                 FROM Events AS E JOIN Locations AS L ON E.Address = L.Address
                                 WHERE E.eventId = @eventId";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@eventId", e.GetEventId());

                    object result = command.ExecuteScalar();
                    this.driverLocationY = Convert.ToDouble(result);
                }
            }
        }

        private void getFinalX(Package p)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();
                string query = @"
                                 SELECT L.longtitude
                                 FROM Packages AS P JOIN Locations AS L ON P.Address_Locations = L.Address
                                 WHERE P.packageId = @packageId";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@packageId", p.get_packageId());

                    object result = command.ExecuteScalar();
                    this.deliveryLocationX = Convert.ToDouble(result);
                }
            }
        }

        private void getFinalY(Package p)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open(); 
                string query = @"
                                 SELECT L.latitude
                                 FROM Packages AS P JOIN Locations AS L ON P.Address_Locations = L.Address
                                 WHERE P.packageId = @packageId";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@packageId", p.get_packageId());

                    object result = command.ExecuteScalar();
                    this.deliveryLocationY = Convert.ToDouble(result);
                }
            }
        }


        public double get_X()
        {
            return this.driverLocationX;
        }

        public double get_Y()
        {
            return this.driverLocationY;
        }

        public void Drive(double speed)
        {
            double xA = this.go_East(speed);
            double xB = this.go_West(speed);
            double yA = this.go_North(speed);
            double yB = this.go_South(speed);
            this.driverLocationX += this.go_East(speed) + this.go_West(speed);
            this.driverLocationY += this.go_North(speed) + this.go_South(speed);
        }

        private double go_North(double speed)
        {
            if(this.driverLocationY < this.deliveryLocationY)
            {
                return speed;
            }
            return 0;
        }

        private double go_South(double speed)
        {
            if (this.driverLocationY > this.deliveryLocationY)
            {
                return 0 - speed;
            }
            return 0;
        }

        private double go_East(double speed)
        {
            if (this.driverLocationX > this.deliveryLocationX)
            {
                return 0 - speed;
            }
            return 0;
        }

        private double go_West(double speed)
        {
            if (this.driverLocationX < this.deliveryLocationX)
            {
                return speed;
            }
            return 0;
        }

        public void Deliver(DonatedFamilyRepresentative df, Event e)
        {
            Package p = new Package(this.getPackageId(), e.GetEventId(), this.volunteerId, df.get_address(), PackageStatus.InTransit, true);
        }

        private string getPackageId()
        {
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string digits = "0123456789";
            string final = letters + digits;

            Random random = new Random();
            StringBuilder catalogNumber = new StringBuilder();

            for (int i = 0; i < 8; i++)
            {
                int randomIndex = random.Next(0, final.Length);
                catalogNumber.Append(final[randomIndex]);
            }
            foreach (Event e in Program.Events)
            {
                if (catalogNumber.ToString().Equals(e.GetEventId()))
                    getPackageId();
            }
            return catalogNumber.ToString();
        }

        public bool IsEventDateSameAsSelectedEvent(string id, string eventDate, List<string> selectedEventsIds)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();

                string query = "SELECT COUNT(*) FROM Events " +
                               "WHERE eventId IN ({0}) " +
                               "AND Date = @eventDate";

                string eventIdsParam = string.Join(",", selectedEventsIds.Select((_, index) => "@eventId" + index));
                string queryFormatted = string.Format(query, eventIdsParam);

                using (SqlCommand command = new SqlCommand(queryFormatted, conn))
                {
                    command.Parameters.AddWithValue("@eventDate", DateTime.Parse(eventDate));

                    for (int i = 0; i < selectedEventsIds.Count; i++)
                    {
                        command.Parameters.AddWithValue("@eventId" + i, selectedEventsIds[i]);
                    }

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value && Convert.ToInt32(result) > 0)
                    {
                        return true; // Event with the same date already selected
                    }
                }
            }

            return false; // No event with the same date already selected

        }

        public Boolean unregistrar(Event e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();
                // Register the events
                string unregisterEventsQuery = " UPDATE dbo.Registrations SET registered = 0 WHERE eventId_Events =" + e.GetEventId() + " AND volunteerId_Volunteers =" + volunteerId;
                using (SqlCommand unregisterEventsCommand = new SqlCommand(unregisterEventsQuery, conn))
                {

                    unregisterEventsCommand.ExecuteNonQuery();
                    foreach (RegistrationForEvent r in registrations)
                    {
                        if (r.GetEvent() == e)
                            r.setRegistered(false);
                        return true;
                    }
                    return false;
                }
            }
        }

        public bool IsEventDateSameAsRegistered(string eventDate)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();

                string query = @"
            SELECT COUNT(*) 
            FROM [dbo].[Registrations] r 
            JOIN [dbo].[Events] e ON r.eventId_Events = e.eventId 
            WHERE r.volunteerId_Volunteers = @volunteerId 
            AND r.registered = 1 
            AND e.[Date] = @eventDate 
            GROUP BY e.[Date]";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@volunteerId", volunteerId);
                    command.Parameters.AddWithValue("@eventDate", DateTime.Parse(eventDate));

                    object result = command.ExecuteScalar();
                    int a = Convert.ToInt32(result);
                    if (result != null && result != DBNull.Value && Convert.ToInt32(result) > 0)
                    {
                        return true; // Volunteer is registered for an event with the same date
                    }
                }
            }

            return false; // Volunteer is not registered for any event with the same date
        }

        public void addRegistration(RegistrationForEvent re)
        {
            registrations.Add(re);
        }

        public List<string> checkDuplicateDates(List<string> selectedEventsIds)
        {
            List<string> duplicateDates = new List<string>();

            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();

                // Check for duplicate dates
                string duplicateDatesQuery = @"
    SELECT Events.Date
    FROM Registrations
    INNER JOIN Events ON Registrations.eventId_Events = Events.eventId
    WHERE volunteerId_Volunteers = @volunteerId
    AND Events.eventId IN ({0})
    GROUP BY Events.Date
    HAVING COUNT(*) > 1";

                string eventIdsParam = string.Join(",", selectedEventsIds.Select((_, index) => "@eventId" + index));
                string duplicateDatesQueryFormatted = string.Format(duplicateDatesQuery, eventIdsParam);

                using (SqlCommand duplicateDatesCommand = new SqlCommand(duplicateDatesQueryFormatted, conn))
                {
                    duplicateDatesCommand.Parameters.AddWithValue("@volunteerId", volunteerId);

                    for (int i = 0; i < selectedEventsIds.Count; i++)
                    {
                        duplicateDatesCommand.Parameters.AddWithValue("@eventId" + i, selectedEventsIds[i]);
                    }


                    using (SqlDataReader reader = duplicateDatesCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string eventDate = reader["Date"].ToString();
                            duplicateDates.Add(eventDate);
                        }
                    }
                }
            }
            return duplicateDates;
        }

        public bool Registrar(string eventId)
        {

            // Register the events
            if (isExist(eventId) == 0)
            {
                SqlCommand c = new SqlCommand();
                c.CommandText = "EXECUTE  [dbo].[insertRegistration] @eventId  ,@volunteerId";

                c.Parameters.AddWithValue("@eventId", eventId);
                c.Parameters.AddWithValue("@volunteerId", this.volunteerId);

                SQL_CON SC = new SQL_CON();
                SC.execute_non_query(c);

                Event e = Program.seekEvent(eventId);
                RegistrationForEvent a = new RegistrationForEvent(this, e);
                e.addRegistration(a);
                registrations.Add(a);
                Program.Registrations.Add(a);

                return true;
            }

            else
            {
                using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
                {
                    conn.Open();
                    // Register the events
                    string unregisterEventsQuery = " UPDATE dbo.Registrations SET registered = 1 WHERE eventId_Events =" + eventId + " AND volunteerId_Volunteers =" + volunteerId;
                    using (SqlCommand unregisterEventsCommand = new SqlCommand(unregisterEventsQuery, conn))
                    {

                        unregisterEventsCommand.ExecuteNonQuery();
                    }
                    registerAgain(eventId);
                    return true;
                }
            }
        }



        private void registerAgain(string eventId)
        {
            foreach (RegistrationForEvent r in registrations)
            {
                if (Program.seekEvent(eventId).Equals(r.GetEvent()))
                {
                    r.setRegistered(true);
                    return;
                }
            }
        }

        public int isExist(string eventId)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();
                string query = "SELECT count(*) FROM Registrations WHERE eventId_Events=" + eventId + " AND volunteerId_Volunteers=" + volunteerId;
                using (SqlCommand registerEventsCommand = new SqlCommand(query, conn))
                {
                    object result = registerEventsCommand.ExecuteScalar();
                    if (result == null)
                        return 0;
                    else return (int)result;
                }
            }
        }

            public string get_volunteerId()
        {
            return this.volunteerId;
        }
        public void set_volunteerId(string volunteerId)
        {
            this.volunteerId = volunteerId;
        }

        public string get_volunteerFirstName()
        {
            return this.volunteerFirstName;
        }
        public void set_volunteerFirstName(string volunteerFirstName)
        {
            this.volunteerFirstName = volunteerFirstName;
        }

        public string get_volunteerLastName()
        {
            return this.volunteerLastName;
        }
        public void set_volunteerLastName(string volunteerLastName)
        {
            this.volunteerLastName = volunteerLastName;
        }

        public string get_volunteerMail()
        {
            return this.volunteerMail;
        }
        public void set_volunteerMail(string volunteerMail)
        {
            this.volunteerMail = volunteerMail;
        }

        public string get_volunteerPhone()
        {
            return this.volunteerPhone;
        }
        public void set_volunteerPhone(string volunteerPhone)
        {
            this.volunteerPhone = volunteerPhone;
        }

        public bool get_drivingLicense()
        {
            return this.volunteerDrivingLicence;
        }
        public void set_drivingLicense(bool drivingLicense)
        {
            this.volunteerDrivingLicence = drivingLicense;
        }

        public VolunteerRole get_volunteerRole()
        {
            return this.volunteerRole;
        }
        public void set_volunteerRole(VolunteerRole volunteerRole)
        {
            this.volunteerRole = volunteerRole;
            if (volunteerRole == VolunteerRole.Driver)
                volunteerDrivingLicence = true;
            else volunteerDrivingLicence = false;
        }

        public bool get_isVolunteerActive()
        {
            return this.isVolunteerActive;
        }
        public void set_isVolunteerActive(bool isVolunteerActive)
        {
            this.isVolunteerActive = isVolunteerActive;
        }

        public List<RegistrationForEvent> getRegistrations()
        {
            return this.registrations;
        }
    }
}