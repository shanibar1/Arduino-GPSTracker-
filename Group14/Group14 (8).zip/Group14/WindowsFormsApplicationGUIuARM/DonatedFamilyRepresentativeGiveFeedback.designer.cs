﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeGiveFeedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DonatedFamilyRepresentativeGiveFeedback));
            this.button_ReturnToFamilyManage = new System.Windows.Forms.Button();
            this.button_GiveFeedback = new System.Windows.Forms.Button();
            this.textBox_Feedback = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxStars = new System.Windows.Forms.ComboBox();
            this.comboBox_Package = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_Exit = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_Date = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button_ReturnToFamilyManage
            // 
            this.button_ReturnToFamilyManage.BackColor = System.Drawing.Color.Gray;
            this.button_ReturnToFamilyManage.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToFamilyManage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_ReturnToFamilyManage.Location = new System.Drawing.Point(0, 452);
            this.button_ReturnToFamilyManage.Name = "button_ReturnToFamilyManage";
            this.button_ReturnToFamilyManage.Size = new System.Drawing.Size(249, 70);
            this.button_ReturnToFamilyManage.TabIndex = 0;
            this.button_ReturnToFamilyManage.Text = "חזור";
            this.button_ReturnToFamilyManage.UseVisualStyleBackColor = false;
            this.button_ReturnToFamilyManage.Click += new System.EventHandler(this.button_ReturnToFamilyManage_Click);
            // 
            // button_GiveFeedback
            // 
            this.button_GiveFeedback.BackColor = System.Drawing.Color.Gray;
            this.button_GiveFeedback.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_GiveFeedback.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_GiveFeedback.Location = new System.Drawing.Point(0, 382);
            this.button_GiveFeedback.Name = "button_GiveFeedback";
            this.button_GiveFeedback.Size = new System.Drawing.Size(249, 64);
            this.button_GiveFeedback.TabIndex = 2;
            this.button_GiveFeedback.Text = "שלח משוב";
            this.button_GiveFeedback.UseVisualStyleBackColor = false;
            this.button_GiveFeedback.Click += new System.EventHandler(this.button_GiveFeedback_Click);
            // 
            // textBox_Feedback
            // 
            this.textBox_Feedback.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Feedback.Location = new System.Drawing.Point(299, 279);
            this.textBox_Feedback.Multiline = true;
            this.textBox_Feedback.Name = "textBox_Feedback";
            this.textBox_Feedback.Size = new System.Drawing.Size(406, 219);
            this.textBox_Feedback.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(742, 282);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = ":מלא משוב";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(789, 230);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = ":דרג";
            // 
            // comboBoxStars
            // 
            this.comboBoxStars.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStars.FormattingEnabled = true;
            this.comboBoxStars.Location = new System.Drawing.Point(507, 230);
            this.comboBoxStars.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxStars.Name = "comboBoxStars";
            this.comboBoxStars.Size = new System.Drawing.Size(198, 21);
            this.comboBoxStars.TabIndex = 6;
            // 
            // comboBox_Package
            // 
            this.comboBox_Package.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBox_Package.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Package.FormattingEnabled = true;
            this.comboBox_Package.Location = new System.Drawing.Point(507, 121);
            this.comboBox_Package.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_Package.Name = "comboBox_Package";
            this.comboBox_Package.Size = new System.Drawing.Size(198, 21);
            this.comboBox_Package.TabIndex = 7;
            this.comboBox_Package.SelectedIndexChanged += new System.EventHandler(this.comboBox_Package_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(742, 121);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = ":בחר חבילה";
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.Color.Gray;
            this.button_Exit.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_Exit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Exit.Location = new System.Drawing.Point(763, 541);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(84, 30);
            this.button_Exit.TabIndex = 10;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(768, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = ":תאריך";
            // 
            // textBox_Date
            // 
            this.textBox_Date.Enabled = false;
            this.textBox_Date.Location = new System.Drawing.Point(507, 173);
            this.textBox_Date.Name = "textBox_Date";
            this.textBox_Date.Size = new System.Drawing.Size(198, 20);
            this.textBox_Date.TabIndex = 12;
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(249, 583);
            this.splitter1.TabIndex = 13;
            this.splitter1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(303, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(559, 63);
            this.label5.TabIndex = 14;
            this.label5.Text = "רישום משוב על חבילה";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(249, 314);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // DonatedFamilyRepresentativeGiveFeedback
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(862, 583);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_Date);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox_Package);
            this.Controls.Add(this.comboBoxStars);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_Feedback);
            this.Controls.Add(this.button_GiveFeedback);
            this.Controls.Add(this.button_ReturnToFamilyManage);
            this.Controls.Add(this.splitter1);
            this.Name = "DonatedFamilyRepresentativeGiveFeedback";
            this.Text = "מילוי משוב";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_ReturnToFamilyManage;
        private System.Windows.Forms.Button button_GiveFeedback;
        private System.Windows.Forms.TextBox textBox_Feedback;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxStars;
        private System.Windows.Forms.ComboBox comboBox_Package;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_Date;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}