﻿namespace Group14
{
    partial class UpdateDeleteVolunteer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateDeleteVolunteer));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_VolunteerId = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerFirstName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerLastName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerMail = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerPhoneNumber = new System.Windows.Forms.TextBox();
            this.comboBox_VolunteerRole = new System.Windows.Forms.ComboBox();
            this.button_UpdateVolunteer = new System.Windows.Forms.Button();
            this.button_DeleteVolunteer = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.label_ErrorVolunteerId = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerFirstName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerLastName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerMail = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerPhone = new System.Windows.Forms.Label();
            this.button_Search = new System.Windows.Forms.Button();
            this.button_Exit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(715, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = ":הכנס ת.ז מתנדב";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(751, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = ":שם פרטי";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(739, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = ":שם משפחה";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(771, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 28);
            this.label4.TabIndex = 3;
            this.label4.Text = ":מייל";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(726, 379);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(165, 28);
            this.label5.TabIndex = 4;
            this.label5.Text = ":מספר פלאפון";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(762, 437);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 28);
            this.label6.TabIndex = 5;
            this.label6.Text = ":תפקיד";
            // 
            // textBox_VolunteerId
            // 
            this.textBox_VolunteerId.Location = new System.Drawing.Point(505, 142);
            this.textBox_VolunteerId.Name = "textBox_VolunteerId";
            this.textBox_VolunteerId.Size = new System.Drawing.Size(202, 20);
            this.textBox_VolunteerId.TabIndex = 6;
            // 
            // textBox_VolunteerFirstName
            // 
            this.textBox_VolunteerFirstName.Location = new System.Drawing.Point(505, 210);
            this.textBox_VolunteerFirstName.Name = "textBox_VolunteerFirstName";
            this.textBox_VolunteerFirstName.Size = new System.Drawing.Size(202, 20);
            this.textBox_VolunteerFirstName.TabIndex = 7;
            // 
            // textBox_VolunteerLastName
            // 
            this.textBox_VolunteerLastName.Location = new System.Drawing.Point(505, 265);
            this.textBox_VolunteerLastName.Name = "textBox_VolunteerLastName";
            this.textBox_VolunteerLastName.Size = new System.Drawing.Size(202, 20);
            this.textBox_VolunteerLastName.TabIndex = 8;
            // 
            // textBox_VolunteerMail
            // 
            this.textBox_VolunteerMail.Location = new System.Drawing.Point(505, 323);
            this.textBox_VolunteerMail.Name = "textBox_VolunteerMail";
            this.textBox_VolunteerMail.Size = new System.Drawing.Size(202, 20);
            this.textBox_VolunteerMail.TabIndex = 9;
            // 
            // textBox_VolunteerPhoneNumber
            // 
            this.textBox_VolunteerPhoneNumber.Location = new System.Drawing.Point(505, 376);
            this.textBox_VolunteerPhoneNumber.Name = "textBox_VolunteerPhoneNumber";
            this.textBox_VolunteerPhoneNumber.Size = new System.Drawing.Size(202, 20);
            this.textBox_VolunteerPhoneNumber.TabIndex = 10;
            // 
            // comboBox_VolunteerRole
            // 
            this.comboBox_VolunteerRole.FormattingEnabled = true;
            this.comboBox_VolunteerRole.Location = new System.Drawing.Point(484, 434);
            this.comboBox_VolunteerRole.Name = "comboBox_VolunteerRole";
            this.comboBox_VolunteerRole.Size = new System.Drawing.Size(223, 21);
            this.comboBox_VolunteerRole.TabIndex = 11;
            // 
            // button_UpdateVolunteer
            // 
            this.button_UpdateVolunteer.BackColor = System.Drawing.Color.Yellow;
            this.button_UpdateVolunteer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_UpdateVolunteer.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_UpdateVolunteer.Location = new System.Drawing.Point(0, 167);
            this.button_UpdateVolunteer.Name = "button_UpdateVolunteer";
            this.button_UpdateVolunteer.Size = new System.Drawing.Size(220, 73);
            this.button_UpdateVolunteer.TabIndex = 12;
            this.button_UpdateVolunteer.Text = "עדכן";
            this.button_UpdateVolunteer.UseVisualStyleBackColor = false;
            this.button_UpdateVolunteer.Click += new System.EventHandler(this.button_UpdateVolunteer_Click);
            // 
            // button_DeleteVolunteer
            // 
            this.button_DeleteVolunteer.BackColor = System.Drawing.Color.Yellow;
            this.button_DeleteVolunteer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_DeleteVolunteer.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_DeleteVolunteer.Location = new System.Drawing.Point(0, 267);
            this.button_DeleteVolunteer.Name = "button_DeleteVolunteer";
            this.button_DeleteVolunteer.Size = new System.Drawing.Size(220, 73);
            this.button_DeleteVolunteer.TabIndex = 14;
            this.button_DeleteVolunteer.Text = "מחק";
            this.button_DeleteVolunteer.UseVisualStyleBackColor = false;
            this.button_DeleteVolunteer.Click += new System.EventHandler(this.button_DeleteVolunteer_Click);
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.Color.Yellow;
            this.button_ReturnToEmployeeManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 375);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(220, 73);
            this.button_ReturnToEmployeeManage.TabIndex = 14;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // label_ErrorVolunteerId
            // 
            this.label_ErrorVolunteerId.AutoSize = true;
            this.label_ErrorVolunteerId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerId.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerId.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerId.Location = new System.Drawing.Point(532, 165);
            this.label_ErrorVolunteerId.Name = "label_ErrorVolunteerId";
            this.label_ErrorVolunteerId.Size = new System.Drawing.Size(73, 13);
            this.label_ErrorVolunteerId.TabIndex = 15;
            this.label_ErrorVolunteerId.Text = "קלט ת.ז שגוי";
            // 
            // label_ErrorVolunteerFirstName
            // 
            this.label_ErrorVolunteerFirstName.AutoSize = true;
            this.label_ErrorVolunteerFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerFirstName.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerFirstName.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerFirstName.Location = new System.Drawing.Point(504, 233);
            this.label_ErrorVolunteerFirstName.Name = "label_ErrorVolunteerFirstName";
            this.label_ErrorVolunteerFirstName.Size = new System.Drawing.Size(101, 13);
            this.label_ErrorVolunteerFirstName.TabIndex = 16;
            this.label_ErrorVolunteerFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // label_ErrorVolunteerLastName
            // 
            this.label_ErrorVolunteerLastName.AutoSize = true;
            this.label_ErrorVolunteerLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerLastName.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerLastName.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerLastName.Location = new System.Drawing.Point(490, 288);
            this.label_ErrorVolunteerLastName.Name = "label_ErrorVolunteerLastName";
            this.label_ErrorVolunteerLastName.Size = new System.Drawing.Size(115, 13);
            this.label_ErrorVolunteerLastName.TabIndex = 17;
            this.label_ErrorVolunteerLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorVolunteerMail
            // 
            this.label_ErrorVolunteerMail.AutoSize = true;
            this.label_ErrorVolunteerMail.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerMail.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerMail.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerMail.Location = new System.Drawing.Point(504, 346);
            this.label_ErrorVolunteerMail.Name = "label_ErrorVolunteerMail";
            this.label_ErrorVolunteerMail.Size = new System.Drawing.Size(79, 13);
            this.label_ErrorVolunteerMail.TabIndex = 18;
            this.label_ErrorVolunteerMail.Text = "קלט מייל שגוי";
            // 
            // label_ErrorVolunteerPhone
            // 
            this.label_ErrorVolunteerPhone.AutoSize = true;
            this.label_ErrorVolunteerPhone.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerPhone.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorVolunteerPhone.ForeColor = System.Drawing.Color.Maroon;
            this.label_ErrorVolunteerPhone.Location = new System.Drawing.Point(504, 399);
            this.label_ErrorVolunteerPhone.Name = "label_ErrorVolunteerPhone";
            this.label_ErrorVolunteerPhone.Size = new System.Drawing.Size(121, 13);
            this.label_ErrorVolunteerPhone.TabIndex = 19;
            this.label_ErrorVolunteerPhone.Text = "קלט מספר פלאפון שגוי";
            // 
            // button_Search
            // 
            this.button_Search.BackColor = System.Drawing.Color.Crimson;
            this.button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Search.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Search.Location = new System.Drawing.Point(412, 140);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(74, 38);
            this.button_Search.TabIndex = 20;
            this.button_Search.Text = "חפש";
            this.button_Search.UseVisualStyleBackColor = false;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.Color.Yellow;
            this.button_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Exit.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(0, 478);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(220, 73);
            this.button_Exit.TabIndex = 45;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Orange;
            this.panel1.Controls.Add(this.button_Exit);
            this.panel1.Controls.Add(this.button_UpdateVolunteer);
            this.panel1.Controls.Add(this.button_DeleteVolunteer);
            this.panel1.Controls.Add(this.button_ReturnToEmployeeManage);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(220, 615);
            this.panel1.TabIndex = 46;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Dock = System.Windows.Forms.DockStyle.Right;
            this.label7.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(314, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(626, 63);
            this.label7.TabIndex = 47;
            this.label7.Text = ":מלא את הפרטים הבאים";
            // 
            // UpdateDeleteVolunteer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(940, 615);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button_Search);
            this.Controls.Add(this.label_ErrorVolunteerPhone);
            this.Controls.Add(this.label_ErrorVolunteerMail);
            this.Controls.Add(this.label_ErrorVolunteerLastName);
            this.Controls.Add(this.label_ErrorVolunteerFirstName);
            this.Controls.Add(this.label_ErrorVolunteerId);
            this.Controls.Add(this.comboBox_VolunteerRole);
            this.Controls.Add(this.textBox_VolunteerPhoneNumber);
            this.Controls.Add(this.textBox_VolunteerMail);
            this.Controls.Add(this.textBox_VolunteerLastName);
            this.Controls.Add(this.textBox_VolunteerFirstName);
            this.Controls.Add(this.textBox_VolunteerId);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Name = "UpdateDeleteVolunteer";
            this.Text = "ניהול מתנדב קיים";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_VolunteerId;
        private System.Windows.Forms.TextBox textBox_VolunteerFirstName;
        private System.Windows.Forms.TextBox textBox_VolunteerLastName;
        private System.Windows.Forms.TextBox textBox_VolunteerMail;
        private System.Windows.Forms.TextBox textBox_VolunteerPhoneNumber;
        private System.Windows.Forms.ComboBox comboBox_VolunteerRole;
        private System.Windows.Forms.Button button_UpdateVolunteer;
        private System.Windows.Forms.Button button_DeleteVolunteer;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.Label label_ErrorVolunteerId;
        private System.Windows.Forms.Label label_ErrorVolunteerFirstName;
        private System.Windows.Forms.Label label_ErrorVolunteerLastName;
        private System.Windows.Forms.Label label_ErrorVolunteerMail;
        private System.Windows.Forms.Label label_ErrorVolunteerPhone;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
    }
}