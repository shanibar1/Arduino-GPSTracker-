﻿namespace Group14
{
    partial class UpdateDeleteFamilyRepresentative
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateDeleteFamilyRepresentative));
            this.label_ErrorFamilyId = new System.Windows.Forms.Label();
            this.label_ErrorFamilyPhone = new System.Windows.Forms.Label();
            this.label_ErrorFamilyLastName = new System.Windows.Forms.Label();
            this.label_ErrorFamilyFirstName = new System.Windows.Forms.Label();
            this.textBox_FamilyLastName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_FamilyPhoneNumber = new System.Windows.Forms.TextBox();
            this.textBox_FamilyFirstName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_FamilyId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label_ErrorFamilyAddress = new System.Windows.Forms.Label();
            this.textBox_FamilyAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Search = new System.Windows.Forms.Button();
            this.button_DeleteFamily = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.button_UpdateFamily = new System.Windows.Forms.Button();
            this.button_Exit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_ErrorFamilyId
            // 
            this.label_ErrorFamilyId.AutoSize = true;
            this.label_ErrorFamilyId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyId.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyId.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyId.Location = new System.Drawing.Point(912, 142);
            this.label_ErrorFamilyId.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorFamilyId.Name = "label_ErrorFamilyId";
            this.label_ErrorFamilyId.Size = new System.Drawing.Size(77, 13);
            this.label_ErrorFamilyId.TabIndex = 62;
            this.label_ErrorFamilyId.Text = "קלט ת.ז שגוי";
            // 
            // label_ErrorFamilyPhone
            // 
            this.label_ErrorFamilyPhone.AutoSize = true;
            this.label_ErrorFamilyPhone.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyPhone.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyPhone.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyPhone.Location = new System.Drawing.Point(920, 430);
            this.label_ErrorFamilyPhone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorFamilyPhone.Name = "label_ErrorFamilyPhone";
            this.label_ErrorFamilyPhone.Size = new System.Drawing.Size(130, 13);
            this.label_ErrorFamilyPhone.TabIndex = 61;
            this.label_ErrorFamilyPhone.Text = "קלט מספר פלאפון שגוי";
            // 
            // label_ErrorFamilyLastName
            // 
            this.label_ErrorFamilyLastName.AutoSize = true;
            this.label_ErrorFamilyLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyLastName.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyLastName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyLastName.Location = new System.Drawing.Point(913, 298);
            this.label_ErrorFamilyLastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorFamilyLastName.Name = "label_ErrorFamilyLastName";
            this.label_ErrorFamilyLastName.Size = new System.Drawing.Size(123, 13);
            this.label_ErrorFamilyLastName.TabIndex = 59;
            this.label_ErrorFamilyLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorFamilyFirstName
            // 
            this.label_ErrorFamilyFirstName.AutoSize = true;
            this.label_ErrorFamilyFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyFirstName.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label_ErrorFamilyFirstName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyFirstName.Location = new System.Drawing.Point(913, 220);
            this.label_ErrorFamilyFirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorFamilyFirstName.Name = "label_ErrorFamilyFirstName";
            this.label_ErrorFamilyFirstName.Size = new System.Drawing.Size(110, 13);
            this.label_ErrorFamilyFirstName.TabIndex = 58;
            this.label_ErrorFamilyFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // textBox_FamilyLastName
            // 
            this.textBox_FamilyLastName.Location = new System.Drawing.Point(765, 275);
            this.textBox_FamilyLastName.Name = "textBox_FamilyLastName";
            this.textBox_FamilyLastName.Size = new System.Drawing.Size(258, 20);
            this.textBox_FamilyLastName.TabIndex = 57;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(1053, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(151, 28);
            this.label6.TabIndex = 56;
            this.label6.Text = ":שם משפחה";
            // 
            // textBox_FamilyPhoneNumber
            // 
            this.textBox_FamilyPhoneNumber.Location = new System.Drawing.Point(765, 407);
            this.textBox_FamilyPhoneNumber.Name = "textBox_FamilyPhoneNumber";
            this.textBox_FamilyPhoneNumber.Size = new System.Drawing.Size(258, 20);
            this.textBox_FamilyPhoneNumber.TabIndex = 51;
            // 
            // textBox_FamilyFirstName
            // 
            this.textBox_FamilyFirstName.Location = new System.Drawing.Point(765, 197);
            this.textBox_FamilyFirstName.Name = "textBox_FamilyFirstName";
            this.textBox_FamilyFirstName.Size = new System.Drawing.Size(258, 20);
            this.textBox_FamilyFirstName.TabIndex = 49;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(1047, 410);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 28);
            this.label4.TabIndex = 47;
            this.label4.Text = ":מספר פלאפון";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(1081, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 28);
            this.label2.TabIndex = 45;
            this.label2.Text = ":שם פרטי";
            // 
            // textBox_FamilyId
            // 
            this.textBox_FamilyId.Location = new System.Drawing.Point(765, 112);
            this.textBox_FamilyId.Name = "textBox_FamilyId";
            this.textBox_FamilyId.Size = new System.Drawing.Size(258, 20);
            this.textBox_FamilyId.TabIndex = 43;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(1039, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 28);
            this.label1.TabIndex = 42;
            this.label1.Text = ":הכנס ת.ז נציג";
            // 
            // label_ErrorFamilyAddress
            // 
            this.label_ErrorFamilyAddress.AutoSize = true;
            this.label_ErrorFamilyAddress.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFamilyAddress.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErrorFamilyAddress.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFamilyAddress.Location = new System.Drawing.Point(947, 375);
            this.label_ErrorFamilyAddress.Name = "label_ErrorFamilyAddress";
            this.label_ErrorFamilyAddress.Size = new System.Drawing.Size(94, 13);
            this.label_ErrorFamilyAddress.TabIndex = 65;
            this.label_ErrorFamilyAddress.Text = "קלט כתובת שגוי";
            // 
            // textBox_FamilyAddress
            // 
            this.textBox_FamilyAddress.Location = new System.Drawing.Point(765, 352);
            this.textBox_FamilyAddress.Name = "textBox_FamilyAddress";
            this.textBox_FamilyAddress.Size = new System.Drawing.Size(258, 20);
            this.textBox_FamilyAddress.TabIndex = 64;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(1111, 355);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 28);
            this.label8.TabIndex = 63;
            this.label8.Text = ":כתובת";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Dock = System.Windows.Forms.DockStyle.Right;
            this.label7.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(670, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(626, 63);
            this.label7.TabIndex = 67;
            this.label7.Text = ":מלא את הפרטים הבאים";
            // 
            // button_Search
            // 
            this.button_Search.BackColor = System.Drawing.Color.Crimson;
            this.button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Search.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Search.Location = new System.Drawing.Point(656, 107);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(74, 38);
            this.button_Search.TabIndex = 69;
            this.button_Search.Text = "חפש";
            this.button_Search.UseVisualStyleBackColor = false;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // button_DeleteFamily
            // 
            this.button_DeleteFamily.BackColor = System.Drawing.Color.Yellow;
            this.button_DeleteFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_DeleteFamily.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_DeleteFamily.Location = new System.Drawing.Point(0, 324);
            this.button_DeleteFamily.Name = "button_DeleteFamily";
            this.button_DeleteFamily.Size = new System.Drawing.Size(230, 73);
            this.button_DeleteFamily.TabIndex = 70;
            this.button_DeleteFamily.Text = "מחק";
            this.button_DeleteFamily.UseVisualStyleBackColor = false;
            this.button_DeleteFamily.Click += new System.EventHandler(this.button_DeleteFamily_Click);
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.Color.Yellow;
            this.button_ReturnToEmployeeManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 426);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(230, 73);
            this.button_ReturnToEmployeeManage.TabIndex = 71;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // button_UpdateFamily
            // 
            this.button_UpdateFamily.BackColor = System.Drawing.Color.Yellow;
            this.button_UpdateFamily.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_UpdateFamily.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_UpdateFamily.Location = new System.Drawing.Point(0, 228);
            this.button_UpdateFamily.Name = "button_UpdateFamily";
            this.button_UpdateFamily.Size = new System.Drawing.Size(230, 73);
            this.button_UpdateFamily.TabIndex = 68;
            this.button_UpdateFamily.Text = "עדכן";
            this.button_UpdateFamily.UseVisualStyleBackColor = false;
            this.button_UpdateFamily.Click += new System.EventHandler(this.button_UpdateFamily_Click);
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.Color.Yellow;
            this.button_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Exit.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(0, 122);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(230, 73);
            this.button_Exit.TabIndex = 72;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.button_Exit);
            this.panel1.Controls.Add(this.button_UpdateFamily);
            this.panel1.Controls.Add(this.button_ReturnToEmployeeManage);
            this.panel1.Controls.Add(this.button_DeleteFamily);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(229, 531);
            this.panel1.TabIndex = 73;
            // 
            // UpdateDeleteFamilyRepresentative
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1296, 531);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_Search);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label_ErrorFamilyAddress);
            this.Controls.Add(this.textBox_FamilyAddress);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label_ErrorFamilyId);
            this.Controls.Add(this.label_ErrorFamilyPhone);
            this.Controls.Add(this.label_ErrorFamilyLastName);
            this.Controls.Add(this.label_ErrorFamilyFirstName);
            this.Controls.Add(this.textBox_FamilyLastName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_FamilyPhoneNumber);
            this.Controls.Add(this.textBox_FamilyFirstName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_FamilyId);
            this.Controls.Add(this.label1);
            this.Name = "UpdateDeleteFamilyRepresentative";
            this.Text = "ניהול משפחה קיימת";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_ErrorFamilyId;
        private System.Windows.Forms.Label label_ErrorFamilyPhone;
        private System.Windows.Forms.Label label_ErrorFamilyLastName;
        private System.Windows.Forms.Label label_ErrorFamilyFirstName;
        private System.Windows.Forms.TextBox textBox_FamilyLastName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_FamilyPhoneNumber;
        private System.Windows.Forms.TextBox textBox_FamilyFirstName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_FamilyId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_ErrorFamilyAddress;
        private System.Windows.Forms.TextBox textBox_FamilyAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Button button_DeleteFamily;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.Button button_UpdateFamily;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Panel panel1;
    }
}