﻿using System;
//final מעודכן
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;

namespace Group14
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>

        // IMPORTANT NOTE
        // FIRST NAME: דוד
        // LAST NAME: קודיש
        // ID: 123456789
        public static System.Collections.Generic.List<Employee> Employees;
        public static System.Collections.Generic.List<Volunteer> Volunteers;
        public static System.Collections.Generic.List<DonatedFamilyRepresentative> DonatedFamilyRepresentatives;
        public static System.Collections.Generic.List<Event> Events;
        public static System.Collections.Generic.List<FoodItem> FoodItems;
        public static System.Collections.Generic.List<Vendor> Vendors;
        public static System.Collections.Generic.List<Package> Packages;
        public static System.Collections.Generic.List<Review> Reviews;
        public static System.Collections.Generic.List<Location> Locations;
        public static System.Collections.Generic.List<RegistrationForEvent> Registrations;
        [STAThread]

        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            init_All();
            Application.Run(new HomePage());
            //Application.Run(new DonatedFamilyRepresentativeTrackPackage(seekFamily("743832640"), seekPackage("P104864")));
            
        }

        public static void init_All()
        {
            init_Employees();
            init_DonatedFamilyRepresentatives();
            init_Reviews();
            init_Locations();
            init_Volunteers();
            init_Packages();
            init_Events();
            init_registrations();
            init_Vendors();
            init_FoodItems();
        }

        public static void init_Employees()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.getEmployees";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Employees = new List<Employee>();

            while (rdr.Read())
            {
                EmployeeRole er = (EmployeeRole)Enum.Parse(typeof(EmployeeRole), rdr.GetValue(5).ToString());
                bool isActive = bool.Parse(rdr.GetValue(6).ToString());
                Employee e = new Employee(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), rdr.GetValue(4).ToString(), er, isActive, false);
                Employees.Add(e);
            }
        }

        public static Employee seekEmployee(string id)
        {
            foreach (Employee e in Employees)
            {
                if (e.get_employeeId() == id)
                    return e;
            }
            return null;
        }

        public static void init_DonatedFamilyRepresentatives()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Representatives";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            DonatedFamilyRepresentatives = new List<DonatedFamilyRepresentative>();

            while (rdr.Read())
            {
                bool isActive = bool.Parse(rdr.GetValue(4).ToString());
                DonatedFamilyRepresentative df = new DonatedFamilyRepresentative(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), rdr.GetValue(5).ToString(), isActive, false);
                DonatedFamilyRepresentatives.Add(df);
            }
        }

        public static DonatedFamilyRepresentative seekFamily(string id)
        {
            foreach (DonatedFamilyRepresentative df in DonatedFamilyRepresentatives)
            {
                if (df.get_id().Equals(id))
                    return df;
            }
            return null;
        }

        public static void init_Packages()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.getPackages";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Packages = new List<Package>();

            while (rdr.Read())
            {
                PackageStatus ps = (PackageStatus)Enum.Parse(typeof(PackageStatus), rdr.GetValue(4).ToString());
                Package p = new Package(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), ps, false);
                Packages.Add(p);
            }
        }

        public static Package seekPackage(string id)
        {
            foreach (Package p in Packages)
            {
                if (p.get_packageId().Equals(id))
                    return p;
            }
            return null;
        }

        public static void init_Reviews()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.getReviews";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Reviews = new List<Review>();

            while (rdr.Read())
            {
                DateTime dateTime = DateTime.Parse(rdr.GetValue(2).ToString());
                int rate = Int32.Parse(rdr.GetValue(3).ToString());
                Review r = new Review(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), dateTime, rate, rdr.GetValue(4).ToString(), false);
                Reviews.Add(r);
            }
        }

        public static void init_Locations()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.getLocations";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Locations = new List<Location>();

            while (rdr.Read())
            {
                Location l = new Location(rdr.GetValue(0).ToString(), Double.Parse(rdr.GetValue(1).ToString()), Double.Parse(rdr.GetValue(2).ToString()), false);
                Locations.Add(l);
            }
        }

        public static void init_Events()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Events";

            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Events = new List<Event>();

            while (rdr.Read())
            {
                EventStatus es = (EventStatus)Enum.Parse(typeof(EventStatus), rdr.GetValue(7).ToString());
                DateTime d = DateTime.Parse(rdr.GetValue(4).ToString());
                DateTime start = DateTime.Parse(rdr.GetValue(5).ToString());
                DateTime end = DateTime.Parse(rdr.GetValue(6).ToString());
                Event e = new Event(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), d, start, end, es, false);
                Events.Add(e);
            }
        }
        public static Event seekEvent(string eventid)
        {
            foreach (Event e in Events)
            {
                if (e.GetEventId() == eventid)
                    return e;
            }
            return null;
        }

        public static void init_Volunteers()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.getVolunteers";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            Volunteers = new List<Volunteer>();

            while (rdr.Read())
            {
                VolunteerRole vr = (VolunteerRole)Enum.Parse(typeof(VolunteerRole), rdr.GetValue(6).ToString());
                bool drivingLicence = bool.Parse(rdr.GetValue(5).ToString());
                bool isActive = bool.Parse(rdr.GetValue(7).ToString());
                Volunteer v = new Volunteer(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), rdr.GetValue(4).ToString(), drivingLicence, vr, isActive, false);
                Volunteers.Add(v);
            }
        }

        public static Volunteer seekVolunteer(string id)
        {
            foreach (Volunteer v in Volunteers)
            {
                if (v.get_volunteerId() == id)
                    return v;
            }
            return null;
        }

        public static void init_registrations()
        {
            SqlCommand d = new SqlCommand();
            d.CommandText = "EXECUTE [dbo].[Get_all_Registrations]";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(d);
            Registrations = new List<RegistrationForEvent>();
            while (rdr.Read())
            {

                Event e = seekEvent(rdr.GetValue(0).ToString());
                Volunteer v = seekVolunteer(rdr.GetValue(1).ToString());
                RegistrationForEvent re = new RegistrationForEvent(v, e, bool.Parse(rdr.GetValue(2).ToString()));
                e.addRegistration(re);
                v.addRegistration(re);
                Registrations.Add(re);
            }
        }

        public static void init_Vendors()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Vendors";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            Vendors = new List<Vendor>();
            while (rdr.Read())
            {

                bool isActive = bool.Parse(rdr.GetValue(5).ToString());
                Vendor v = new Vendor(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), rdr.GetValue(4).ToString(), isActive, false);
                Vendors.Add(v);
            }
        }

        public static Vendor seekVendor(string id)
        {
            foreach (Vendor v in Vendors)
            {
                if (v.GetId() == id)
                    return v;
            }
            return null;
        }

        public static void init_FoodItems()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_FoodItems";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            FoodItems = new List<FoodItem>();

            while (rdr.Read())
            {
                bool inStock = bool.Parse(rdr.GetValue(4).ToString());
                DateTime d = DateTime.Parse(rdr.GetValue(3).ToString());
                FoodItem foodItem = new FoodItem(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), int.Parse(rdr.GetValue(2).ToString()), d, inStock, false);
                FoodItems.Add(foodItem);
            }
        }

        public static FoodItem seekFoodItem(string id)
        {
            foreach (FoodItem f in FoodItems)
            {
                if (f.GetItemName().Equals(id))
                    return f;
            }
            return null;
        }
    }
}
