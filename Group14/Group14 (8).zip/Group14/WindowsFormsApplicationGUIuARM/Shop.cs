﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class Shop : Form
    {
        int counter = 0;
        private Employee employee;
        private FoodItem item;
        private Vendor vendor;
        DataTable vendorsTable = new DataTable();
        DataTable itemsTable = new DataTable();
        private List<FoodItem> shoopingCart;
        private List<string> items = new List<string>(); 
        private List<string> images;
        private float totalPrice = 0;
        SqlConnection con = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True");

        public Shop(Employee employee)
        {
            InitializeComponent();
            findItem("corn");
            
            fillComboBox();
            this.employee = employee;
            lb_itemName2.Visible = false;

        }


        private void Shop_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sAD_14DataSet.PricesPerVendor' table. You can move, or remove it, as needed.
            this.pricesPerVendorTableAdapter.Fill(this.sAD_14DataSet.PricesPerVendor);
            // TODO: This line of code loads data into the 'sAD_14DataSet1.PricesPerVendor' table. You can move, or remove it, as needed.
            itemsTable.Columns.Add("Item name", typeof(string));
            itemsTable.Columns.Add("Amount", typeof(int));
            itemsTable.Columns.Add("Vendor name", typeof(string));
            itemsTable.Columns.Add("Vendor price", typeof(float));
            dg_shoppingCart.DataSource = itemsTable;
            vendorsGrid();
        }

        public void vendorsGrid()
        {
            if(item == null)
            {
                for (int i = dg_vendorsPrices.RowCount - 1; i > -1; i--)
                    dg_vendorsPrices.Rows.RemoveAt(i);
                return;
            }
            string query = "SELECT * FROM PricesPerVendor WHERE foodId_FoodItems = " + "'" + item.GetItemId() + "'";
            SqlDataAdapter dba = new SqlDataAdapter(query, con);
            SqlCommandBuilder gridTable = new SqlCommandBuilder(dba);
            var ds = new DataSet();
            dba.Fill(ds);
            dg_vendorsPrices.DataSource = ds.Tables[0];
            con.Close();
        }

        public void findItem(string name)
        {
            bool flag = false;
            foreach(FoodItem f in Program.FoodItems)
            {
                if (f.GetItemName().Equals(name))
                {
                    item = f;
                    flag = true;
                    break;
                }    
            }
            lb_itemName2.Text = name;
            lb_itemName.Text = name;
            if (!flag)
                item = null;
        }

        public void findVendor(string vendorId)
        {
            foreach (Vendor v in Program.Vendors)
            {
                if (v.GetId().Equals(vendorId))
                    vendor = v;
            }
        }

            private void btn_show_Click(object sender, EventArgs e)
        {
            string imagePath = "";
            findItem(cmb_generalItems.Text.ToString());
            vendorsGrid();
            imagePath = @"C:\Users\barbenda\Downloads\Group14 - final\Group14 - final\WindowsFormsApplicationGUIuARM\Resources\" + lb_itemName.Text.ToString()+".jpg";
            if (File.Exists(imagePath))
            {
                Image newImage = Image.FromFile(imagePath);
                img_item.Image = newImage;
                lb_itemName2.Visible = true;
            }
            else
                MessageBox.Show("לא קיים");
        }
        public void fillComboBox()
        {
            foreach (FoodItem f in Program.FoodItems)
                items.Add(f.GetItemName());
            cmb_generalItems.DataSource = items;
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (counter>0)
            {
                int rowindex = dg_shoppingCart.CurrentCell.RowIndex;
            float value = float.Parse(dg_shoppingCart.Rows[rowindex].Cells[3].Value.ToString());
            totalPrice -= value;
            this.tx_totalPrice.Text = totalPrice.ToString();
            dg_shoppingCart.Rows.RemoveAt(rowindex);
                counter--;
            }

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            for (int i = dg_shoppingCart.RowCount - 1; i > -1; i--)
                dg_shoppingCart.Rows.RemoveAt(i);
            this.tx_totalPrice.Text = "0";
            counter = 0;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string newItem = tx_itemName.Text.Trim(); // Get the value from the text box

            if (!string.IsNullOrEmpty(newItem) && img_upload.Image != null)
            {
                items.Add(newItem);
                cmb_generalItems.DataSource = null; // Clear the data source to refresh the combo box
                cmb_generalItems.DataSource = items;
                //save image by the name tx_itemName.Text
                MessageBox.Show("הפריט התווסף לרשימה");
                string folderPath = @"C:\Users\barbenda\Downloads\Group14 - final\Group14 - final\WindowsFormsApplicationGUIuARM\Resources\";
                string fileName = Path.Combine(folderPath, tx_itemName.Text.Trim() + ".jpg");
                img_upload.Image.Save(fileName, ImageFormat.Jpeg);
                tx_itemName.Text = string.Empty;
                img_upload.Image = null;
            }
            else
                MessageBox.Show("נא למלא את כל הרשומות");
        }

        private void btn_addToCart_Click(object sender, EventArgs e)
        {
            if(dg_vendorsPrices.CurrentCell == null)
            {
                MessageBox.Show("אין פריטים נבחרים");
                return;
            }
            int rowindex = dg_vendorsPrices.CurrentCell.RowIndex;
            findVendor(dg_vendorsPrices.Rows[rowindex].Cells[0].Value.ToString());
            int amount = Convert.ToInt32(amount_numeric.Value);
            float value = float.Parse(dg_vendorsPrices.Rows[rowindex].Cells[2].Value.ToString()) * amount;
            string itemName = this.lb_itemName.Text.ToString();
            itemsTable.Rows.Add(itemName, amount,vendor.GetName(), value);
            totalPrice += value;
            this.tx_totalPrice.Text = totalPrice.ToString();
            dg_shoppingCart.DataSource = itemsTable;
            MessageBox.Show("הפריט התווסף בהצלחה לעגלת הקניות");
            counter++;
        }

        private void btn_upload_Click_1(object sender, EventArgs e)
        {
            string imageLocation = "";
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Image files (*.jpg, *.png)|*.jpg;*.png|All Files (*.*)|*.*";
                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    imageLocation = dialog.FileName;

                img_upload.ImageLocation = imageLocation;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_return_crud_Click(object sender, EventArgs e)
        {
            ItemCRUD i = new ItemCRUD(employee);
            this.Hide();
            i.Show();
        }

        private void btn_pay_Click(object sender, EventArgs e)
        {
            MessageBox.Show("!ההזמנה בוצעה בהצלחה");
            Shop s = new Shop(employee);
            s.Show();
            this.Hide();

        }

       
    }
}
