﻿namespace Group14
{
    partial class UserControlDays
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Ibdays = new System.Windows.Forms.Label();
            this.ibEvent = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Ibdays
            // 
            this.Ibdays.AutoSize = true;
            this.Ibdays.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Ibdays.Location = new System.Drawing.Point(3, 10);
            this.Ibdays.Name = "Ibdays";
            this.Ibdays.Size = new System.Drawing.Size(25, 19);
            this.Ibdays.TabIndex = 0;
            this.Ibdays.Text = "00";
            // 
            // ibEvent
            // 
            this.ibEvent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ibEvent.Font = new System.Drawing.Font("David", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ibEvent.Location = new System.Drawing.Point(10, 46);
            this.ibEvent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ibEvent.Name = "ibEvent";
            this.ibEvent.Size = new System.Drawing.Size(85, 31);
            this.ibEvent.TabIndex = 1;
            this.ibEvent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ibEvent.Click += new System.EventHandler(this.ibEvent_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::WindowsFormsApplicationGUIuARM.Properties.Resources.icons8_add_new_48;
            this.pictureBox1.Location = new System.Drawing.Point(74, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 39);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.UserControlDays_Click);
            // 
            // UserControlDays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ibEvent);
            this.Controls.Add(this.Ibdays);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Name = "UserControlDays";
            this.Size = new System.Drawing.Size(109, 77);
            this.Load += new System.EventHandler(this.UserControlDays_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Ibdays;
        private System.Windows.Forms.Label ibEvent;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
