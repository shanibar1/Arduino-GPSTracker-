using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Group14
{
    public class DonatedFamilyRepresentative
    {
        private string id;
        private string address;
        private string firstName;
        private string lastName;
        private string phoneNumber;
        private bool isActive;
        private List<Package> PackagesToTrack; // relevant packages for family
        private List<Package> PackagesToReview;
        public DonatedFamilyRepresentative(string id, string address, string firstName, string lastName, string phoneNumber, bool isActive, bool is_new)
        {
            this.id = id;
            this.address = address;
            this.firstName = firstName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.isActive = isActive;
            if (is_new)
            {
                this.CreateDonatedFamilyRepresentative();
                Program.DonatedFamilyRepresentatives.Add(this);
            }
        }

        public void CreateDonatedFamilyRepresentative()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Representative @representativeId, @Address_Locations, @firstName, @lastName, @phoneNumber, @isActive";
            c.Parameters.AddWithValue("@representativeId", this.id);
            c.Parameters.AddWithValue("@Address_Locations", this.address);
            c.Parameters.AddWithValue("@firstName", this.firstName);
            c.Parameters.AddWithValue("@lastName", this.lastName);
            c.Parameters.AddWithValue("@phoneNumber", this.phoneNumber);
            c.Parameters.AddWithValue("@isActive", this.isActive);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void UpdateFamiliesRepresentatives()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.UpdateFamilies @representativeId, @Address_Locations, @firstName, @lastName, @phoneNumber, @isActive";
            c.Parameters.AddWithValue("@representativeId", this.id);
            c.Parameters.AddWithValue("@Address_Locations", this.address);
            c.Parameters.AddWithValue("@firstName", this.firstName);
            c.Parameters.AddWithValue("@lastName", this.lastName);
            c.Parameters.AddWithValue("@phoneNumber", this.phoneNumber);
            c.Parameters.AddWithValue("@isActive", this.isActive);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Delete_Family()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.DeleteFamily @Id";
            c.Parameters.AddWithValue("@Id", this.id);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
            isActive = false;
        }

        public void GiveFeedback(Package p, int rate, string feedback)
        {
            string a = p.get_packageId();
            Review review = new Review(p.get_packageId(), this.id, DateTime.Now, rate, feedback, true);
        }

        public void updatePackagesTrack()
        {
            this.PackagesToTrack = new List<Package>();
            foreach(Package p in Program.Packages)
            {
                bool correctAddress = p.get_address().Equals(this.address);
                if (correctAddress) 
                    this.PackagesToTrack.Add(p); 
            }
        }
        public void updatePackagesReview()
        {
            this.PackagesToReview = new List<Package>();
            foreach (Package p in Program.Packages)
            {
                bool correctAddress = p.get_address().Equals(this.address);
                bool firstReview = noReview(p);
                if (correctAddress && firstReview)
                    this.PackagesToReview.Add(p);
            }
        }

        private bool noReview(Package p)
        {
            foreach(Review r in Program.Reviews)
            {
                if (r.get_packageId().Equals(p.get_packageId()))
                    return false;
            }
            return true;
        }

        public Volunteer getDriver(Package package)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();
                string query = @"
                                 SELECT volunteerId
                                 FROM Volunteers AS V JOIN Packages AS P ON V.volunteerId = P.volunteerId_Volunteers JOIN FamiliesRepresentatives AS F ON P.Address_Locations = F.Address_Locations
                                 WHERE V.Type = 'Driver' AND F.representativeId = @representativeId";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@representativeId", this.id);

                    object result = command.ExecuteScalar();
                    string driverId = Convert.ToString(result);
                    return Program.seekVolunteer(driverId);
                }
            }
        }

        public string get_id()
        {
            return this.id;
        }

        public string get_address()
        {
            return this.address;
        }

        public void set_address(string address)
        {
            this.address = address;
        }

        public string get_firstName()
        {
            return this.firstName;
        }

        public void set_firstName(string firstName)
        {
            this.firstName = firstName;
        }

        public string get_lastName()
        {
            return this.lastName;
        }

        public void set_lastName(string lastName)
        {
            this.lastName = lastName;
        }
        
        public string get_phoneNumber()
        {
            return this.phoneNumber;
        }

        public void set_phoneNumber(string phoneNumber)
        {
            this.phoneNumber = phoneNumber;
        }

        public bool get_isActive()
        {
            return this.isActive;
        }

        public void set_isActive(bool isActive)
        {
            this.isActive = isActive;
        }

        public List<Package> GetPackagesReviews()
        {
            return this.PackagesToReview;
        }
        public List<Package> GetPackagesTracks()
        {
            return this.PackagesToTrack;
        }
    }
}