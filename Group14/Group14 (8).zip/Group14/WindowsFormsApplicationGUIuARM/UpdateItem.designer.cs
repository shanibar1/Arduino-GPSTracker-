﻿namespace Group14
{
    partial class UpdateItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateItem));
            this.cmb_items = new System.Windows.Forms.ComboBox();
            this.lb_item = new System.Windows.Forms.Label();
            this.textBox_Expired = new System.Windows.Forms.TextBox();
            this.textBox_units = new System.Windows.Forms.TextBox();
            this.textBox_ProductName = new System.Windows.Forms.TextBox();
            this.lb_rel = new System.Windows.Forms.Label();
            this.lb_date = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_return = new System.Windows.Forms.Button();
            this.comboBox_ItemStatus = new System.Windows.Forms.ComboBox();
            this.lb_updateItem = new System.Windows.Forms.Label();
            this.label_ErrorProductName = new System.Windows.Forms.Label();
            this.label_ErrorValidUnits = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmb_items
            // 
            this.cmb_items.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_items.FormattingEnabled = true;
            this.cmb_items.Location = new System.Drawing.Point(621, 182);
            this.cmb_items.Name = "cmb_items";
            this.cmb_items.Size = new System.Drawing.Size(236, 21);
            this.cmb_items.TabIndex = 0;
            this.cmb_items.SelectedIndexChanged += new System.EventHandler(this.cmb_items_SelectedIndexChanged);
            // 
            // lb_item
            // 
            this.lb_item.AutoSize = true;
            this.lb_item.BackColor = System.Drawing.Color.Transparent;
            this.lb_item.Font = new System.Drawing.Font("David", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_item.Location = new System.Drawing.Point(876, 185);
            this.lb_item.Name = "lb_item";
            this.lb_item.Size = new System.Drawing.Size(93, 24);
            this.lb_item.TabIndex = 1;
            this.lb_item.Text = "בחר מוצר";
            // 
            // textBox_Expired
            // 
            this.textBox_Expired.Location = new System.Drawing.Point(485, 316);
            this.textBox_Expired.Name = "textBox_Expired";
            this.textBox_Expired.Size = new System.Drawing.Size(100, 20);
            this.textBox_Expired.TabIndex = 20;
            // 
            // textBox_units
            // 
            this.textBox_units.Location = new System.Drawing.Point(621, 265);
            this.textBox_units.Name = "textBox_units";
            this.textBox_units.Size = new System.Drawing.Size(200, 20);
            this.textBox_units.TabIndex = 19;
            // 
            // textBox_ProductName
            // 
            this.textBox_ProductName.Location = new System.Drawing.Point(621, 228);
            this.textBox_ProductName.Name = "textBox_ProductName";
            this.textBox_ProductName.Size = new System.Drawing.Size(236, 20);
            this.textBox_ProductName.TabIndex = 17;
            // 
            // lb_rel
            // 
            this.lb_rel.AutoSize = true;
            this.lb_rel.BackColor = System.Drawing.Color.Transparent;
            this.lb_rel.Font = new System.Drawing.Font("David", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_rel.Location = new System.Drawing.Point(862, 366);
            this.lb_rel.Name = "lb_rel";
            this.lb_rel.Size = new System.Drawing.Size(107, 24);
            this.lb_rel.TabIndex = 16;
            this.lb_rel.Text = ":רלוונטיות";
            // 
            // lb_date
            // 
            this.lb_date.AutoSize = true;
            this.lb_date.BackColor = System.Drawing.Color.Transparent;
            this.lb_date.Font = new System.Drawing.Font("David", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_date.Location = new System.Drawing.Point(832, 316);
            this.lb_date.Name = "lb_date";
            this.lb_date.Size = new System.Drawing.Size(137, 24);
            this.lb_date.TabIndex = 15;
            this.lb_date.Text = ":תאריך תפוגה";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(827, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 24);
            this.label5.TabIndex = 14;
            this.label5.Text = ":יחידות במלאי";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_name.Font = new System.Drawing.Font("David", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.Location = new System.Drawing.Point(856, 224);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(113, 24);
            this.lb_name.TabIndex = 12;
            this.lb_name.Text = ":שם המוצר";
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Yellow;
            this.btn_update.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_update.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_update.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_update.Location = new System.Drawing.Point(0, 100);
            this.btn_update.Margin = new System.Windows.Forms.Padding(2);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(200, 103);
            this.btn_update.TabIndex = 22;
            this.btn_update.Text = "החל";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_return
            // 
            this.btn_return.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_return.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_return.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_return.Location = new System.Drawing.Point(0, 0);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(200, 100);
            this.btn_return.TabIndex = 23;
            this.btn_return.Text = "חזור";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // comboBox_ItemStatus
            // 
            this.comboBox_ItemStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ItemStatus.FormattingEnabled = true;
            this.comboBox_ItemStatus.Location = new System.Drawing.Point(621, 366);
            this.comboBox_ItemStatus.Name = "comboBox_ItemStatus";
            this.comboBox_ItemStatus.Size = new System.Drawing.Size(200, 21);
            this.comboBox_ItemStatus.TabIndex = 24;
            // 
            // lb_updateItem
            // 
            this.lb_updateItem.AutoSize = true;
            this.lb_updateItem.Dock = System.Windows.Forms.DockStyle.Right;
            this.lb_updateItem.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_updateItem.Location = new System.Drawing.Point(551, 0);
            this.lb_updateItem.Name = "lb_updateItem";
            this.lb_updateItem.Size = new System.Drawing.Size(289, 63);
            this.lb_updateItem.TabIndex = 25;
            this.lb_updateItem.Text = ":עדכן מוצר";
            // 
            // label_ErrorProductName
            // 
            this.label_ErrorProductName.AutoSize = true;
            this.label_ErrorProductName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorProductName.Font = new System.Drawing.Font("David", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ErrorProductName.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorProductName.Location = new System.Drawing.Point(456, 224);
            this.label_ErrorProductName.Name = "label_ErrorProductName";
            this.label_ErrorProductName.Size = new System.Drawing.Size(119, 24);
            this.label_ErrorProductName.TabIndex = 26;
            this.label_ErrorProductName.Text = "שם לא תקין";
            // 
            // label_ErrorValidUnits
            // 
            this.label_ErrorValidUnits.AutoSize = true;
            this.label_ErrorValidUnits.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorValidUnits.Font = new System.Drawing.Font("David", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ErrorValidUnits.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorValidUnits.Location = new System.Drawing.Point(436, 265);
            this.label_ErrorValidUnits.Name = "label_ErrorValidUnits";
            this.label_ErrorValidUnits.Size = new System.Drawing.Size(139, 24);
            this.label_ErrorValidUnits.TabIndex = 28;
            this.label_ErrorValidUnits.Text = "מספר לא תקין";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(621, 316);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 29;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.btn_update);
            this.panel1.Controls.Add(this.btn_return);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 570);
            this.panel1.TabIndex = 30;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.lb_updateItem);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(840, 100);
            this.panel2.TabIndex = 31;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // UpdateItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1040, 570);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label_ErrorValidUnits);
            this.Controls.Add(this.label_ErrorProductName);
            this.Controls.Add(this.comboBox_ItemStatus);
            this.Controls.Add(this.textBox_Expired);
            this.Controls.Add(this.textBox_units);
            this.Controls.Add(this.textBox_ProductName);
            this.Controls.Add(this.lb_rel);
            this.Controls.Add(this.lb_date);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.lb_item);
            this.Controls.Add(this.cmb_items);
            this.Name = "UpdateItem";
            this.Text = "עדכון מוצר";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_items;
        private System.Windows.Forms.Label lb_item;
        private System.Windows.Forms.TextBox textBox_Expired;
        private System.Windows.Forms.TextBox textBox_units;
        private System.Windows.Forms.TextBox textBox_ProductName;
        private System.Windows.Forms.Label lb_rel;
        private System.Windows.Forms.Label lb_date;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.ComboBox comboBox_ItemStatus;
        private System.Windows.Forms.Label lb_updateItem;
        private System.Windows.Forms.Label label_ErrorProductName;
        private System.Windows.Forms.Label label_ErrorValidUnits;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}