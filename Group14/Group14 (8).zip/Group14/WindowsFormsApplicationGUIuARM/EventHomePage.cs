﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class EventHomePage : Form
    {
        static int month, year;
        public static int static_month, static_year;
        static DateTime now;
        private Employee employee;
        public EventHomePage(Employee e)
        {
            InitializeComponent();
            now = DateTime.Now;
            this.employee = e;
        }

        private void EventHomePage_Load(object sender, EventArgs e)
        {
            dislayDays();
        }
        private void dislayDays()
        {
            month = now.Month;
            year = now.Year;
            String monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            static_month = month;
            static_year = year;
            LBDATE.Text = monthName + " " + year;
            DateTime startOfTheMonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysOfTheWeek = Convert.ToInt32(startOfTheMonth.DayOfWeek.ToString("d")) + 1;

            for (int i = 1; i < daysOfTheWeek; i++)
            {
                UserControl1 ucblank = new UserControl1();
                daycontainer.Controls.Add(ucblank);
            }
            for (int i = 1; i <= days; i++)
            {
                UserControlDays ucdays = new UserControlDays(this.employee, static_year, static_month, i);
                ucdays.days(i);
                daycontainer.Controls.Add(ucdays);
                today(ucdays, i);
                ucdays.displayEvent(i, static_month, static_year);
            }            
        }

        

       
        private void button_NextMonth_Click(object sender, EventArgs e)
        {
            daycontainer.Controls.Clear();
            month++;
            if (month > 12)
            {
                year++;
                month = 1;
            }
            static_month = month;
            static_year = year;
            String monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            LBDATE.Text = monthName + " " + year;
            DateTime startOfTheMonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysOfTheWeek = Convert.ToInt32(startOfTheMonth.DayOfWeek.ToString("d")) + 1;

            for (int i = 1; i < daysOfTheWeek; i++)
            {
                UserControl1 ucblank = new UserControl1();
                daycontainer.Controls.Add(ucblank);
            }
            for (int i = 1; i <= days; i++)
            {
                UserControlDays ucdays = new UserControlDays(this.employee, static_year, static_month, i);
                ucdays.days(i);
                daycontainer.Controls.Add(ucdays);
                today(ucdays, i);
                ucdays.displayEvent(i, static_month, static_year);
            }
        }

      

        private void button_Return_Click(object sender, EventArgs e)
        {
            EmployeeManage em = new EmployeeManage(this.employee);
            em.Show();
            this.Hide();
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button_Previous_Click(object sender, EventArgs e)
        {
            daycontainer.Controls.Clear();
            month--;

            if (month < 1)
            {
                year--;
                month = 12;
            }
            static_month = month;
            static_year = year;
            String monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            LBDATE.Text = monthName + " " + year;
            DateTime startOfTheMonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysOfTheWeek = Convert.ToInt32(startOfTheMonth.DayOfWeek.ToString("d")) + 1;

            for (int i = 1; i < daysOfTheWeek; i++)
            {
                UserControl1 ucblank = new UserControl1();
                daycontainer.Controls.Add(ucblank);
            }
            for (int i = 1; i <= days; i++)
            {
                UserControlDays ucdays = new UserControlDays(this.employee, static_year, static_month, i);
                ucdays.days(i);
                daycontainer.Controls.Add(ucdays);
                today(ucdays, i);
                ucdays.displayEvent(i, static_month, static_year);
            }
        }

        private void today(UserControlDays ucdays, int i)
        {
            bool day = i == now.Day;
            bool months = month == now.Month;
            bool years = year == now.Year;
            if (day && months && years)
                ucdays.BackColor = Color.Thistle;
            else
                ucdays.BackColor = Color.White;
        }
    }
}
