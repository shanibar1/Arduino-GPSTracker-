﻿namespace Group14
{
    partial class VendorCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VendorCRUD));
            this.button_Exit = new System.Windows.Forms.Button();
            this.button_ReturnToHomePage = new System.Windows.Forms.Button();
            this.button_CreateNewVendor = new System.Windows.Forms.Button();
            this.button_WatchExistVendor = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button_Exit
            // 
            this.button_Exit.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(700, 478);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 10;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_ReturnToHomePage
            // 
            this.button_ReturnToHomePage.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button_ReturnToHomePage.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToHomePage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_ReturnToHomePage.Location = new System.Drawing.Point(0, 387);
            this.button_ReturnToHomePage.Name = "button_ReturnToHomePage";
            this.button_ReturnToHomePage.Size = new System.Drawing.Size(243, 76);
            this.button_ReturnToHomePage.TabIndex = 9;
            this.button_ReturnToHomePage.Text = "חזור לעמוד הניהול";
            this.button_ReturnToHomePage.UseVisualStyleBackColor = false;
            this.button_ReturnToHomePage.Click += new System.EventHandler(this.button_ReturnToHomePage_Click);
            // 
            // button_CreateNewVendor
            // 
            this.button_CreateNewVendor.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button_CreateNewVendor.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_CreateNewVendor.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_CreateNewVendor.Location = new System.Drawing.Point(0, 304);
            this.button_CreateNewVendor.Name = "button_CreateNewVendor";
            this.button_CreateNewVendor.Size = new System.Drawing.Size(243, 77);
            this.button_CreateNewVendor.TabIndex = 8;
            this.button_CreateNewVendor.Text = "צור ספק חדש";
            this.button_CreateNewVendor.UseVisualStyleBackColor = false;
            this.button_CreateNewVendor.Click += new System.EventHandler(this.button_CreateNewVendor_Click);
            // 
            // button_WatchExistVendor
            // 
            this.button_WatchExistVendor.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button_WatchExistVendor.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_WatchExistVendor.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_WatchExistVendor.Location = new System.Drawing.Point(0, 221);
            this.button_WatchExistVendor.Name = "button_WatchExistVendor";
            this.button_WatchExistVendor.Size = new System.Drawing.Size(243, 77);
            this.button_WatchExistVendor.TabIndex = 7;
            this.button_WatchExistVendor.Text = "צפה בספק קיים";
            this.button_WatchExistVendor.UseVisualStyleBackColor = false;
            this.button_WatchExistVendor.Click += new System.EventHandler(this.button_WatchExistVendor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(453, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 63);
            this.label1.TabIndex = 6;
            this.label1.Text = "ניהול ספקים";
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(243, 513);
            this.splitter1.TabIndex = 11;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(243, 215);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(326, 99);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(369, 302);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // VendorCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(787, 513);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.button_ReturnToHomePage);
            this.Controls.Add(this.button_CreateNewVendor);
            this.Controls.Add(this.button_WatchExistVendor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.splitter1);
            this.Name = "VendorCRUD";
            this.Text = "ניהול ספקים";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Button button_ReturnToHomePage;
        private System.Windows.Forms.Button button_CreateNewVendor;
        private System.Windows.Forms.Button button_WatchExistVendor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}