using System;
using System.Data.SqlClient;

namespace Group14
{
    public class Package {

        SqlConnection con = new SqlConnection("Data Source = IEMDBS; Initial Catalog = SAD_14; Integrated Security = True");
        private string packageId;
        private string eventId;
        private string volunteerId;
        private string address;
        private PackageStatus packageStatus;

        public Package(string packageId, string eventId, string volunteerId, string address, PackageStatus packageStatus, bool is_new)
        {
            this.packageId = packageId;
            this.eventId = eventId;
            this.volunteerId = volunteerId;
            this.address = address;
            DateTime dt = DateTime.Now;
            dt = dt.AddMinutes(-30);
            if (this.getDate() == dt)
                this.packageStatus = PackageStatus.InTransit;
            else if (this.getDate() > dt)
                this.packageStatus = PackageStatus.Pending;
            else
                this.packageStatus = PackageStatus.Delivered;
            if (is_new)
            {
                this.CreatePackage();
                Program.Packages.Add(this);
            }
        }

        public void CreatePackage()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Package @packageId, @eventId_Events, @volunteerId_Volunteers, @Address_Locations, @packageStatus";
            c.Parameters.AddWithValue("@packageId", this.packageId);
            c.Parameters.AddWithValue("@eventId_Events", this.eventId);
            c.Parameters.AddWithValue("@volunteerId_Volunteers", this.volunteerId);
            c.Parameters.AddWithValue("@Address_Locations", this.address);
            c.Parameters.AddWithValue("@packageStatus", this.packageStatus.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void UpdatePackage(PackageStatus ps)
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.UpdatePackage @packageId, @eventId_Events, @volunteerId_Volunteers, @Address_Locations, @packageStatus";
            c.Parameters.AddWithValue("@packageId", this.packageId);
            c.Parameters.AddWithValue("@eventId_Events", this.eventId);
            c.Parameters.AddWithValue("@volunteerId_Volunteers", this.volunteerId);
            c.Parameters.AddWithValue("@Address_Locations", this.address);
            c.Parameters.AddWithValue("@packageStatus", ps.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public DateTime getDate()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();

                string query = @"
                                SELECT E.Date
                                FROM Packages AS P JOIN Events AS E ON P.eventId_Events = E.eventId
                                WHERE E.eventId = @eventId
                                GROUP BY E.Date";

                using (SqlCommand command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@eventId", this.eventId);

                    object result = command.ExecuteScalar();
                    return Convert.ToDateTime(result);
                }
            }
        }

        public string get_packageId()
        {
            return this.packageId;
        }

        public void set_packageId(string packageId)
        {
            this.packageId = packageId;
        }

        public string get_eventId()
        {
            return this.eventId;
        }

        public void set_eventId(string eventId)
        {
            this.eventId = eventId;
        }

        public string get_volunteerId()
        {
            return this.volunteerId;
        }

        public void set_volunteerId(string volunteerId)
        {
            this.volunteerId = volunteerId;
        }

        public string get_address()
        {
            return this.address;
        }

        public void set_address(string address)
        {
            this.address = address;
        }

        public PackageStatus getPackageStatus()
        {
            return this.packageStatus;
        }

        public void setPackageStatus(PackageStatus packageStatus)
        {
            this.packageStatus = packageStatus;
        }
    }
}