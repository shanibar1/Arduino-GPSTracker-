﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Group14
{
    public enum PackageStatus
    {
        Pending,
        InTransit,
        Delivered
    }
}
