﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class DonatedFamilyRepresentativeManage : Form
    {
        private DonatedFamilyRepresentative df;
        public DonatedFamilyRepresentativeManage(DonatedFamilyRepresentative d)
        {
            InitializeComponent();
            this.df = d;
            this.labelFamily.Text = "שלום למשפחת " + df.get_lastName() + "!";
            this.df.updatePackagesReview();
            this.df.updatePackagesTrack();
        }

        private void button_GiveFeedback_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeGiveFeedback gf = new DonatedFamilyRepresentativeGiveFeedback(this.df);
            gf.Show();
            this.Hide();
        }

        private void button_BackToHomePage_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }

        private void button_TrackPackage_Click(object sender, EventArgs e)
        {
            this.Hide();
            DonatedFamilyRepresentativeWaitingRoom wr = new DonatedFamilyRepresentativeWaitingRoom(this.df, packageToTrack());
            wr.Show();
        }

        private Package packageToTrack()
        {
            this.df.updatePackagesTrack();

            foreach (Package p in this.df.GetPackagesTracks())
            {
                if (p.getDate() == DateTime.Today && !p.getPackageStatus().ToString().Equals("Delivered"))
                    return p;
            }
            return null;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            DonatedFamilyRepresentativeWaitingRoom wr = new DonatedFamilyRepresentativeWaitingRoom(this.df, packageToTrack());
            wr.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeGiveFeedback gf = new DonatedFamilyRepresentativeGiveFeedback(this.df);
            gf.Show();
            this.Hide();
        }
    }
}
