﻿namespace Group14
{
    partial class EmployeeManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeManage));
            this.button_ManageItems = new System.Windows.Forms.Button();
            this.button_ManageEvent = new System.Windows.Forms.Button();
            this.button_ViewReports = new System.Windows.Forms.Button();
            this.button_DonatedFamilyRepresentativeCRUD = new System.Windows.Forms.Button();
            this.button_EmployeeCRUD = new System.Windows.Forms.Button();
            this.buttonWatchReviews = new System.Windows.Forms.Button();
            this.button_VolunteerCRUD = new System.Windows.Forms.Button();
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_FillForms = new System.Windows.Forms.Button();
            this.button_OpenEventReport = new System.Windows.Forms.Button();
            this.buttonReports = new System.Windows.Forms.Button();
            this.panelManege = new System.Windows.Forms.Panel();
            this.buttonManageVendors = new System.Windows.Forms.Button();
            this.buttonManege = new System.Windows.Forms.Button();
            this.button_BackToHomePage = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.pictureBoxWhatsapp = new System.Windows.Forms.PictureBox();
            this.labelSendMessage = new System.Windows.Forms.Label();
            this.pictureBox_Alma = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelSideMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelManege.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhatsapp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Alma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_ManageItems
            // 
            this.button_ManageItems.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_ManageItems, "button_ManageItems");
            this.button_ManageItems.ForeColor = System.Drawing.Color.LightGray;
            this.button_ManageItems.Name = "button_ManageItems";
            this.button_ManageItems.UseVisualStyleBackColor = true;
            this.button_ManageItems.Click += new System.EventHandler(this.button_ManageItems_Click);
            // 
            // button_ManageEvent
            // 
            this.button_ManageEvent.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_ManageEvent, "button_ManageEvent");
            this.button_ManageEvent.ForeColor = System.Drawing.Color.LightGray;
            this.button_ManageEvent.Name = "button_ManageEvent";
            this.button_ManageEvent.UseVisualStyleBackColor = true;
            this.button_ManageEvent.Click += new System.EventHandler(this.button_ManageEvent_Click);
            // 
            // button_ViewReports
            // 
            this.button_ViewReports.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.button_ViewReports.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_ViewReports, "button_ViewReports");
            this.button_ViewReports.ForeColor = System.Drawing.Color.LightGray;
            this.button_ViewReports.Name = "button_ViewReports";
            this.button_ViewReports.UseVisualStyleBackColor = false;
            this.button_ViewReports.Click += new System.EventHandler(this.button_ViewReports_Click);
            // 
            // button_DonatedFamilyRepresentativeCRUD
            // 
            this.button_DonatedFamilyRepresentativeCRUD.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_DonatedFamilyRepresentativeCRUD, "button_DonatedFamilyRepresentativeCRUD");
            this.button_DonatedFamilyRepresentativeCRUD.ForeColor = System.Drawing.Color.LightGray;
            this.button_DonatedFamilyRepresentativeCRUD.Name = "button_DonatedFamilyRepresentativeCRUD";
            this.button_DonatedFamilyRepresentativeCRUD.UseVisualStyleBackColor = true;
            this.button_DonatedFamilyRepresentativeCRUD.Click += new System.EventHandler(this.button_DonatedFamilyRepresentativeCRUD_Click);
            // 
            // button_EmployeeCRUD
            // 
            this.button_EmployeeCRUD.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_EmployeeCRUD, "button_EmployeeCRUD");
            this.button_EmployeeCRUD.ForeColor = System.Drawing.Color.LightGray;
            this.button_EmployeeCRUD.Name = "button_EmployeeCRUD";
            this.button_EmployeeCRUD.UseVisualStyleBackColor = true;
            this.button_EmployeeCRUD.Click += new System.EventHandler(this.button_EmployeeCRUD_Click);
            // 
            // buttonWatchReviews
            // 
            this.buttonWatchReviews.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.buttonWatchReviews.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.buttonWatchReviews, "buttonWatchReviews");
            this.buttonWatchReviews.ForeColor = System.Drawing.Color.LightGray;
            this.buttonWatchReviews.Name = "buttonWatchReviews";
            this.buttonWatchReviews.UseVisualStyleBackColor = false;
            // 
            // button_VolunteerCRUD
            // 
            this.button_VolunteerCRUD.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_VolunteerCRUD, "button_VolunteerCRUD");
            this.button_VolunteerCRUD.ForeColor = System.Drawing.Color.LightGray;
            this.button_VolunteerCRUD.Name = "button_VolunteerCRUD";
            this.button_VolunteerCRUD.UseVisualStyleBackColor = true;
            this.button_VolunteerCRUD.Click += new System.EventHandler(this.button_VolunteerCRUD_Click);
            // 
            // panelSideMenu
            // 
            resources.ApplyResources(this.panelSideMenu, "panelSideMenu");
            this.panelSideMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelSideMenu.Controls.Add(this.panel1);
            this.panelSideMenu.Controls.Add(this.buttonReports);
            this.panelSideMenu.Controls.Add(this.panelManege);
            this.panelSideMenu.Controls.Add(this.buttonManege);
            this.panelSideMenu.Controls.Add(this.button_BackToHomePage);
            this.panelSideMenu.Name = "panelSideMenu";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_FillForms);
            this.panel1.Controls.Add(this.button_OpenEventReport);
            this.panel1.Controls.Add(this.button_ViewReports);
            this.panel1.Controls.Add(this.buttonWatchReviews);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // button_FillForms
            // 
            this.button_FillForms.BackColor = System.Drawing.SystemColors.WindowFrame;
            resources.ApplyResources(this.button_FillForms, "button_FillForms");
            this.button_FillForms.ForeColor = System.Drawing.Color.LightGray;
            this.button_FillForms.Name = "button_FillForms";
            this.button_FillForms.UseVisualStyleBackColor = false;
            // 
            // button_OpenEventReport
            // 
            this.button_OpenEventReport.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.button_OpenEventReport.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_OpenEventReport, "button_OpenEventReport");
            this.button_OpenEventReport.ForeColor = System.Drawing.Color.LightGray;
            this.button_OpenEventReport.Name = "button_OpenEventReport";
            this.button_OpenEventReport.UseVisualStyleBackColor = false;
            // 
            // buttonReports
            // 
            this.buttonReports.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonReports.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.buttonReports, "buttonReports");
            this.buttonReports.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonReports.Name = "buttonReports";
            this.buttonReports.UseVisualStyleBackColor = false;
            this.buttonReports.Click += new System.EventHandler(this.buttonReports_Click);
            // 
            // panelManege
            // 
            resources.ApplyResources(this.panelManege, "panelManege");
            this.panelManege.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panelManege.Controls.Add(this.buttonManageVendors);
            this.panelManege.Controls.Add(this.button_ManageItems);
            this.panelManege.Controls.Add(this.button_EmployeeCRUD);
            this.panelManege.Controls.Add(this.button_VolunteerCRUD);
            this.panelManege.Controls.Add(this.button_ManageEvent);
            this.panelManege.Controls.Add(this.button_DonatedFamilyRepresentativeCRUD);
            this.panelManege.Name = "panelManege";
            // 
            // buttonManageVendors
            // 
            this.buttonManageVendors.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.buttonManageVendors, "buttonManageVendors");
            this.buttonManageVendors.ForeColor = System.Drawing.Color.LightGray;
            this.buttonManageVendors.Name = "buttonManageVendors";
            this.buttonManageVendors.UseVisualStyleBackColor = true;
            this.buttonManageVendors.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonManege
            // 
            this.buttonManege.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonManege.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.buttonManege, "buttonManege");
            this.buttonManege.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonManege.Name = "buttonManege";
            this.buttonManege.UseVisualStyleBackColor = false;
            this.buttonManege.Click += new System.EventHandler(this.buttonManege_Click);
            // 
            // button_BackToHomePage
            // 
            this.button_BackToHomePage.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_BackToHomePage.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.button_BackToHomePage, "button_BackToHomePage");
            this.button_BackToHomePage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_BackToHomePage.Name = "button_BackToHomePage";
            this.button_BackToHomePage.UseVisualStyleBackColor = false;
            this.button_BackToHomePage.Click += new System.EventHandler(this.button_BackToHomePage_Click);
            // 
            // labelName
            // 
            resources.ApplyResources(this.labelName, "labelName");
            this.labelName.Name = "labelName";
            // 
            // pictureBoxWhatsapp
            // 
            this.pictureBoxWhatsapp.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.pictureBoxWhatsapp, "pictureBoxWhatsapp");
            this.pictureBoxWhatsapp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxWhatsapp.Image = global::WindowsFormsApplicationGUIuARM.Properties.Resources.whatsapp_logo;
            this.pictureBoxWhatsapp.Name = "pictureBoxWhatsapp";
            this.pictureBoxWhatsapp.TabStop = false;
            this.pictureBoxWhatsapp.Click += new System.EventHandler(this.pictureBoxWhatsapp_Click);
            // 
            // labelSendMessage
            // 
            resources.ApplyResources(this.labelSendMessage, "labelSendMessage");
            this.labelSendMessage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelSendMessage.ForeColor = System.Drawing.Color.ForestGreen;
            this.labelSendMessage.Name = "labelSendMessage";
            this.labelSendMessage.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox_Alma
            // 
            resources.ApplyResources(this.pictureBox_Alma, "pictureBox_Alma");
            this.pictureBox_Alma.Name = "pictureBox_Alma";
            this.pictureBox_Alma.TabStop = false;
            this.pictureBox_Alma.Click += new System.EventHandler(this.pictureBox_Alma_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1700;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "WhatsApp Image 2023-06-13 at 14.41.03.jpeg");
            this.imageList1.Images.SetKeyName(1, "WhatsApp Image 2023-06-13 at 14.41.04 (1).jpeg");
            this.imageList1.Images.SetKeyName(2, "WhatsApp Image 2023-06-13 at 14.41.04 (2).jpeg");
            this.imageList1.Images.SetKeyName(3, "WhatsApp Image 2023-06-13 at 14.41.04.jpeg");
            this.imageList1.Images.SetKeyName(4, "WhatsApp Image 2023-06-13 at 14.41.05 (1).jpeg");
            this.imageList1.Images.SetKeyName(5, "WhatsApp Image 2023-06-13 at 14.41.05 (2).jpeg");
            this.imageList1.Images.SetKeyName(6, "WhatsApp Image 2023-06-13 at 14.41.05.jpeg");
            this.imageList1.Images.SetKeyName(7, "WhatsApp Image 2023-06-13 at 14.50.24.jpeg");
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Name = "label1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::WindowsFormsApplicationGUIuARM.Properties.Resources.My_project;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // EmployeeManage
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            resources.ApplyResources(this, "$this");
            this.BackColor = System.Drawing.Color.LightCyan;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox_Alma);
            this.Controls.Add(this.labelSendMessage);
            this.Controls.Add(this.pictureBoxWhatsapp);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.panelSideMenu);
            this.Name = "EmployeeManage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.EmployeeManage_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelSideMenu.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panelManege.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhatsapp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Alma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_ManageItems;
        private System.Windows.Forms.Button button_ManageEvent;
        private System.Windows.Forms.Button button_ViewReports;
        private System.Windows.Forms.Button button_DonatedFamilyRepresentativeCRUD;
        private System.Windows.Forms.Button button_EmployeeCRUD;
        private System.Windows.Forms.Button buttonWatchReviews;
        private System.Windows.Forms.Button button_VolunteerCRUD;
        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Button buttonManege;
        private System.Windows.Forms.Button button_BackToHomePage;
        private System.Windows.Forms.Panel panelManege;
        private System.Windows.Forms.Button button_OpenEventReport;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Button button_FillForms;
        private System.Windows.Forms.Button buttonReports;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonManageVendors;
        private System.Windows.Forms.PictureBox pictureBoxWhatsapp;
        private System.Windows.Forms.Label labelSendMessage;
        private System.Windows.Forms.PictureBox pictureBox_Alma;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}