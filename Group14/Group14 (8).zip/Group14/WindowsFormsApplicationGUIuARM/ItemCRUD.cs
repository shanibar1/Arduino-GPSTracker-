﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class ItemCRUD : Form
    {
        private Employee employee;
        public ItemCRUD(Employee employee)
        {
            InitializeComponent();
            this.employee = employee;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button_AddNewItem_Click(object sender, EventArgs e)
        {
            Shop cv = new Shop(employee);
            cv.Show();
            this.Hide();
        }

        private void button_ReadItem_Click(object sender, EventArgs e)
        {
            ReadItems ic = new ReadItems(employee);
            ic.Show();
            this.Hide();
        }

        private void ReturnTo_Click(object sender, EventArgs e)
        {
            EmployeeManage em = new EmployeeManage(this.employee);
            em.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Shop cv = new Shop(employee);
            cv.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            ReadItems ic = new ReadItems(employee);
            ic.Show();
            this.Hide();
        }
    }
}
