﻿namespace Group14
{
    partial class VolunteerCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VolunteerCRUD));
            this.label1 = new System.Windows.Forms.Label();
            this.button_WatchExistVolunteer = new System.Windows.Forms.Button();
            this.button_CreateNewVolunteer = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.button_Exit = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(734, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(381, 63);
            this.label1.TabIndex = 0;
            this.label1.Text = "ניהול מתנדבים";
            // 
            // button_WatchExistVolunteer
            // 
            this.button_WatchExistVolunteer.BackColor = System.Drawing.Color.BlueViolet;
            this.button_WatchExistVolunteer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_WatchExistVolunteer.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_WatchExistVolunteer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_WatchExistVolunteer.Location = new System.Drawing.Point(836, 458);
            this.button_WatchExistVolunteer.Name = "button_WatchExistVolunteer";
            this.button_WatchExistVolunteer.Size = new System.Drawing.Size(243, 87);
            this.button_WatchExistVolunteer.TabIndex = 1;
            this.button_WatchExistVolunteer.Text = "צפה במתנדב קיים";
            this.button_WatchExistVolunteer.UseVisualStyleBackColor = false;
            this.button_WatchExistVolunteer.Click += new System.EventHandler(this.button_WatchExistVolunteer_Click);
            // 
            // button_CreateNewVolunteer
            // 
            this.button_CreateNewVolunteer.BackColor = System.Drawing.Color.BlueViolet;
            this.button_CreateNewVolunteer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_CreateNewVolunteer.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_CreateNewVolunteer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_CreateNewVolunteer.Location = new System.Drawing.Point(438, 458);
            this.button_CreateNewVolunteer.Name = "button_CreateNewVolunteer";
            this.button_CreateNewVolunteer.Size = new System.Drawing.Size(243, 87);
            this.button_CreateNewVolunteer.TabIndex = 2;
            this.button_CreateNewVolunteer.Text = "צור מתנדב חדש";
            this.button_CreateNewVolunteer.UseVisualStyleBackColor = false;
            this.button_CreateNewVolunteer.Click += new System.EventHandler(this.button_CreateNewVolunteer_Click);
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.SystemColors.GrayText;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 356);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(304, 87);
            this.button_ReturnToEmployeeManage.TabIndex = 3;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // button_Exit
            // 
            this.button_Exit.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_Exit.Location = new System.Drawing.Point(1040, 598);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 4;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(304, 633);
            this.splitter1.TabIndex = 5;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(304, 164);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(475, 171);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(186, 167);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(850, 171);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(186, 167);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 22;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // VolunteerCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1127, 633);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.button_ReturnToEmployeeManage);
            this.Controls.Add(this.button_CreateNewVolunteer);
            this.Controls.Add(this.button_WatchExistVolunteer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.splitter1);
            this.Name = "VolunteerCRUD";
            this.Text = "ניהול מתנדבים";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_WatchExistVolunteer;
        private System.Windows.Forms.Button button_CreateNewVolunteer;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}