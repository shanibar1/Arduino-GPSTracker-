﻿namespace Group14
{
    partial class DonatedFamilyRepresentativeManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DonatedFamilyRepresentativeManage));
            this.button_GiveFeedback = new System.Windows.Forms.Button();
            this.button_TrackPackage = new System.Windows.Forms.Button();
            this.button_BackToHomePage = new System.Windows.Forms.Button();
            this.labelFamily = new System.Windows.Forms.Label();
            this.button_Exit = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button_GiveFeedback
            // 
            this.button_GiveFeedback.BackColor = System.Drawing.Color.YellowGreen;
            this.button_GiveFeedback.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_GiveFeedback.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_GiveFeedback.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_GiveFeedback.Location = new System.Drawing.Point(453, 375);
            this.button_GiveFeedback.Name = "button_GiveFeedback";
            this.button_GiveFeedback.Size = new System.Drawing.Size(189, 75);
            this.button_GiveFeedback.TabIndex = 0;
            this.button_GiveFeedback.Text = "מילוי משוב";
            this.button_GiveFeedback.UseVisualStyleBackColor = false;
            this.button_GiveFeedback.Click += new System.EventHandler(this.button_GiveFeedback_Click);
            // 
            // button_TrackPackage
            // 
            this.button_TrackPackage.BackColor = System.Drawing.Color.YellowGreen;
            this.button_TrackPackage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_TrackPackage.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_TrackPackage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_TrackPackage.Location = new System.Drawing.Point(713, 375);
            this.button_TrackPackage.Name = "button_TrackPackage";
            this.button_TrackPackage.Size = new System.Drawing.Size(189, 75);
            this.button_TrackPackage.TabIndex = 1;
            this.button_TrackPackage.Text = "מעקב אחר חבילה";
            this.button_TrackPackage.UseVisualStyleBackColor = false;
            this.button_TrackPackage.Click += new System.EventHandler(this.button_TrackPackage_Click);
            // 
            // button_BackToHomePage
            // 
            this.button_BackToHomePage.BackColor = System.Drawing.Color.Purple;
            this.button_BackToHomePage.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_BackToHomePage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_BackToHomePage.Location = new System.Drawing.Point(0, 514);
            this.button_BackToHomePage.Name = "button_BackToHomePage";
            this.button_BackToHomePage.Size = new System.Drawing.Size(335, 64);
            this.button_BackToHomePage.TabIndex = 2;
            this.button_BackToHomePage.Text = "חזור";
            this.button_BackToHomePage.UseVisualStyleBackColor = false;
            this.button_BackToHomePage.Click += new System.EventHandler(this.button_BackToHomePage_Click);
            // 
            // labelFamily
            // 
            this.labelFamily.AutoSize = true;
            this.labelFamily.Dock = System.Windows.Forms.DockStyle.Right;
            this.labelFamily.Font = new System.Drawing.Font("David", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFamily.Location = new System.Drawing.Point(778, 0);
            this.labelFamily.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFamily.Name = "labelFamily";
            this.labelFamily.Size = new System.Drawing.Size(255, 27);
            this.labelFamily.TabIndex = 3;
            this.labelFamily.Text = "שלום למשפחה הנתרמת";
            // 
            // button_Exit
            // 
            this.button_Exit.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(956, 568);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(65, 30);
            this.button_Exit.TabIndex = 11;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(335, 610);
            this.splitter1.TabIndex = 12;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(335, 275);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(453, 171);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(186, 167);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 21;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(716, 171);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(186, 167);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // DonatedFamilyRepresentativeManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1033, 610);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.labelFamily);
            this.Controls.Add(this.button_BackToHomePage);
            this.Controls.Add(this.button_TrackPackage);
            this.Controls.Add(this.button_GiveFeedback);
            this.Controls.Add(this.splitter1);
            this.Name = "DonatedFamilyRepresentativeManage";
            this.Text = "מסך משפחה";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_GiveFeedback;
        private System.Windows.Forms.Button button_TrackPackage;
        private System.Windows.Forms.Button button_BackToHomePage;
        private System.Windows.Forms.Label labelFamily;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}