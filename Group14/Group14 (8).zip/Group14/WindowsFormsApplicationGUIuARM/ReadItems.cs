﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class ReadItems : Form
    {
        private Employee employee;
        public ReadItems(Employee employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private void readItems_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sAD_14DataSet.FoodItems' table. You can move, or remove it, as needed.
            this.foodItemsTableAdapter.Fill(this.sAD_14DataSet.FoodItems);
        }


        private void NewMethod()
        {
            //foodItemsTableAdapter.Filter = string.Empty;
        }

        private void readItems_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sAD_14DataSet1.FoodItems' table. You can move, or remove it, as needed.
            this.foodItemsTableAdapter1.Fill(this.sAD_14DataSet1.FoodItems);

        }

        private void sAD14DataSet1BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void buttonReturnToItemCrud_Click(object sender, EventArgs e)
        {
            ItemCRUD ic = new ItemCRUD(employee);
            ic.Show();
            this.Close();
        }

        private void addItem_Click(object sender, EventArgs e)
        {
            AddItemToInventory a = new AddItemToInventory(employee);
            a.Show();
            this.Close();
        }

        private void updateItem_Click(object sender, EventArgs e)
        {
            UpdateItem a = new UpdateItem(employee);
            a.Show();
            this.Close();
        }

    }  
}
