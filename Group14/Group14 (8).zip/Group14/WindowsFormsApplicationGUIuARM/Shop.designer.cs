﻿using WindowsFormsApplicationGUIuARM;

namespace Group14
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_vendorsPrices = new System.Windows.Forms.DataGridView();
            this.vendorIdVendorsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodIdFoodItemsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricesPerVendorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sAD_14DataSet = new WindowsFormsApplicationGUIuARM.SAD_14DataSet();
            this.btn_addToCart = new System.Windows.Forms.Button();
            this.amount_numeric = new System.Windows.Forms.NumericUpDown();
            this.lb_amount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_itemName = new System.Windows.Forms.Label();
            this.btn_remove = new System.Windows.Forms.Button();
            this.dg_shoppingCart = new System.Windows.Forms.DataGridView();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_pay = new System.Windows.Forms.Button();
            this.tx_totalPrice = new System.Windows.Forms.TextBox();
            this.lb_total_price = new System.Windows.Forms.Label();
            this.lb_shoppingCart = new System.Windows.Forms.Label();
            this.lb_chooseItem = new System.Windows.Forms.Label();
            this.pricesPerVendorTableAdapter = new WindowsFormsApplicationGUIuARM.SAD_14DataSetTableAdapters.PricesPerVendorTableAdapter();
            this.cmb_generalItems = new System.Windows.Forms.ComboBox();
            this.lb_itemName2 = new System.Windows.Forms.Label();
            this.lb_addItem = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tx_itemName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.img_upload = new System.Windows.Forms.PictureBox();
            this.img_item = new System.Windows.Forms.PictureBox();
            this.btn_upload = new System.Windows.Forms.Button();
            this.btn_return_crud = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dg_vendorsPrices)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pricesPerVendorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD_14DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount_numeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_shoppingCart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_upload)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_item)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_show
            // 
            this.btn_show.BackColor = System.Drawing.Color.Orange;
            this.btn_show.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold);
            this.btn_show.Location = new System.Drawing.Point(28, 49);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(51, 37);
            this.btn_show.TabIndex = 38;
            this.btn_show.Text = "הצג";
            this.btn_show.UseVisualStyleBackColor = false;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_vendorsPrices
            // 
            this.dg_vendorsPrices.AllowUserToAddRows = false;
            this.dg_vendorsPrices.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.dg_vendorsPrices.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dg_vendorsPrices.AutoGenerateColumns = false;
            this.dg_vendorsPrices.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dg_vendorsPrices.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dg_vendorsPrices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_vendorsPrices.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vendorIdVendorsDataGridViewTextBoxColumn,
            this.foodIdFoodItemsDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dg_vendorsPrices.DataSource = this.pricesPerVendorBindingSource;
            this.dg_vendorsPrices.Location = new System.Drawing.Point(35, 57);
            this.dg_vendorsPrices.Name = "dg_vendorsPrices";
            this.dg_vendorsPrices.ReadOnly = true;
            this.dg_vendorsPrices.Size = new System.Drawing.Size(365, 165);
            this.dg_vendorsPrices.TabIndex = 39;
            // 
            // vendorIdVendorsDataGridViewTextBoxColumn
            // 
            this.vendorIdVendorsDataGridViewTextBoxColumn.DataPropertyName = "vendorId_Vendors";
            this.vendorIdVendorsDataGridViewTextBoxColumn.HeaderText = "vendor Id";
            this.vendorIdVendorsDataGridViewTextBoxColumn.Name = "vendorIdVendorsDataGridViewTextBoxColumn";
            this.vendorIdVendorsDataGridViewTextBoxColumn.ReadOnly = true;
            this.vendorIdVendorsDataGridViewTextBoxColumn.Width = 130;
            // 
            // foodIdFoodItemsDataGridViewTextBoxColumn
            // 
            this.foodIdFoodItemsDataGridViewTextBoxColumn.DataPropertyName = "foodId_FoodItems";
            this.foodIdFoodItemsDataGridViewTextBoxColumn.HeaderText = "food Id";
            this.foodIdFoodItemsDataGridViewTextBoxColumn.Name = "foodIdFoodItemsDataGridViewTextBoxColumn";
            this.foodIdFoodItemsDataGridViewTextBoxColumn.ReadOnly = true;
            this.foodIdFoodItemsDataGridViewTextBoxColumn.Width = 130;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.FillWeight = 40F;
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 50;
            // 
            // pricesPerVendorBindingSource
            // 
            this.pricesPerVendorBindingSource.DataMember = "PricesPerVendor";
            this.pricesPerVendorBindingSource.DataSource = this.sAD_14DataSet;
            // 
            // sAD_14DataSet
            // 
            this.sAD_14DataSet.DataSetName = "SAD_14DataSet";
            this.sAD_14DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_addToCart
            // 
            this.btn_addToCart.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold);
            this.btn_addToCart.Location = new System.Drawing.Point(35, 283);
            this.btn_addToCart.Name = "btn_addToCart";
            this.btn_addToCart.Size = new System.Drawing.Size(112, 49);
            this.btn_addToCart.TabIndex = 42;
            this.btn_addToCart.Text = "הוסף לעגלת הקניות";
            this.btn_addToCart.UseVisualStyleBackColor = true;
            this.btn_addToCart.Click += new System.EventHandler(this.btn_addToCart_Click);
            // 
            // amount_numeric
            // 
            this.amount_numeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.amount_numeric.Location = new System.Drawing.Point(289, 283);
            this.amount_numeric.Margin = new System.Windows.Forms.Padding(2);
            this.amount_numeric.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.amount_numeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.amount_numeric.Name = "amount_numeric";
            this.amount_numeric.Size = new System.Drawing.Size(39, 26);
            this.amount_numeric.TabIndex = 41;
            this.amount_numeric.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lb_amount
            // 
            this.lb_amount.AutoSize = true;
            this.lb_amount.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_amount.Location = new System.Drawing.Point(332, 283);
            this.lb_amount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_amount.Name = "lb_amount";
            this.lb_amount.Size = new System.Drawing.Size(45, 16);
            this.lb_amount.TabIndex = 40;
            this.lb_amount.Text = ":כמות";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("David", 20F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(256, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 27);
            this.label1.TabIndex = 44;
            this.label1.Text = "ספקים עבור הפריט";
            // 
            // lb_itemName
            // 
            this.lb_itemName.AutoSize = true;
            this.lb_itemName.Font = new System.Drawing.Font("David", 20F, System.Drawing.FontStyle.Bold);
            this.lb_itemName.Location = new System.Drawing.Point(74, 8);
            this.lb_itemName.Name = "lb_itemName";
            this.lb_itemName.Size = new System.Drawing.Size(120, 27);
            this.lb_itemName.TabIndex = 43;
            this.lb_itemName.Text = "שם הפריט";
            // 
            // btn_remove
            // 
            this.btn_remove.BackColor = System.Drawing.Color.DarkRed;
            this.btn_remove.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_remove.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_remove.Location = new System.Drawing.Point(312, 299);
            this.btn_remove.Margin = new System.Windows.Forms.Padding(2);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(92, 35);
            this.btn_remove.TabIndex = 51;
            this.btn_remove.Text = "הסר פריט";
            this.btn_remove.UseVisualStyleBackColor = false;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // dg_shoppingCart
            // 
            this.dg_shoppingCart.AllowUserToAddRows = false;
            this.dg_shoppingCart.AllowUserToDeleteRows = false;
            this.dg_shoppingCart.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dg_shoppingCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_shoppingCart.Location = new System.Drawing.Point(6, 57);
            this.dg_shoppingCart.Name = "dg_shoppingCart";
            this.dg_shoppingCart.ReadOnly = true;
            this.dg_shoppingCart.Size = new System.Drawing.Size(420, 165);
            this.dg_shoppingCart.TabIndex = 50;
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.Color.Red;
            this.btn_reset.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_reset.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_reset.Location = new System.Drawing.Point(286, 344);
            this.btn_reset.Margin = new System.Windows.Forms.Padding(2);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(118, 35);
            this.btn_reset.TabIndex = 49;
            this.btn_reset.Text = "אפס הזמנה";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_pay
            // 
            this.btn_pay.BackColor = System.Drawing.Color.LightGreen;
            this.btn_pay.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_pay.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_pay.Location = new System.Drawing.Point(21, 344);
            this.btn_pay.Margin = new System.Windows.Forms.Padding(2);
            this.btn_pay.Name = "btn_pay";
            this.btn_pay.Size = new System.Drawing.Size(75, 35);
            this.btn_pay.TabIndex = 48;
            this.btn_pay.Text = "שלם";
            this.btn_pay.UseVisualStyleBackColor = false;
            this.btn_pay.Click += new System.EventHandler(this.btn_pay_Click);
            // 
            // tx_totalPrice
            // 
            this.tx_totalPrice.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.tx_totalPrice.Location = new System.Drawing.Point(21, 309);
            this.tx_totalPrice.Margin = new System.Windows.Forms.Padding(2);
            this.tx_totalPrice.Name = "tx_totalPrice";
            this.tx_totalPrice.Size = new System.Drawing.Size(95, 23);
            this.tx_totalPrice.TabIndex = 47;
            // 
            // lb_total_price
            // 
            this.lb_total_price.AutoSize = true;
            this.lb_total_price.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lb_total_price.Location = new System.Drawing.Point(120, 309);
            this.lb_total_price.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_total_price.Name = "lb_total_price";
            this.lb_total_price.Size = new System.Drawing.Size(95, 16);
            this.lb_total_price.TabIndex = 46;
            this.lb_total_price.Text = "סה\"כ לתשלום";
            // 
            // lb_shoppingCart
            // 
            this.lb_shoppingCart.AutoSize = true;
            this.lb_shoppingCart.Font = new System.Drawing.Font("David", 20F, System.Drawing.FontStyle.Bold);
            this.lb_shoppingCart.Location = new System.Drawing.Point(256, 9);
            this.lb_shoppingCart.Name = "lb_shoppingCart";
            this.lb_shoppingCart.Size = new System.Drawing.Size(136, 27);
            this.lb_shoppingCart.TabIndex = 52;
            this.lb_shoppingCart.Text = ":עגלת קניות";
            // 
            // lb_chooseItem
            // 
            this.lb_chooseItem.AutoSize = true;
            this.lb_chooseItem.Font = new System.Drawing.Font("David", 20F, System.Drawing.FontStyle.Bold);
            this.lb_chooseItem.Location = new System.Drawing.Point(109, 9);
            this.lb_chooseItem.Name = "lb_chooseItem";
            this.lb_chooseItem.Size = new System.Drawing.Size(271, 27);
            this.lb_chooseItem.TabIndex = 53;
            this.lb_chooseItem.Text = ":בחר מוצר מתוך הרשימה";
            // 
            // pricesPerVendorTableAdapter
            // 
            this.pricesPerVendorTableAdapter.ClearBeforeFill = true;
            // 
            // cmb_generalItems
            // 
            this.cmb_generalItems.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_generalItems.FormattingEnabled = true;
            this.cmb_generalItems.Location = new System.Drawing.Point(106, 58);
            this.cmb_generalItems.Name = "cmb_generalItems";
            this.cmb_generalItems.Size = new System.Drawing.Size(263, 21);
            this.cmb_generalItems.TabIndex = 54;
            // 
            // lb_itemName2
            // 
            this.lb_itemName2.AutoSize = true;
            this.lb_itemName2.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_itemName2.Location = new System.Drawing.Point(140, 104);
            this.lb_itemName2.Name = "lb_itemName2";
            this.lb_itemName2.Size = new System.Drawing.Size(85, 19);
            this.lb_itemName2.TabIndex = 58;
            this.lb_itemName2.Text = "שם הפריט";
            // 
            // lb_addItem
            // 
            this.lb_addItem.AutoSize = true;
            this.lb_addItem.BackColor = System.Drawing.Color.Transparent;
            this.lb_addItem.Font = new System.Drawing.Font("David", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_addItem.Location = new System.Drawing.Point(121, 17);
            this.lb_addItem.Name = "lb_addItem";
            this.lb_addItem.Size = new System.Drawing.Size(210, 27);
            this.lb_addItem.TabIndex = 59;
            this.lb_addItem.Text = "הוסף מוצר לרשימה";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(286, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 19);
            this.label3.TabIndex = 60;
            this.label3.Text = "שם המוצר";
            // 
            // tx_itemName
            // 
            this.tx_itemName.Location = new System.Drawing.Point(124, 27);
            this.tx_itemName.Margin = new System.Windows.Forms.Padding(2);
            this.tx_itemName.Name = "tx_itemName";
            this.tx_itemName.Size = new System.Drawing.Size(147, 20);
            this.tx_itemName.TabIndex = 61;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(311, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 19);
            this.label4.TabIndex = 62;
            this.label4.Text = "תמונה";
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.GreenYellow;
            this.btn_add.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold);
            this.btn_add.Location = new System.Drawing.Point(134, 139);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(63, 33);
            this.btn_add.TabIndex = 63;
            this.btn_add.Text = "הוסף";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // img_upload
            // 
            this.img_upload.Location = new System.Drawing.Point(212, 139);
            this.img_upload.Margin = new System.Windows.Forms.Padding(2);
            this.img_upload.Name = "img_upload";
            this.img_upload.Size = new System.Drawing.Size(155, 143);
            this.img_upload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_upload.TabIndex = 64;
            this.img_upload.TabStop = false;
            // 
            // img_item
            // 
            this.img_item.Location = new System.Drawing.Point(28, 134);
            this.img_item.Margin = new System.Windows.Forms.Padding(2);
            this.img_item.Name = "img_item";
            this.img_item.Size = new System.Drawing.Size(321, 367);
            this.img_item.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_item.TabIndex = 65;
            this.img_item.TabStop = false;
            // 
            // btn_upload
            // 
            this.btn_upload.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold);
            this.btn_upload.Location = new System.Drawing.Point(134, 177);
            this.btn_upload.Margin = new System.Windows.Forms.Padding(2);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(63, 33);
            this.btn_upload.TabIndex = 66;
            this.btn_upload.Text = "העלה";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click_1);
            // 
            // btn_return_crud
            // 
            this.btn_return_crud.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold);
            this.btn_return_crud.Location = new System.Drawing.Point(369, 8);
            this.btn_return_crud.Margin = new System.Windows.Forms.Padding(2);
            this.btn_return_crud.Name = "btn_return_crud";
            this.btn_return_crud.Size = new System.Drawing.Size(70, 24);
            this.btn_return_crud.TabIndex = 67;
            this.btn_return_crud.Text = "חזור";
            this.btn_return_crud.UseVisualStyleBackColor = true;
            this.btn_return_crud.Click += new System.EventHandler(this.btn_return_crud_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.dg_shoppingCart);
            this.panel1.Controls.Add(this.tx_totalPrice);
            this.panel1.Controls.Add(this.lb_total_price);
            this.panel1.Controls.Add(this.btn_pay);
            this.panel1.Controls.Add(this.btn_reset);
            this.panel1.Controls.Add(this.btn_remove);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.panel1.Location = new System.Drawing.Point(855, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 898);
            this.panel1.TabIndex = 68;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Orange;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.lb_shoppingCart);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(449, 42);
            this.panel2.TabIndex = 69;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Orange;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.btn_return_crud);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(449, 42);
            this.panel4.TabIndex = 70;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("David", 20F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(195, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 27);
            this.label2.TabIndex = 52;
            this.label2.Text = ":עגלת קניות";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.dg_vendorsPrices);
            this.panel3.Controls.Add(this.amount_numeric);
            this.panel3.Controls.Add(this.btn_addToCart);
            this.panel3.Controls.Add(this.lb_amount);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(386, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(469, 898);
            this.panel3.TabIndex = 69;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Orange;
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.lb_itemName);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(518, 42);
            this.panel5.TabIndex = 66;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.img_item);
            this.panel6.Controls.Add(this.lb_itemName2);
            this.panel6.Controls.Add(this.cmb_generalItems);
            this.panel6.Controls.Add(this.btn_show);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(-2, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(388, 898);
            this.panel6.TabIndex = 68;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Orange;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.lb_chooseItem);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(388, 43);
            this.panel9.TabIndex = 69;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Orange;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.lb_addItem);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 515);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(388, 62);
            this.panel8.TabIndex = 68;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.img_upload);
            this.panel7.Controls.Add(this.btn_add);
            this.panel7.Controls.Add(this.label3);
            this.panel7.Controls.Add(this.btn_upload);
            this.panel7.Controls.Add(this.tx_itemName);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 577);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(388, 321);
            this.panel7.TabIndex = 0;
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1306, 898);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Shop";
            this.Text = "חנות";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_vendorsPrices)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pricesPerVendorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAD_14DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amount_numeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_shoppingCart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_upload)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_item)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_vendorsPrices;
        private System.Windows.Forms.Button btn_addToCart;
        private System.Windows.Forms.Label lb_amount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_itemName;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.DataGridView dg_shoppingCart;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_pay;
        private System.Windows.Forms.TextBox tx_totalPrice;
        private System.Windows.Forms.Label lb_total_price;
        private System.Windows.Forms.Label lb_shoppingCart;
        private System.Windows.Forms.Label lb_chooseItem;
        private SAD_14DataSet sAD_14DataSet;
        private System.Windows.Forms.BindingSource pricesPerVendorBindingSource;
        private WindowsFormsApplicationGUIuARM.SAD_14DataSetTableAdapters.PricesPerVendorTableAdapter pricesPerVendorTableAdapter;
        private System.Windows.Forms.ComboBox cmb_generalItems;
        private System.Windows.Forms.Label lb_itemName2;
        private System.Windows.Forms.Label lb_addItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tx_itemName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.PictureBox img_upload;
        private System.Windows.Forms.PictureBox img_item;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Button btn_return_crud;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorIdVendorsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodIdFoodItemsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.NumericUpDown amount_numeric;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
    }
}