using System;
using System.Data.SqlClient;
using System.Drawing;

namespace Group14
{
    public class Location {

        private string address;
        private double latitude;
        private double longitude;

        public Location(string address, double latitude, double longitude, bool is_new)
        {
            this.address = address;
            this.latitude = latitude;
            this.longitude = longitude;
            if (is_new)
            {
                this.CreateLocation();
                Program.Locations.Add(this);
            }
        }

        public Location()
        { 
        }

        public double getXByAddress(string address)
        {
            double x = 0;
            foreach (Location l in Program.Locations)
            {
                if (l.get_Address().Equals(address))
                {
                    x = l.get_X();
                    break;
                }
            }

            return x;
        }

        public double getYByAddress(string address)
        {
            double y = 0;
            foreach (Location l in Program.Locations)
            {
                if (l.get_Address().Equals(address))
                {
                    y = l.get_Y();
                    break;
                }
            }

            return y;
        }

        public void CreateLocation()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Location @Address, @longtitude, @latitude";
            c.Parameters.AddWithValue("@Address", this.address);
            c.Parameters.AddWithValue("@longtitude", this.longitude);
            c.Parameters.AddWithValue("@latitude", this.latitude);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }


        public string get_Address()
        {
            return this.address;
        }

        public void set_Address(string address)
        {
            this.address = address;
        }

        public double get_X()
        {
            return this.latitude;
        }

        public void set_X(int latitude)
        {
            this.latitude = latitude;
        }

        public double get_Y()
        {
            return this.longitude;
        }

        public void set_Y(int longitude)
        {
            this.longitude = longitude;
        }

        public double CreateXByAddress()
        {
            Random random = new Random();
            return (random.NextDouble()*0.001241) + 31.248462;
        }

        public double CreateYByAddress()
        {
            Random random = new Random();
            return (random.NextDouble()*0.004581) + 34.787355;
        }
    }
}