﻿namespace Group14
{
    partial class CreateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateEmployee));
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_EmployeeId = new System.Windows.Forms.TextBox();
            this.textBox_EmployeeFirstName = new System.Windows.Forms.TextBox();
            this.textBox_EmployeeLastName = new System.Windows.Forms.TextBox();
            this.textBox_EmployeeMail = new System.Windows.Forms.TextBox();
            this.textBox_EmployeePhoneNumber = new System.Windows.Forms.TextBox();
            this.comboBox_EmployeeRole = new System.Windows.Forms.ComboBox();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.button_AddNewEmployee = new System.Windows.Forms.Button();
            this.label_ErrorEmployeeId = new System.Windows.Forms.Label();
            this.label_ErrorEmployeeFirstName = new System.Windows.Forms.Label();
            this.label_ErrorEmployeeLastName = new System.Windows.Forms.Label();
            this.label_ErrorEmployeeMail = new System.Windows.Forms.Label();
            this.label_ErrorEmployeePhone = new System.Windows.Forms.Label();
            this.button_Exit = new System.Windows.Forms.Button();
            this.label_ErrorEmployeeRole = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(905, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 28);
            this.label3.TabIndex = 1;
            this.label3.Text = ":תעודת זהות";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(933, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 28);
            this.label4.TabIndex = 2;
            this.label4.Text = ":שם פרטי";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(905, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 28);
            this.label5.TabIndex = 3;
            this.label5.Text = ":שם משפחה";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(983, 291);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 28);
            this.label6.TabIndex = 4;
            this.label6.Text = ":מייל";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(891, 343);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(165, 28);
            this.label7.TabIndex = 5;
            this.label7.Text = ":מספר פלאפון";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(961, 403);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 28);
            this.label8.TabIndex = 6;
            this.label8.Text = ":תפקיד";
            // 
            // textBox_EmployeeId
            // 
            this.textBox_EmployeeId.Location = new System.Drawing.Point(556, 124);
            this.textBox_EmployeeId.Name = "textBox_EmployeeId";
            this.textBox_EmployeeId.Size = new System.Drawing.Size(256, 20);
            this.textBox_EmployeeId.TabIndex = 7;
            // 
            // textBox_EmployeeFirstName
            // 
            this.textBox_EmployeeFirstName.Location = new System.Drawing.Point(556, 185);
            this.textBox_EmployeeFirstName.Name = "textBox_EmployeeFirstName";
            this.textBox_EmployeeFirstName.Size = new System.Drawing.Size(256, 20);
            this.textBox_EmployeeFirstName.TabIndex = 8;
            // 
            // textBox_EmployeeLastName
            // 
            this.textBox_EmployeeLastName.Location = new System.Drawing.Point(556, 237);
            this.textBox_EmployeeLastName.Name = "textBox_EmployeeLastName";
            this.textBox_EmployeeLastName.Size = new System.Drawing.Size(256, 20);
            this.textBox_EmployeeLastName.TabIndex = 9;
            // 
            // textBox_EmployeeMail
            // 
            this.textBox_EmployeeMail.Location = new System.Drawing.Point(556, 291);
            this.textBox_EmployeeMail.Name = "textBox_EmployeeMail";
            this.textBox_EmployeeMail.Size = new System.Drawing.Size(256, 20);
            this.textBox_EmployeeMail.TabIndex = 10;
            // 
            // textBox_EmployeePhoneNumber
            // 
            this.textBox_EmployeePhoneNumber.Location = new System.Drawing.Point(556, 343);
            this.textBox_EmployeePhoneNumber.Name = "textBox_EmployeePhoneNumber";
            this.textBox_EmployeePhoneNumber.Size = new System.Drawing.Size(256, 20);
            this.textBox_EmployeePhoneNumber.TabIndex = 11;
            // 
            // comboBox_EmployeeRole
            // 
            this.comboBox_EmployeeRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_EmployeeRole.FormattingEnabled = true;
            this.comboBox_EmployeeRole.Location = new System.Drawing.Point(556, 403);
            this.comboBox_EmployeeRole.Name = "comboBox_EmployeeRole";
            this.comboBox_EmployeeRole.Size = new System.Drawing.Size(256, 21);
            this.comboBox_EmployeeRole.TabIndex = 12;
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_ReturnToEmployeeManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 265);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(226, 67);
            this.button_ReturnToEmployeeManage.TabIndex = 13;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // button_AddNewEmployee
            // 
            this.button_AddNewEmployee.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_AddNewEmployee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_AddNewEmployee.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_AddNewEmployee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_AddNewEmployee.Location = new System.Drawing.Point(0, 163);
            this.button_AddNewEmployee.Name = "button_AddNewEmployee";
            this.button_AddNewEmployee.Size = new System.Drawing.Size(226, 67);
            this.button_AddNewEmployee.TabIndex = 14;
            this.button_AddNewEmployee.Text = "צור עובד";
            this.button_AddNewEmployee.UseVisualStyleBackColor = false;
            this.button_AddNewEmployee.Click += new System.EventHandler(this.button_AddNewEmployee_Click);
            // 
            // label_ErrorEmployeeId
            // 
            this.label_ErrorEmployeeId.AutoSize = true;
            this.label_ErrorEmployeeId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorEmployeeId.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorEmployeeId.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorEmployeeId.Location = new System.Drawing.Point(282, 123);
            this.label_ErrorEmployeeId.Name = "label_ErrorEmployeeId";
            this.label_ErrorEmployeeId.Size = new System.Drawing.Size(155, 28);
            this.label_ErrorEmployeeId.TabIndex = 15;
            this.label_ErrorEmployeeId.Text = "קלט ת.ז שגוי";
            // 
            // label_ErrorEmployeeFirstName
            // 
            this.label_ErrorEmployeeFirstName.AutoSize = true;
            this.label_ErrorEmployeeFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorEmployeeFirstName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorEmployeeFirstName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorEmployeeFirstName.Location = new System.Drawing.Point(282, 185);
            this.label_ErrorEmployeeFirstName.Name = "label_ErrorEmployeeFirstName";
            this.label_ErrorEmployeeFirstName.Size = new System.Drawing.Size(220, 28);
            this.label_ErrorEmployeeFirstName.TabIndex = 16;
            this.label_ErrorEmployeeFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // label_ErrorEmployeeLastName
            // 
            this.label_ErrorEmployeeLastName.AutoSize = true;
            this.label_ErrorEmployeeLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorEmployeeLastName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorEmployeeLastName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorEmployeeLastName.Location = new System.Drawing.Point(282, 236);
            this.label_ErrorEmployeeLastName.Name = "label_ErrorEmployeeLastName";
            this.label_ErrorEmployeeLastName.Size = new System.Drawing.Size(248, 28);
            this.label_ErrorEmployeeLastName.TabIndex = 17;
            this.label_ErrorEmployeeLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorEmployeeMail
            // 
            this.label_ErrorEmployeeMail.AutoSize = true;
            this.label_ErrorEmployeeMail.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorEmployeeMail.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorEmployeeMail.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorEmployeeMail.Location = new System.Drawing.Point(282, 287);
            this.label_ErrorEmployeeMail.Name = "label_ErrorEmployeeMail";
            this.label_ErrorEmployeeMail.Size = new System.Drawing.Size(170, 28);
            this.label_ErrorEmployeeMail.TabIndex = 18;
            this.label_ErrorEmployeeMail.Text = "קלט מייל שגוי";
            // 
            // label_ErrorEmployeePhone
            // 
            this.label_ErrorEmployeePhone.AutoSize = true;
            this.label_ErrorEmployeePhone.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorEmployeePhone.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorEmployeePhone.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorEmployeePhone.Location = new System.Drawing.Point(282, 339);
            this.label_ErrorEmployeePhone.Name = "label_ErrorEmployeePhone";
            this.label_ErrorEmployeePhone.Size = new System.Drawing.Size(262, 28);
            this.label_ErrorEmployeePhone.TabIndex = 19;
            this.label_ErrorEmployeePhone.Text = "קלט מספר פלאפון שגוי";
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Exit.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Exit.Location = new System.Drawing.Point(3, 364);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(223, 67);
            this.button_Exit.TabIndex = 20;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // label_ErrorEmployeeRole
            // 
            this.label_ErrorEmployeeRole.AutoSize = true;
            this.label_ErrorEmployeeRole.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorEmployeeRole.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorEmployeeRole.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorEmployeeRole.Location = new System.Drawing.Point(282, 403);
            this.label_ErrorEmployeeRole.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ErrorEmployeeRole.Name = "label_ErrorEmployeeRole";
            this.label_ErrorEmployeeRole.Size = new System.Drawing.Size(192, 28);
            this.label_ErrorEmployeeRole.TabIndex = 22;
            this.label_ErrorEmployeeRole.Text = "קלט תפקיד שגוי";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(556, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(626, 63);
            this.label2.TabIndex = 23;
            this.label2.Text = ":מלא את הפרטים הבאים";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.button_AddNewEmployee);
            this.panel1.Controls.Add(this.button_ReturnToEmployeeManage);
            this.panel1.Controls.Add(this.button_Exit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(226, 601);
            this.panel1.TabIndex = 24;
            // 
            // CreateEmployee
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1182, 601);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_ErrorEmployeeRole);
            this.Controls.Add(this.label_ErrorEmployeePhone);
            this.Controls.Add(this.label_ErrorEmployeeMail);
            this.Controls.Add(this.label_ErrorEmployeeLastName);
            this.Controls.Add(this.label_ErrorEmployeeFirstName);
            this.Controls.Add(this.label_ErrorEmployeeId);
            this.Controls.Add(this.comboBox_EmployeeRole);
            this.Controls.Add(this.textBox_EmployeePhoneNumber);
            this.Controls.Add(this.textBox_EmployeeMail);
            this.Controls.Add(this.textBox_EmployeeLastName);
            this.Controls.Add(this.textBox_EmployeeFirstName);
            this.Controls.Add(this.textBox_EmployeeId);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "CreateEmployee";
            this.Text = "יצירת עובד חדש";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_EmployeeId;
        private System.Windows.Forms.TextBox textBox_EmployeeFirstName;
        private System.Windows.Forms.TextBox textBox_EmployeeLastName;
        private System.Windows.Forms.TextBox textBox_EmployeeMail;
        private System.Windows.Forms.TextBox textBox_EmployeePhoneNumber;
        private System.Windows.Forms.ComboBox comboBox_EmployeeRole;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.Button button_AddNewEmployee;
        private System.Windows.Forms.Label label_ErrorEmployeeId;
        private System.Windows.Forms.Label label_ErrorEmployeeFirstName;
        private System.Windows.Forms.Label label_ErrorEmployeeLastName;
        private System.Windows.Forms.Label label_ErrorEmployeeMail;
        private System.Windows.Forms.Label label_ErrorEmployeePhone;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Label label_ErrorEmployeeRole;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
    }
}