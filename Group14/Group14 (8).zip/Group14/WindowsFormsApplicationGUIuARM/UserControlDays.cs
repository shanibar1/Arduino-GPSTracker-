﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class UserControlDays : UserControl
    {
        private Employee emp;
        private DateTime dt;
        private DateTime today;
        public static string static_day;
        public UserControlDays(Employee emp, int year, int month, int day)
        {
            InitializeComponent();
            this.emp = emp;
            this.dt = DateTime.Now;
            this.today = new DateTime(year, month, day);
            today = today.AddDays(1);
            if (today < this.dt)
            {
                this.pictureBox1.Visible = false;
            }
            today = today.AddDays(-1);
        }

        public void days(int numdays)
        {
            DateTime today = DateTime.Now;
            Ibdays.Text = numdays + "";
        }

        private void UserControlDays_Click(object sender, EventArgs e)
        {
            static_day = Ibdays.Text;
            EventForm Event_Form = new EventForm(emp);
            Event_Form.Show();
        }

        public void displayEvent(int day, int month, int year)
        {
            int count = 0;
            foreach (Event e in Program.Events)
            {

                DateTime d = new DateTime(year, month, day);
                if ((e.GetDate() == d) && (!e.GetStatus().ToString().Equals("canceled")))
                    count++;
            }
            if (count != 0)
           
            ibEvent.Text = "מספר האירועים: " + count;
        }

        private void ibEvent_Click(object sender, EventArgs e)
        {
            static_day = Ibdays.Text;
            if (!ibEvent.Text.Equals(""))
            {
                WatchEvents we = new WatchEvents(this.today, this.emp);
                we.Show();
            }
            else
                ibEvent.Enabled = false;
        }

        private void UserControlDays_Load(object sender, EventArgs e)
        {

        }
    }
}
