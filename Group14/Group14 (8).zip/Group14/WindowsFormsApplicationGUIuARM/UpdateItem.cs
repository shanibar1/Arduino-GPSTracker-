﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Group14
{
    public partial class UpdateItem : Form
    {
        private FoodItem exist_FoodItem;
        List<FoodItem> FoodItems;
        private Employee employee;
        public UpdateItem(Employee employee)
        {
            InitializeComponent();
            FoodItems = Program.FoodItems;
            this.employee = employee;
            cmb_items.SelectedIndexChanged += cmb_items_SelectedIndexChanged;
            fill_combo_Box();
            dateTimePicker1.Enabled = false;
            textBox_ProductName.Enabled = false;
            textBox_units.Enabled = false;
            comboBox_ItemStatus.Enabled = false;
            //הסתרת הודעות שגיאה
            makeLabelsErrorInvisible();
            //הסתרת הכפתורים


        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorProductName.Visible = false;
            label_ErrorValidUnits.Visible = false;

        }

        //private void ComboBox_SelectionChanged(object sender, EventArgs e)
        //{
        //    // Get the selected item from the combo box
        //    string selectedValue = cmb_items.SelectedItem.ToString();
        //    exist_FoodItem = Program.seekFoodItem(selectedValue);
        //    textBox_Expired.Enabled = true;
        //    textBox_ProductName.Enabled = true;
        //    textBox_units.Enabled = true;
        //    comboBox_ItemStatus.Enabled = true;
        //    textBox_Expired.Text = exist_FoodItem.GetExpiredDate().ToString();
        //    textBox_ProductName.Text = exist_FoodItem.GetItemName();
        //    textBox_units.Text = exist_FoodItem.GetUnitsInStock().ToString();
        //}
        private void btn_return_Click(object sender, EventArgs e)
        {
            ReadItems r = new ReadItems(employee);
            r.Show();
            this.Hide();
        }

        private void fill_combo_Box()
        {
            List<String> foodItems = new List<string>();
            foreach (FoodItem f in this.FoodItems)
                foodItems.Add(f.GetItemName());
            cmb_items.DataSource = foodItems;
        }

        private void cmb_items_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = cmb_items.SelectedItem.ToString();
            exist_FoodItem = Program.seekFoodItem(selectedValue);
            dateTimePicker1.Enabled = true;
            textBox_ProductName.Enabled = true;
            textBox_units.Enabled = true;
            comboBox_ItemStatus.Enabled = true;
            dateTimePicker1.Value = exist_FoodItem.GetExpiredDate();
            textBox_ProductName.Text = exist_FoodItem.GetItemName();
            textBox_units.Text = exist_FoodItem.GetUnitsInStock().ToString();
            comboBox_ItemStatus.DataSource = Enum.GetValues(typeof(ItemStatus));
            if (exist_FoodItem.GetIsInStock())
                comboBox_ItemStatus.SelectedItem = ItemStatus.InStock;
            else
                comboBox_ItemStatus.SelectedItem = ItemStatus.OutOfStock;
        }


        private void btn_update_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                makeLabelsErrorInvisible();
                exist_FoodItem.SetItemName(textBox_ProductName.Text);
                //exist_FoodItem.SetExpiredDate();
                exist_FoodItem.SetUnitsInStock(int.Parse(textBox_units.Text));
                if (comboBox_ItemStatus.SelectedItem.ToString().Equals("InStock"))
                    exist_FoodItem.SetIsInStock(true);
                else exist_FoodItem.SetIsInStock(false);
                exist_FoodItem.SetExpiredDate(dateTimePicker1.Value);
                exist_FoodItem.UpdateFoodItem();

               
            }
        }
        public Boolean checkInput()
        {

            makeLabelsErrorInvisible();
            bool properNameText = !textBox_ProductName.Text.All(char.IsLetter);
            bool emptyName = textBox_ProductName.Text == "";
            
            bool validUnits = Regex.IsMatch(textBox_units.Text, @"^\d+$");
            
            

            if (properNameText || emptyName)
            {
                if (emptyName)

                    label_ErrorProductName.Text = "בבקשה הכנס ערך";

                else if (properNameText)
                    label_ErrorProductName.Text = "בבקשה הכנס קלט לא מספרי";
                label_ErrorProductName.Visible = true;
            }
            if (!validUnits )
            {
                label_ErrorValidUnits.Text = "בבקשה הכנס ערך תקין";


                label_ErrorValidUnits.Visible = true;
            }
            if (properNameText || emptyName || !validUnits )
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
