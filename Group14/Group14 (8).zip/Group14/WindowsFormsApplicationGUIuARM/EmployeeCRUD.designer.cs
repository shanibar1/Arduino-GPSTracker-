﻿namespace Group14
{
    partial class EmployeeCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeCRUD));
            this.label1 = new System.Windows.Forms.Label();
            this.button_WatchExistEmployee = new System.Windows.Forms.Button();
            this.button_CreateNewEmployee = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.button_Exit = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(674, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 63);
            this.label1.TabIndex = 0;
            this.label1.Text = "ניהול עובדים";
            // 
            // button_WatchExistEmployee
            // 
            this.button_WatchExistEmployee.BackColor = System.Drawing.Color.Purple;
            this.button_WatchExistEmployee.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_WatchExistEmployee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_WatchExistEmployee.Location = new System.Drawing.Point(721, 400);
            this.button_WatchExistEmployee.Name = "button_WatchExistEmployee";
            this.button_WatchExistEmployee.Size = new System.Drawing.Size(255, 87);
            this.button_WatchExistEmployee.TabIndex = 1;
            this.button_WatchExistEmployee.Text = "צפה בעובד קיים";
            this.button_WatchExistEmployee.UseVisualStyleBackColor = false;
            this.button_WatchExistEmployee.Click += new System.EventHandler(this.button_WatchExistEmployee_Click);
            // 
            // button_CreateNewEmployee
            // 
            this.button_CreateNewEmployee.BackColor = System.Drawing.Color.Purple;
            this.button_CreateNewEmployee.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_CreateNewEmployee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_CreateNewEmployee.Location = new System.Drawing.Point(362, 400);
            this.button_CreateNewEmployee.Name = "button_CreateNewEmployee";
            this.button_CreateNewEmployee.Size = new System.Drawing.Size(255, 87);
            this.button_CreateNewEmployee.TabIndex = 2;
            this.button_CreateNewEmployee.Text = "צור עובד חדש";
            this.button_CreateNewEmployee.UseVisualStyleBackColor = false;
            this.button_CreateNewEmployee.Click += new System.EventHandler(this.button_CreateNewEmployee_Click);
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 475);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(255, 87);
            this.button_ReturnToEmployeeManage.TabIndex = 3;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // button_Exit
            // 
            this.button_Exit.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_Exit.Location = new System.Drawing.Point(911, 594);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 4;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(255, 629);
            this.splitter1.TabIndex = 5;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(255, 261);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(761, 196);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(186, 167);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 21;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(402, 196);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(186, 167);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // EmployeeCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1008, 629);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.button_ReturnToEmployeeManage);
            this.Controls.Add(this.button_CreateNewEmployee);
            this.Controls.Add(this.button_WatchExistEmployee);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.splitter1);
            this.Name = "EmployeeCRUD";
            this.Text = "ניהול עובדים";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_WatchExistEmployee;
        private System.Windows.Forms.Button button_CreateNewEmployee;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}