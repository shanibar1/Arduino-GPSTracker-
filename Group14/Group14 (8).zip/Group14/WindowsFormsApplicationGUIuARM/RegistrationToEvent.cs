﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group14
{
    public partial class RegistrationToEvent : Form
    {
        SqlConnection con = new SqlConnection("Data Source = IEMDBS; Initial Catalog = SAD_14; Integrated Security = True");
        private Volunteer volunteer;
        private List<string> selectedEventsIds;

        public RegistrationToEvent(Volunteer v)
        {
            InitializeComponent();
            volunteer = v;
            dataGridView1.CellClick += dataGridView_CellClick;
            btnSave.Click += btnSave_Click;
            this.label_welcome.Text = "!" + "שלום" + " " + volunteer.get_volunteerFirstName(); // עברית
            selectedEventsIds = new List<string>();

            // Create a new ListBox control and configure its properties

        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string eventId = selectedRow.Cells["eventId"].Value.ToString();

                // Get the event date of the selected event
                string eventDate = selectedRow.Cells["dateDataGridViewTextBoxColumn"].Value.ToString();

                // Check if any selected event has the same date as the clicked event
                if (selectedEventsIds.Any(id => volunteer.IsEventDateSameAsSelectedEvent(id, eventDate, selectedEventsIds)) && !selectedEventsIds.Contains(eventId))
                {
                    MessageBox.Show("אפשר להרשם לאירוע אחד בתאריך זה");
                    return;
                }
                if (volunteer.IsEventDateSameAsRegistered(eventDate) && !selectedEventsIds.Contains(eventId))
                {
                    MessageBox.Show("אתה כבר רשום לאירוע בתאריך זה");
                    return;
                }
                if (selectedEventsIds.Contains(eventId))
                {
                    selectedEventsIds.Remove(eventId);
                }
                else
                {
                    selectedEventsIds.Add(eventId);
                }

                UpdateSelectedEventsListBox();
            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {

            if (selectedEventsIds.Count > 0)
            {

                List<string> duplicateDates = volunteer.checkDuplicateDates(selectedEventsIds);

                if (duplicateDates.Count > 0)
                {
                    string duplicateDatesMessage = "אתה כבר רשום לאירוע בתאריך זה";
                    duplicateDatesMessage += string.Join("\n", duplicateDates);
                    MessageBox.Show(duplicateDatesMessage);
                    return;
                }

                foreach (string eventId in selectedEventsIds)

                    volunteer.Registrar(eventId);

                MessageBox.Show("ההרשמה בוצעה");

                RegistrationToEvent rtE = new RegistrationToEvent(volunteer);
                rtE.Show();
                this.Hide();
                selectedEventsIds.Clear();
                UpdateSelectedEventsListBox();

            }

            else
            {
                MessageBox.Show("אנא בחר אירוע אחד לפחות");
            }

        }

            private bool volunteerNeddeed()
            {
                throw new NotImplementedException();
            }

            private void UpdateSelectedEventsListBox()
            {
                listBox_Events.DataSource = null;
                listBox_Events.DataSource = selectedEventsIds;
            }

            private void RegistrationToEvent_Load(object sender, EventArgs e)
            {
            grid();
            }
        private void grid()
        {
            string query = "SELECT  eventId, employeeId_Employees, Address, Name, Date, startTime, endTime, Status FROM dbo.Events WHERE(Date >= DATEADD(DAY, -1, GETDATE())) AND(eventId NOT IN (SELECT eventId_Events FROM   dbo.Registrations  WHERE(volunteerId_Volunteers = " + volunteer.get_volunteerId() + ") AND(registered = 1)))";

            SqlDataAdapter dba = new SqlDataAdapter(query, con);

            SqlCommandBuilder gridTable = new SqlCommandBuilder(dba);
            var ds = new DataSet();
            dba.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }

        private void listBox_Events_SelectedIndexChanged(object sender, EventArgs e)
            {

            }

            private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {

            }

            private void label1_Click(object sender, EventArgs e)
            {

            }

        private void button_return_Click(object sender, EventArgs e)
        {
            VolunteerManage hp = new VolunteerManage(this.volunteer);
            hp.Show();
            this.Hide();
        }

        
    }
    } 


    