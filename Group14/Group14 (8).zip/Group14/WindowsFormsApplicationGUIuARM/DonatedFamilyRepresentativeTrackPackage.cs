﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using GMap.NET.WindowsForms.ToolTips;

namespace Group14
{
    public partial class DonatedFamilyRepresentativeTrackPackage : Form
    {
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private Volunteer driver;
        private DonatedFamilyRepresentative df;
        private Package package;
        private Location l;
        private GMapOverlay markersOverlay;
        private GMarkerGoogle marker;
        private double driverSpeed;
        private double dist;

        public DonatedFamilyRepresentativeTrackPackage(DonatedFamilyRepresentative df, Package package)
        {
            InitializeComponent();
            this.l = new Location();
            this.displayLocation(l.getXByAddress(df.get_address()), l.getYByAddress(df.get_address()));
            this.markersOverlay = new GMapOverlay();
            this.driverSpeed = 0.0001;
            this.dist = 0.0001;
            this.df = df;
            df.updatePackagesTrack();
            this.package = package;
            this.driver = df.getDriver(this.package);
            this.driver.setupDrive(Program.seekEvent(this.package.get_eventId()), this.package);
        }

        private void displayLocation(double x, double y)
        {
            gMapControl1.MapProvider = GMap.NET.MapProviders.GoogleMapProvider.Instance;
            GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerAndCache;
            gMapControl1.Position = new PointLatLng(x, y);
            gMapControl1.MinZoom = 0;
            gMapControl1.MaxZoom = 30;
            gMapControl1.Zoom = 18;
            gMapControl1.DragButton = MouseButtons.Left;

            marker = new GMarkerGoogle(new PointLatLng(x, y), GMarkerGoogleType.lightblue_dot);

            markersOverlay = new GMapOverlay();
            gMapControl1.Overlays.Add(markersOverlay);
        }

        private void button_PackageTracking_Click(object sender, EventArgs e)
        {
            markersOverlay.Markers.Remove(marker);
            this.displayLocation(this.driver.get_X(), this.driver.get_Y());
            markersOverlay.Markers.Add(marker);
        }

        private void button_CurrentLocation_Click(object sender, EventArgs e)
        {
            markersOverlay.Markers.Remove(marker);
            this.displayLocation(this.l.getXByAddress(this.df.get_address()), this.l.getYByAddress(this.df.get_address()));
            markersOverlay.Markers.Add(marker);
        }

        private void button_ReturnToManage_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeManage dfr = new DonatedFamilyRepresentativeManage(df);
            dfr.Show();
            this.Hide();
        }

        private bool driveArrived(double dist)
        {
            double distX = System.Math.Abs(this.l.getXByAddress(this.df.get_address()) - this.driver.get_X());
            double distY = System.Math.Abs(this.l.getYByAddress(this.df.get_address()) - this.driver.get_Y());
            if (distX < dist && distY < dist)
            {
                return true;
            }
            else
                return false;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void DonatedFamilyRepresentativeTrackPackage_Load(object sender, EventArgs e)
        {
            timer.Start();
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = 1500;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            bool a = driveArrived(dist);
            if (!driveArrived(dist))
            {
                this.driver.Drive(this.driverSpeed);
            }
            else
            {
                timer.Stop();
                this.package.UpdatePackage(PackageStatus.Delivered);
                this.Hide();
                DonatedFamilyRepresentativeManage dfr = new DonatedFamilyRepresentativeManage(df);
                dfr.Show();
            }
        }
    }
}
