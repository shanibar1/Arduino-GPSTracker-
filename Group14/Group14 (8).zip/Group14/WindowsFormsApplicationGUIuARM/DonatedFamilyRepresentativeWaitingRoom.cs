﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class DonatedFamilyRepresentativeWaitingRoom : Form
    {
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        private bool hasPackage;
        private DonatedFamilyRepresentative df;
        private Package package;

        public DonatedFamilyRepresentativeWaitingRoom(DonatedFamilyRepresentative df, Package package)
        {
            InitializeComponent();
            this.df = df;
            this.package = package;
            this.hasPackage = !(package == null);

        }

        private void DonatedFamilyRepresentativeWaitingRoom_Load(object sender, EventArgs e)
        {
            timer.Interval = 3500;
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeTrackPackage dft;
            DonatedFamilyRepresentativeManage dfm;
            if (this.hasPackage)
            {
                dft = new DonatedFamilyRepresentativeTrackPackage(df, package);
                dft.Show();
                this.Close();
                timer.Stop();
            }
            else
            {
                dfm = new DonatedFamilyRepresentativeManage(df);
                dfm.Show();
                this.Close();
                timer.Stop();
                MessageBox.Show("לא נמסרת היום חבילה");
            }
        }
    }
}

