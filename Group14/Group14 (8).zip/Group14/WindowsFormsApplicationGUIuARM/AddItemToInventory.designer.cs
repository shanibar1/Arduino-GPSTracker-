﻿namespace Group14
{
    partial class AddItemToInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddItemToInventory));
            this.btn_return = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.tx_name = new System.Windows.Forms.TextBox();
            this.lb_date = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_addItem = new System.Windows.Forms.Label();
            this.num_quan = new System.Windows.Forms.NumericUpDown();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.num_quan)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_return
            // 
            this.btn_return.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_return.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_return.Location = new System.Drawing.Point(21, 12);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(81, 25);
            this.btn_return.TabIndex = 33;
            this.btn_return.Text = "חזור";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Indigo;
            this.btn_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_update.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_update.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_update.Location = new System.Drawing.Point(21, 554);
            this.btn_update.Margin = new System.Windows.Forms.Padding(2);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(150, 44);
            this.btn_update.TabIndex = 32;
            this.btn_update.Text = "הוסף מוצר";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // tx_name
            // 
            this.tx_name.Location = new System.Drawing.Point(385, 225);
            this.tx_name.Name = "tx_name";
            this.tx_name.Size = new System.Drawing.Size(177, 20);
            this.tx_name.TabIndex = 29;
            // 
            // lb_date
            // 
            this.lb_date.AutoSize = true;
            this.lb_date.BackColor = System.Drawing.Color.Transparent;
            this.lb_date.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lb_date.Location = new System.Drawing.Point(568, 303);
            this.lb_date.Name = "lb_date";
            this.lb_date.Size = new System.Drawing.Size(109, 19);
            this.lb_date.TabIndex = 27;
            this.lb_date.Text = ":תאריך תפוגה";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(561, 369);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 19);
            this.label5.TabIndex = 26;
            this.label5.Text = ":יחידות במלאי";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_name.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lb_name.Location = new System.Drawing.Point(589, 226);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(90, 19);
            this.lb_name.TabIndex = 25;
            this.lb_name.Text = ":שם המוצר";
            // 
            // lb_addItem
            // 
            this.lb_addItem.AutoSize = true;
            this.lb_addItem.Cursor = System.Windows.Forms.Cursors.Default;
            this.lb_addItem.Dock = System.Windows.Forms.DockStyle.Right;
            this.lb_addItem.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lb_addItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lb_addItem.Location = new System.Drawing.Point(833, 0);
            this.lb_addItem.Name = "lb_addItem";
            this.lb_addItem.Size = new System.Drawing.Size(305, 63);
            this.lb_addItem.TabIndex = 34;
            this.lb_addItem.Text = ":הוסף מוצר";
            // 
            // num_quan
            // 
            this.num_quan.Location = new System.Drawing.Point(496, 367);
            this.num_quan.Maximum = new decimal(new int[] {
            800,
            0,
            0,
            0});
            this.num_quan.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_quan.Name = "num_quan";
            this.num_quan.Size = new System.Drawing.Size(36, 20);
            this.num_quan.TabIndex = 35;
            this.num_quan.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.dateTimePicker1.Location = new System.Drawing.Point(341, 300);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(221, 23);
            this.dateTimePicker1.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(258, 225);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 37;
            this.label1.Text = "שם לא תקין";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkViolet;
            this.panel1.Controls.Add(this.lb_addItem);
            this.panel1.Controls.Add(this.btn_return);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1138, 100);
            this.panel1.TabIndex = 38;
            // 
            // AddItemToInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1138, 626);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.num_quan);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.tx_name);
            this.Controls.Add(this.lb_date);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lb_name);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "AddItemToInventory";
            this.Text = "הוסף מוצר";
            ((System.ComponentModel.ISupportInitialize)(this.num_quan)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.TextBox tx_name;
        private System.Windows.Forms.Label lb_date;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_addItem;
        private System.Windows.Forms.NumericUpDown num_quan;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
    }
}