﻿namespace Group14
{
    partial class EventForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Date = new System.Windows.Forms.TextBox();
            this.textBox_Event = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button_Save = new System.Windows.Forms.Button();
            this.textBox_Address = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox_StartTime = new System.Windows.Forms.ComboBox();
            this.label_ErroremptyEventName = new System.Windows.Forms.Label();
            this.label_ErroremptyEventAddress = new System.Windows.Forms.Label();
            this.label_ErroremptyStartTime = new System.Windows.Forms.Label();
            this.button_return = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_Date
            // 
            this.textBox_Date.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox_Date.Enabled = false;
            this.textBox_Date.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.textBox_Date.Location = new System.Drawing.Point(8, 109);
            this.textBox_Date.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_Date.Name = "textBox_Date";
            this.textBox_Date.Size = new System.Drawing.Size(309, 23);
            this.textBox_Date.TabIndex = 0;
            // 
            // textBox_Event
            // 
            this.textBox_Event.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox_Event.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.textBox_Event.ForeColor = System.Drawing.Color.Navy;
            this.textBox_Event.Location = new System.Drawing.Point(8, 193);
            this.textBox_Event.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_Event.Name = "textBox_Event";
            this.textBox_Event.Size = new System.Drawing.Size(309, 23);
            this.textBox_Event.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(12, 84);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(12, 175);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Event";
            // 
            // button_Save
            // 
            this.button_Save.BackColor = System.Drawing.Color.Indigo;
            this.button_Save.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_Save.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Save.Location = new System.Drawing.Point(312, 468);
            this.button_Save.Margin = new System.Windows.Forms.Padding(2);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(67, 27);
            this.button_Save.TabIndex = 4;
            this.button_Save.Text = "save";
            this.button_Save.UseVisualStyleBackColor = false;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // textBox_Address
            // 
            this.textBox_Address.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox_Address.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.textBox_Address.ForeColor = System.Drawing.Color.Navy;
            this.textBox_Address.Location = new System.Drawing.Point(8, 275);
            this.textBox_Address.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_Address.Name = "textBox_Address";
            this.textBox_Address.Size = new System.Drawing.Size(309, 23);
            this.textBox_Address.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(12, 257);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Address";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::WindowsFormsApplicationGUIuARM.Properties.Resources.My_project;
            this.pictureBox1.Location = new System.Drawing.Point(282, -1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("David", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label4.Location = new System.Drawing.Point(41, 6);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(239, 47);
            this.label4.TabIndex = 8;
            this.label4.Text = "יצירת אירוע";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(12, 341);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Start Time";
            // 
            // comboBox_StartTime
            // 
            this.comboBox_StartTime.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBox_StartTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_StartTime.FormattingEnabled = true;
            this.comboBox_StartTime.Location = new System.Drawing.Point(120, 339);
            this.comboBox_StartTime.Name = "comboBox_StartTime";
            this.comboBox_StartTime.Size = new System.Drawing.Size(91, 21);
            this.comboBox_StartTime.TabIndex = 12;
            // 
            // label_ErroremptyEventName
            // 
            this.label_ErroremptyEventName.AutoSize = true;
            this.label_ErroremptyEventName.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErroremptyEventName.ForeColor = System.Drawing.Color.Red;
            this.label_ErroremptyEventName.Location = new System.Drawing.Point(182, 236);
            this.label_ErroremptyEventName.Name = "label_ErroremptyEventName";
            this.label_ErroremptyEventName.Size = new System.Drawing.Size(135, 13);
            this.label_ErroremptyEventName.TabIndex = 18;
            this.label_ErroremptyEventName.Text = "בבקשה הכנס שם אירוע";
            // 
            // label_ErroremptyEventAddress
            // 
            this.label_ErroremptyEventAddress.AutoSize = true;
            this.label_ErroremptyEventAddress.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErroremptyEventAddress.ForeColor = System.Drawing.Color.Red;
            this.label_ErroremptyEventAddress.Location = new System.Drawing.Point(201, 312);
            this.label_ErroremptyEventAddress.Name = "label_ErroremptyEventAddress";
            this.label_ErroremptyEventAddress.Size = new System.Drawing.Size(116, 13);
            this.label_ErroremptyEventAddress.TabIndex = 19;
            this.label_ErroremptyEventAddress.Text = "בבקשה הכנס כתובת";
            // 
            // label_ErroremptyStartTime
            // 
            this.label_ErroremptyStartTime.AutoSize = true;
            this.label_ErroremptyStartTime.Font = new System.Drawing.Font("David", 10.2F, System.Drawing.FontStyle.Bold);
            this.label_ErroremptyStartTime.ForeColor = System.Drawing.Color.Red;
            this.label_ErroremptyStartTime.Location = new System.Drawing.Point(169, 390);
            this.label_ErroremptyStartTime.Name = "label_ErroremptyStartTime";
            this.label_ErroremptyStartTime.Size = new System.Drawing.Size(148, 13);
            this.label_ErroremptyStartTime.TabIndex = 20;
            this.label_ErroremptyStartTime.Text = "בבקשה הכנס שעת התחלה";
            // 
            // button_return
            // 
            this.button_return.BackColor = System.Drawing.Color.Indigo;
            this.button_return.Font = new System.Drawing.Font("David", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button_return.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_return.Location = new System.Drawing.Point(19, 468);
            this.button_return.Margin = new System.Windows.Forms.Padding(2);
            this.button_return.Name = "button_return";
            this.button_return.Size = new System.Drawing.Size(67, 27);
            this.button_return.TabIndex = 21;
            this.button_return.Text = "return";
            this.button_return.UseVisualStyleBackColor = false;
            this.button_return.Click += new System.EventHandler(this.button_return_Click);
            // 
            // EventForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Plum;
            this.ClientSize = new System.Drawing.Size(394, 506);
            this.Controls.Add(this.button_return);
            this.Controls.Add(this.label_ErroremptyStartTime);
            this.Controls.Add(this.label_ErroremptyEventAddress);
            this.Controls.Add(this.label_ErroremptyEventName);
            this.Controls.Add(this.comboBox_StartTime);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_Address);
            this.Controls.Add(this.button_Save);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_Event);
            this.Controls.Add(this.textBox_Date);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "EventForm";
            this.Text = "EventForm";
            this.Load += new System.EventHandler(this.EventForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Date;
        private System.Windows.Forms.TextBox textBox_Event;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.TextBox textBox_Address;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_StartTime;
        private System.Windows.Forms.Label label_ErroremptyEventName;
        private System.Windows.Forms.Label label_ErroremptyEventAddress;
        private System.Windows.Forms.Label label_ErroremptyStartTime;
        private System.Windows.Forms.Button button_return;
    }
}