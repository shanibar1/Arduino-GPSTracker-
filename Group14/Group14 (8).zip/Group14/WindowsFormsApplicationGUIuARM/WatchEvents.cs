﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Group14
{
    public partial class WatchEvents : Form
    {
        private Event ToRemoveEvent;
        private Employee employee;
        private DateTime dt;
        public WatchEvents(DateTime dt, Employee employee)
        {
            InitializeComponent();
            this.dt = dt;
            this.employee = employee;
        }

        private void WatchEvents_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sAD_14DataSet.Events' table. You can move, or remove it, as needed.
            //this.eventsTableAdapter.Fill(this.sAD_14DataSet.Events);
            grid();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void grid()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=IEMDBS;Initial Catalog=SAD_14;Integrated Security=True"))
            {
                conn.Open();
                /*DateTime dts = DateTime.ParseExact(this.dt.ToString(), "MM/dd/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);

                string s = dt.ToString("dd/M/yyyy", CultureInfo.InvariantCulture);*/

                string query = @"
                                SELECT *
                                FROM Events
                                WHERE 
                                Events.[Date] = '" + this.dt.ToString("yyyy-MM-dd") + "' AND Status <> 'canceled' ";

                SqlDataAdapter dba = new SqlDataAdapter(query, conn);

                SqlCommandBuilder gridTable = new SqlCommandBuilder(dba);
                var ds = new DataSet();
                dba.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                conn.Close();
            }

         

        }

        private void buttonReturn_Click(object sender, EventArgs e)
        {
            EventHomePage EH = new EventHomePage(this.employee);
            EH.Show();
            this.Hide();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {

            int total = dataGridView1.Rows.Cast<DataGridViewRow>().Where(p => Convert.ToBoolean(p.Cells["remove"].Value) == true).Count();
            if (total > 0)
            {
                string message = $"אתה בטוח שברצונך למחוק {total} שורות?";
                if (total > 1)

                    message = $"אתה בטוח שברצונך למחוק {total} שורות?";

                if (MessageBox.Show(message, "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    for (int i = dataGridView1.RowCount - 1; i >= 0; i--)
                    {
                        DataGridViewRow row = dataGridView1.Rows[i];
                       
                        if (Convert.ToBoolean(row.Cells["remove"].Value) == true)
                        {
                            string eventId = row.Cells["eventIdDataGridViewTextBoxColumn"].Value.ToString();
                            Program.seekEvent(eventId).Delete_Event();
                            WatchEvents WE = new WatchEvents(this.dt,this.employee);
                            WE.Show();
                            this.Hide();

                        }


                    }
                }


            }
        }
    }
    }


