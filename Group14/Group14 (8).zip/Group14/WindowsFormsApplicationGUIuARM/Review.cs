using System;
using System.Data.SqlClient;

namespace Group14
{

    public class Review {

        private string packageId;
        private string representativeId;
        private DateTime reviewDate;
        private int reviewRate;
        private string reviewWords;

        public Review(string packageId, string representativeId, DateTime reviewDate, int reviewRate, string reviewWords, bool is_new)
        {
            this.packageId = packageId;
            this.representativeId = representativeId;
            this.reviewDate = reviewDate;
            this.reviewRate = reviewRate;
            this.reviewWords = reviewWords;
            if (is_new)
            {
                this.CreateReview();
                Program.Reviews.Add(this);
            }
        }

        public void CreateReview()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Create_Review @packageId_Packages, @representativeId_FamiliesRepresentives, @Date, @Rate, @Paragraph";
            c.Parameters.AddWithValue("@packageId_Packages", this.packageId);
            c.Parameters.AddWithValue("@representativeId_FamiliesRepresentives", this.representativeId);
            c.Parameters.AddWithValue("@Date", this.reviewDate);
            c.Parameters.AddWithValue("@Rate", this.reviewRate);
            c.Parameters.AddWithValue("@Paragraph", this.reviewWords);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public bool AddReview() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool RemoveReview() {
            throw new System.NotImplementedException("Not implemented");
        }
        public bool EditReview() {
            throw new System.NotImplementedException("Not implemented");
        }

        public string get_packageId()
        {
            return this.packageId;
        }

        public void set_packageId(string packageId)
        {
            this.packageId = packageId;
        }

        public string get_representativeId()
        {
            return this.representativeId;
        }

        public void set_representativeId(string representativeId)
        {
            this.representativeId = representativeId;
        }

        public DateTime get_reviewDate()
        {
            return this.reviewDate;
        }

        public void set_reviewDate(DateTime reviewDate)
        {
            this.reviewDate = reviewDate;
        }

        public int get_reviewRate()
        {
            return this.reviewRate;
        }

        public void set_reviewRate(int reviewRate)
        {
            this.reviewRate = reviewRate;
        }

        public string get_reviewWords()
        {
            return this.reviewWords;
        }

        public void set_reviewWords(string reviewWords)
        {
            this.reviewWords = reviewWords;
        }

    }  
}
