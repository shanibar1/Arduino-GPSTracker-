﻿namespace Group14
{
    partial class CreateVolunteer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateVolunteer));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_VolunteerId = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerFirstName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerLastName = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerMail = new System.Windows.Forms.TextBox();
            this.textBox_VolunteerPhoneNumber = new System.Windows.Forms.TextBox();
            this.comboBox_VolunteerRole = new System.Windows.Forms.ComboBox();
            this.labelDrivingLicence = new System.Windows.Forms.Label();
            this.checkBox_DrivingLicence = new System.Windows.Forms.CheckBox();
            this.button_AddNewVolunteer = new System.Windows.Forms.Button();
            this.button_ReturnToEmployeeManage = new System.Windows.Forms.Button();
            this.label_ErrorVolunteerId = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerFirstName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerLastName = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerMail = new System.Windows.Forms.Label();
            this.label_ErrorVolunteerPhone = new System.Windows.Forms.Label();
            this.button_Exit = new System.Windows.Forms.Button();
            this.lable_drivingLicence = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(421, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(626, 63);
            this.label2.TabIndex = 1;
            this.label2.Text = ":מלא את הפרטים הבאים";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(909, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "מייל";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(848, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = ":שם פרטי";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(820, 261);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 28);
            this.label4.TabIndex = 4;
            this.label4.Text = ":שם משפחה";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(820, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 28);
            this.label5.TabIndex = 5;
            this.label5.Text = ":תעודת זהות";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(829, 405);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 28);
            this.label6.TabIndex = 6;
            this.label6.Text = "מספר טלפון";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(887, 479);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 28);
            this.label7.TabIndex = 8;
            this.label7.Text = "תפקיד";
            // 
            // textBox_VolunteerId
            // 
            this.textBox_VolunteerId.Location = new System.Drawing.Point(626, 106);
            this.textBox_VolunteerId.Name = "textBox_VolunteerId";
            this.textBox_VolunteerId.Size = new System.Drawing.Size(175, 20);
            this.textBox_VolunteerId.TabIndex = 9;
            // 
            // textBox_VolunteerFirstName
            // 
            this.textBox_VolunteerFirstName.Location = new System.Drawing.Point(626, 192);
            this.textBox_VolunteerFirstName.Name = "textBox_VolunteerFirstName";
            this.textBox_VolunteerFirstName.Size = new System.Drawing.Size(175, 20);
            this.textBox_VolunteerFirstName.TabIndex = 10;
            // 
            // textBox_VolunteerLastName
            // 
            this.textBox_VolunteerLastName.Location = new System.Drawing.Point(626, 261);
            this.textBox_VolunteerLastName.Name = "textBox_VolunteerLastName";
            this.textBox_VolunteerLastName.Size = new System.Drawing.Size(175, 20);
            this.textBox_VolunteerLastName.TabIndex = 11;
            // 
            // textBox_VolunteerMail
            // 
            this.textBox_VolunteerMail.Location = new System.Drawing.Point(626, 337);
            this.textBox_VolunteerMail.Name = "textBox_VolunteerMail";
            this.textBox_VolunteerMail.Size = new System.Drawing.Size(175, 20);
            this.textBox_VolunteerMail.TabIndex = 12;
            // 
            // textBox_VolunteerPhoneNumber
            // 
            this.textBox_VolunteerPhoneNumber.Location = new System.Drawing.Point(626, 405);
            this.textBox_VolunteerPhoneNumber.Name = "textBox_VolunteerPhoneNumber";
            this.textBox_VolunteerPhoneNumber.Size = new System.Drawing.Size(175, 20);
            this.textBox_VolunteerPhoneNumber.TabIndex = 13;
            // 
            // comboBox_VolunteerRole
            // 
            this.comboBox_VolunteerRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_VolunteerRole.FormattingEnabled = true;
            this.comboBox_VolunteerRole.Location = new System.Drawing.Point(605, 468);
            this.comboBox_VolunteerRole.Name = "comboBox_VolunteerRole";
            this.comboBox_VolunteerRole.Size = new System.Drawing.Size(196, 21);
            this.comboBox_VolunteerRole.TabIndex = 14;
            this.comboBox_VolunteerRole.SelectedIndexChanged += new System.EventHandler(this.comboBox_VolunteerRole_SelectedIndexChanged);
            // 
            // labelDrivingLicence
            // 
            this.labelDrivingLicence.AutoSize = true;
            this.labelDrivingLicence.BackColor = System.Drawing.Color.Transparent;
            this.labelDrivingLicence.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.labelDrivingLicence.Location = new System.Drawing.Point(732, 533);
            this.labelDrivingLicence.Name = "labelDrivingLicence";
            this.labelDrivingLicence.Size = new System.Drawing.Size(239, 28);
            this.labelDrivingLicence.TabIndex = 15;
            this.labelDrivingLicence.Text = ":רישיון נהיגה בתוקף";
            // 
            // checkBox_DrivingLicence
            // 
            this.checkBox_DrivingLicence.AutoSize = true;
            this.checkBox_DrivingLicence.Location = new System.Drawing.Point(711, 535);
            this.checkBox_DrivingLicence.Name = "checkBox_DrivingLicence";
            this.checkBox_DrivingLicence.Size = new System.Drawing.Size(15, 14);
            this.checkBox_DrivingLicence.TabIndex = 16;
            this.checkBox_DrivingLicence.UseVisualStyleBackColor = true;
            // 
            // button_AddNewVolunteer
            // 
            this.button_AddNewVolunteer.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_AddNewVolunteer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_AddNewVolunteer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_AddNewVolunteer.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_AddNewVolunteer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_AddNewVolunteer.Location = new System.Drawing.Point(0, 185);
            this.button_AddNewVolunteer.Name = "button_AddNewVolunteer";
            this.button_AddNewVolunteer.Size = new System.Drawing.Size(200, 71);
            this.button_AddNewVolunteer.TabIndex = 17;
            this.button_AddNewVolunteer.Text = "צור מתנדב";
            this.button_AddNewVolunteer.UseVisualStyleBackColor = false;
            this.button_AddNewVolunteer.Click += new System.EventHandler(this.button_AddNewVolunteer_Click);
            // 
            // button_ReturnToEmployeeManage
            // 
            this.button_ReturnToEmployeeManage.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_ReturnToEmployeeManage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_ReturnToEmployeeManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnToEmployeeManage.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_ReturnToEmployeeManage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_ReturnToEmployeeManage.Location = new System.Drawing.Point(0, 300);
            this.button_ReturnToEmployeeManage.Name = "button_ReturnToEmployeeManage";
            this.button_ReturnToEmployeeManage.Size = new System.Drawing.Size(200, 71);
            this.button_ReturnToEmployeeManage.TabIndex = 18;
            this.button_ReturnToEmployeeManage.Text = "חזור";
            this.button_ReturnToEmployeeManage.UseVisualStyleBackColor = false;
            this.button_ReturnToEmployeeManage.Click += new System.EventHandler(this.button_ReturnToEmployeeManage_Click);
            // 
            // label_ErrorVolunteerId
            // 
            this.label_ErrorVolunteerId.AutoSize = true;
            this.label_ErrorVolunteerId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerId.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVolunteerId.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorVolunteerId.Location = new System.Drawing.Point(360, 99);
            this.label_ErrorVolunteerId.Name = "label_ErrorVolunteerId";
            this.label_ErrorVolunteerId.Size = new System.Drawing.Size(155, 28);
            this.label_ErrorVolunteerId.TabIndex = 19;
            this.label_ErrorVolunteerId.Text = "קלט ת.ז שגוי";
            this.label_ErrorVolunteerId.Click += new System.EventHandler(this.label_ErrorVolunteerId_Click);
            // 
            // label_ErrorVolunteerFirstName
            // 
            this.label_ErrorVolunteerFirstName.AutoSize = true;
            this.label_ErrorVolunteerFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerFirstName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVolunteerFirstName.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorVolunteerFirstName.Location = new System.Drawing.Point(360, 179);
            this.label_ErrorVolunteerFirstName.Name = "label_ErrorVolunteerFirstName";
            this.label_ErrorVolunteerFirstName.Size = new System.Drawing.Size(220, 28);
            this.label_ErrorVolunteerFirstName.TabIndex = 20;
            this.label_ErrorVolunteerFirstName.Text = "קלט שם פרטי שגוי";
            // 
            // label_ErrorVolunteerLastName
            // 
            this.label_ErrorVolunteerLastName.AutoSize = true;
            this.label_ErrorVolunteerLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerLastName.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVolunteerLastName.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorVolunteerLastName.Location = new System.Drawing.Point(360, 257);
            this.label_ErrorVolunteerLastName.Name = "label_ErrorVolunteerLastName";
            this.label_ErrorVolunteerLastName.Size = new System.Drawing.Size(248, 28);
            this.label_ErrorVolunteerLastName.TabIndex = 21;
            this.label_ErrorVolunteerLastName.Text = "קלט שם משפחה שגוי";
            // 
            // label_ErrorVolunteerMail
            // 
            this.label_ErrorVolunteerMail.AutoSize = true;
            this.label_ErrorVolunteerMail.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerMail.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVolunteerMail.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorVolunteerMail.Location = new System.Drawing.Point(360, 333);
            this.label_ErrorVolunteerMail.Name = "label_ErrorVolunteerMail";
            this.label_ErrorVolunteerMail.Size = new System.Drawing.Size(170, 28);
            this.label_ErrorVolunteerMail.TabIndex = 22;
            this.label_ErrorVolunteerMail.Text = "קלט מייל שגוי";
            // 
            // label_ErrorVolunteerPhone
            // 
            this.label_ErrorVolunteerPhone.AutoSize = true;
            this.label_ErrorVolunteerPhone.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorVolunteerPhone.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_ErrorVolunteerPhone.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorVolunteerPhone.Location = new System.Drawing.Point(360, 401);
            this.label_ErrorVolunteerPhone.Name = "label_ErrorVolunteerPhone";
            this.label_ErrorVolunteerPhone.Size = new System.Drawing.Size(170, 28);
            this.label_ErrorVolunteerPhone.TabIndex = 23;
            this.label_ErrorVolunteerPhone.Text = "קלט מייל שגוי";
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button_Exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Exit.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.button_Exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Exit.Location = new System.Drawing.Point(0, 401);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(200, 71);
            this.button_Exit.TabIndex = 24;
            this.button_Exit.Text = "יציאה";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // lable_drivingLicence
            // 
            this.lable_drivingLicence.AutoSize = true;
            this.lable_drivingLicence.BackColor = System.Drawing.Color.Transparent;
            this.lable_drivingLicence.Font = new System.Drawing.Font("David", 21.75F, System.Drawing.FontStyle.Bold);
            this.lable_drivingLicence.ForeColor = System.Drawing.Color.Red;
            this.lable_drivingLicence.Location = new System.Drawing.Point(360, 525);
            this.lable_drivingLicence.Name = "lable_drivingLicence";
            this.lable_drivingLicence.Size = new System.Drawing.Size(340, 28);
            this.lable_drivingLicence.TabIndex = 25;
            this.lable_drivingLicence.Text = "חובה לצרף רישון נהיגה בתוקף";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.button_AddNewVolunteer);
            this.panel1.Controls.Add(this.button_Exit);
            this.panel1.Controls.Add(this.button_ReturnToEmployeeManage);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 631);
            this.panel1.TabIndex = 26;
            // 
            // CreateVolunteer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1047, 631);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lable_drivingLicence);
            this.Controls.Add(this.label_ErrorVolunteerPhone);
            this.Controls.Add(this.label_ErrorVolunteerMail);
            this.Controls.Add(this.label_ErrorVolunteerLastName);
            this.Controls.Add(this.label_ErrorVolunteerFirstName);
            this.Controls.Add(this.label_ErrorVolunteerId);
            this.Controls.Add(this.checkBox_DrivingLicence);
            this.Controls.Add(this.labelDrivingLicence);
            this.Controls.Add(this.comboBox_VolunteerRole);
            this.Controls.Add(this.textBox_VolunteerPhoneNumber);
            this.Controls.Add(this.textBox_VolunteerMail);
            this.Controls.Add(this.textBox_VolunteerLastName);
            this.Controls.Add(this.textBox_VolunteerFirstName);
            this.Controls.Add(this.textBox_VolunteerId);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "CreateVolunteer";
            this.Text = "יצירת מתנדב חדש";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_VolunteerId;
        private System.Windows.Forms.TextBox textBox_VolunteerFirstName;
        private System.Windows.Forms.TextBox textBox_VolunteerLastName;
        private System.Windows.Forms.TextBox textBox_VolunteerMail;
        private System.Windows.Forms.TextBox textBox_VolunteerPhoneNumber;
        private System.Windows.Forms.ComboBox comboBox_VolunteerRole;
        private System.Windows.Forms.Label labelDrivingLicence;
        private System.Windows.Forms.CheckBox checkBox_DrivingLicence;
        private System.Windows.Forms.Button button_AddNewVolunteer;
        private System.Windows.Forms.Button button_ReturnToEmployeeManage;
        private System.Windows.Forms.Label label_ErrorVolunteerId;
        private System.Windows.Forms.Label label_ErrorVolunteerFirstName;
        private System.Windows.Forms.Label label_ErrorVolunteerLastName;
        private System.Windows.Forms.Label label_ErrorVolunteerMail;
        private System.Windows.Forms.Label label_ErrorVolunteerPhone;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Label lable_drivingLicence;
        private System.Windows.Forms.Panel panel1;
    }
}