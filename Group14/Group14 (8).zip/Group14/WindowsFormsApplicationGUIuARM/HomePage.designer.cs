﻿namespace Group14
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_ErrorLastName = new System.Windows.Forms.Label();
            this.label_ErrorFirstName = new System.Windows.Forms.Label();
            this.label_ErrorId = new System.Windows.Forms.Label();
            this.textBox_LastName = new System.Windows.Forms.TextBox();
            this.textBox_FirstName = new System.Windows.Forms.TextBox();
            this.textBox_Id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_SignIn = new System.Windows.Forms.Button();
            this.button_Exit = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Name = "label3";
            // 
            // label_ErrorLastName
            // 
            resources.ApplyResources(this.label_ErrorLastName, "label_ErrorLastName");
            this.label_ErrorLastName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorLastName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorLastName.Name = "label_ErrorLastName";
            // 
            // label_ErrorFirstName
            // 
            resources.ApplyResources(this.label_ErrorFirstName, "label_ErrorFirstName");
            this.label_ErrorFirstName.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorFirstName.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorFirstName.Name = "label_ErrorFirstName";
            // 
            // label_ErrorId
            // 
            resources.ApplyResources(this.label_ErrorId, "label_ErrorId");
            this.label_ErrorId.BackColor = System.Drawing.Color.Transparent;
            this.label_ErrorId.ForeColor = System.Drawing.Color.Firebrick;
            this.label_ErrorId.Name = "label_ErrorId";
            // 
            // textBox_LastName
            // 
            resources.ApplyResources(this.textBox_LastName, "textBox_LastName");
            this.textBox_LastName.Name = "textBox_LastName";
            // 
            // textBox_FirstName
            // 
            resources.ApplyResources(this.textBox_FirstName, "textBox_FirstName");
            this.textBox_FirstName.Name = "textBox_FirstName";
            // 
            // textBox_Id
            // 
            resources.ApplyResources(this.textBox_Id, "textBox_Id");
            this.textBox_Id.Name = "textBox_Id";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.SteelBlue;
            this.label4.Name = "label4";
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.PaleTurquoise;
            resources.ApplyResources(this.splitter1, "splitter1");
            this.splitter1.Name = "splitter1";
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.pictureBox1.Image = global::WindowsFormsApplicationGUIuARM.Properties.Resources.My_project;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // button_SignIn
            // 
            this.button_SignIn.BackColor = System.Drawing.Color.Teal;
            resources.ApplyResources(this.button_SignIn, "button_SignIn");
            this.button_SignIn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_SignIn.Name = "button_SignIn";
            this.button_SignIn.UseVisualStyleBackColor = false;
            this.button_SignIn.Click += new System.EventHandler(this.button_SignIn_Click);
            // 
            // button_Exit
            // 
            this.button_Exit.BackColor = System.Drawing.Color.Teal;
            resources.ApplyResources(this.button_Exit, "button_Exit");
            this.button_Exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.UseVisualStyleBackColor = false;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Name = "label5";
            // 
            // HomePage
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.button_SignIn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label_ErrorLastName);
            this.Controls.Add(this.label_ErrorFirstName);
            this.Controls.Add(this.label_ErrorId);
            this.Controls.Add(this.textBox_LastName);
            this.Controls.Add(this.textBox_FirstName);
            this.Controls.Add(this.textBox_Id);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "HomePage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_ErrorLastName;
        private System.Windows.Forms.Label label_ErrorFirstName;
        private System.Windows.Forms.Label label_ErrorId;
        private System.Windows.Forms.TextBox textBox_LastName;
        private System.Windows.Forms.TextBox textBox_FirstName;
        private System.Windows.Forms.TextBox textBox_Id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_SignIn;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Label label5;
    }
}