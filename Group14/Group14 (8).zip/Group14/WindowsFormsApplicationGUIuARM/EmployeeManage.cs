﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class EmployeeManage : Form
    {
        private Employee employee;
        public EmployeeManage(Employee e)
        {
            InitializeComponent();
           
            this.employee = e;
            this.labelName.Text = "!" + "שלום" + " " + this.employee.get_employeeFirstName();
            setButtons();
            customizeDesing();
           
            
        }
        private void customizeDesing()
        {
            panelManege.Visible = false;
            panel1.Visible = false;
        }
        private void hideSubMenu()
        {
            if (panelManege.Visible == true)
            {
                panelManege.Visible = false;
            }
            if (panel1.Visible == true)
            {
                panel1.Visible = false;
            }

        }
        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }
        private void setButtons()
        {
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
                this.button_ViewReports.Visible = true;
                this.button_FillForms.Visible = true;
                this.button_OpenEventReport.Visible = true;
                this.button_ManageItems.Visible = true;
                this.button_ManageEvent.Visible = true;
                this.buttonManageVendors.Visible = true;
                this.button_VolunteerCRUD.Visible = true;
                this.button_DonatedFamilyRepresentativeCRUD.Visible = true;
                this.button_EmployeeCRUD.Visible = true;
                this.buttonWatchReviews.Visible = true;
                this.pictureBoxWhatsapp.Visible = true;
                this.labelSendMessage.Visible = true;



            }
            else if (employee.get_employeeRole().ToString().Equals("DeputyCEO"))
            {
                this.button_ViewReports.Visible = false;
                this.button_FillForms.Visible = false;
                this.button_OpenEventReport.Visible = false;
                this.button_ManageItems.Visible = true;
                this.button_ManageEvent.Visible = true;
                this.buttonManageVendors.Visible = false;
                this.button_VolunteerCRUD.Visible = false;
                this.button_DonatedFamilyRepresentativeCRUD.Visible = false;
                this.button_EmployeeCRUD.Visible = true;
                this.buttonWatchReviews.Visible = false;
                this.buttonReports.Visible = false;
                this.pictureBoxWhatsapp.Visible = true;
                this.labelSendMessage.Visible = true;

            }
            else if (employee.get_employeeRole().ToString().Equals("Accountant"))
            {
                this.button_ViewReports.Visible = true;
                this.button_FillForms.Visible = true;
                this.button_OpenEventReport.Visible = false;
                this.button_ManageItems.Visible = false;
                this.button_ManageEvent.Visible = false;
                this.buttonManageVendors.Visible = false;
                this.button_VolunteerCRUD.Visible = false;
                this.button_DonatedFamilyRepresentativeCRUD.Visible = false;
                this.button_EmployeeCRUD.Visible = false;
                this.buttonWatchReviews.Visible = false;
                this.buttonManege.Visible = false;
                this.pictureBoxWhatsapp.Visible = false;
                this.labelSendMessage.Visible = false;
            }
            else // Lawyer
            {
                this.button_ViewReports.Visible = false;
                this.button_FillForms.Visible = true;
                this.button_OpenEventReport.Visible = false;
                this.button_ManageItems.Visible = false;
                this.button_ManageEvent.Visible = false;
                this.buttonManageVendors.Visible = false;
                this.button_VolunteerCRUD.Visible = false;
                this.button_DonatedFamilyRepresentativeCRUD.Visible = false;
                this.button_EmployeeCRUD.Visible = false;
                this.buttonWatchReviews.Visible = false;
                this.buttonManege.Visible = false;
                this.pictureBoxWhatsapp.Visible = true;
                this.labelSendMessage.Visible = true;
            }
        }

        private void button_BackToHomePage_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }

        private void button_ManageItems_Click(object sender, EventArgs e)
        {
            ItemCRUD ic = new ItemCRUD(this.employee);
            ic.Show();
            this.Hide();
            hideSubMenu();
        }

        private void button_ManageEvent_Click(object sender, EventArgs e)
        {
            EventHomePage evh = new EventHomePage(this.employee);
            evh.Show();
            this.Hide();
            hideSubMenu();
        }
       
        private void button_ViewReports_Click(object sender, EventArgs e)
        {
           
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
                
            }
            else if (employee.get_employeeRole().ToString().Equals("Accountant"))
            {
                
            
            }
        }

        private void button_FillForms_Click(object sender, EventArgs e)
        {
          
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
        

            }
            else if (employee.get_employeeRole().ToString().Equals("Accountant"))
            {
   
            }
        }

        private void button_OpenEventReport_Click(object sender, EventArgs e)
        {
            if (employee.get_employeeRole().ToString().Equals("CEO"))
            {
                
            }
            else if (employee.get_employeeRole().ToString().Equals("Lawyer"))
            {
                

            }
        }

        private void button_DonatedFamilyRepresentativeCRUD_Click(object sender, EventArgs e)
        {
            DonatedFamilyRepresentativeCRUD df = new DonatedFamilyRepresentativeCRUD(this.employee);
            df.Show();
            this.Hide();
            hideSubMenu();
        }

        private void button_EmployeeCRUD_Click(object sender, EventArgs e)
        {
            EmployeeCRUD ec = new EmployeeCRUD(this.employee);
            ec.Show();
            this.Hide();
            hideSubMenu();
        }

        private void button_VolunteerCRUD_Click(object sender, EventArgs e)
        {
            VolunteerCRUD vc = new VolunteerCRUD(this.employee);
            vc.Show();
            this.Hide();
            hideSubMenu();
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void buttonManege_Click(object sender, EventArgs e)
        {
            showSubMenu(panelManege);
        }

        private void buttonReports_Click(object sender, EventArgs e)
        {
            showSubMenu(panel1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VendorCRUD df = new VendorCRUD(employee);
            df.Show();
            this.Hide();
            hideSubMenu();
        }

        private void pictureBoxWhatsapp_Click(object sender, EventArgs e)
        {
            WhatsApp WA = new WhatsApp(this.employee);
            WA.Show();
            this.Hide();

        }

        private void label1_Click(object sender, EventArgs e)
        {
            WhatsApp WA = new WhatsApp(this.employee);
            WA.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            hp.Show();
            this.Hide();
        }

        private void pictureBox_Alma_Click(object sender, EventArgs e)
        {

        }
        int count = 1;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (count < 7)
            {
                pictureBox_Alma.Image = imageList1.Images[count];
                count++;
            }
            else
                count = 1;
          
        }

        private void EmployeeManage_Load(object sender, EventArgs e)
        {

        }
    }
}
