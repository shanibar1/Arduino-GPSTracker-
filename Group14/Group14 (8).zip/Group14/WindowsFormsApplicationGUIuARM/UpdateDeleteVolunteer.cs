﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class UpdateDeleteVolunteer : Form
    {
        private Employee employee;
        private Volunteer exist_Volunteer;
        public UpdateDeleteVolunteer(Employee e)
        {
            InitializeComponent();
            comboBox_VolunteerRole.DataSource = Enum.GetValues(typeof(VolunteerRole));
            textBox_VolunteerFirstName.Enabled = false;
            textBox_VolunteerLastName.Enabled = false;
            textBox_VolunteerMail.Enabled = false;
            textBox_VolunteerPhoneNumber.Enabled = false;
            comboBox_VolunteerRole.Enabled = false;
            makeLabelsErrorInvisible();
            //button_DeleteVolunteer.Hide();
            //button_UpdateVolunteer.Hide();
            this.employee = e;
        }


        private void button_UpdateVolunteer_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                makeLabelsErrorInvisible();
                exist_Volunteer.set_volunteerFirstName(textBox_VolunteerFirstName.Text);
                exist_Volunteer.set_volunteerLastName(textBox_VolunteerLastName.Text);
                exist_Volunteer.set_volunteerMail(textBox_VolunteerMail.Text);
                exist_Volunteer.set_volunteerPhone(textBox_VolunteerPhoneNumber.Text);
                exist_Volunteer.set_volunteerRole((VolunteerRole)Enum.Parse(typeof(VolunteerRole), comboBox_VolunteerRole.Text));
                exist_Volunteer.UpdateVolunteer();

                UpdateDeleteVolunteer em = new UpdateDeleteVolunteer(this.employee);
                em.Show();
                this.Close();
            }
        }

        private void button_DeleteVolunteer_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                makeLabelsErrorInvisible();
                foreach (RegistrationForEvent r in exist_Volunteer.getRegistrations())
                {
                    if (r.GetRegistered())
                        exist_Volunteer.unregistrar(r.GetEvent());
                }
                exist_Volunteer.Delete_Volunteer();

                UpdateDeleteVolunteer vcrud = new UpdateDeleteVolunteer(employee);
                vcrud.Show();
                this.Close();


            }
        }

        private void button_ReturnToEmployeeManage_Click(object sender, EventArgs e)
        {
            VolunteerCRUD em = new VolunteerCRUD(this.employee);
            em.Show();
            this.Close();
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            if (checkIdInput())
            {
                makeLabelsErrorInvisible();
                if (textBox_VolunteerId != null)
                {
                    label_ErrorVolunteerId.Visible = false;
                    //הצגת הכפתורים
                    button_DeleteVolunteer.Show();
                    button_UpdateVolunteer.Show();
                    //איתור המופע המתאים והצגת הפרטים
                    exist_Volunteer = Program.seekVolunteer(textBox_VolunteerId.Text);
                    textBox_VolunteerFirstName.Enabled = true;
                    textBox_VolunteerLastName.Enabled = true;
                    textBox_VolunteerMail.Enabled = true;
                    textBox_VolunteerPhoneNumber.Enabled = true;
                    comboBox_VolunteerRole.Enabled = true;
                    textBox_VolunteerId.Enabled = false;
                    textBox_VolunteerFirstName.Text = exist_Volunteer.get_volunteerFirstName();
                    textBox_VolunteerLastName.Text = exist_Volunteer.get_volunteerLastName();
                    textBox_VolunteerMail.Text = exist_Volunteer.get_volunteerMail();
                    textBox_VolunteerPhoneNumber.Text = exist_Volunteer.get_volunteerPhone();
                    comboBox_VolunteerRole.DataSource = Enum.GetValues(typeof(VolunteerRole));
                    comboBox_VolunteerRole.Text = exist_Volunteer.get_volunteerRole().ToString();
                }
            }
        }

        private bool checkIdInput()
        {
            bool properIdText = textBox_VolunteerId.Text.All(char.IsDigit);
            bool properIdLength = textBox_VolunteerId.TextLength == 9;
            bool emptyId = textBox_VolunteerId.Text == "";
            if (emptyId || !properIdText || !properIdLength)
            {
                MessageBox.Show("קלט לא תקין");
                if (emptyId)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס ערך";
                }
                else if (!properIdText)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (!properIdLength)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerId.Visible = true;
                return false;
            }
            else
            {
                if (Program.seekVolunteer(textBox_VolunteerId.Text) == null)
                {
                    label_ErrorVolunteerId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorVolunteerId.Visible = true;
                    return false;
                }
                else if (!Program.seekVolunteer(textBox_VolunteerId.Text).get_isVolunteerActive())
                {
                    label_ErrorVolunteerId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorVolunteerId.Visible = true;
                    return false;
                }
                else if (Program.seekEmployee(textBox_VolunteerId.Text) != null)
                {
                    if (Program.seekEmployee(textBox_VolunteerId.Text).get_employeeRole() == EmployeeRole.CEO)
                    {
                        label_ErrorVolunteerId.Text = "לא ניתן לערוך מכאן מנכ''ל";
                        label_ErrorVolunteerId.Visible = true;
                        return false;
                    }
                    label_ErrorVolunteerId.Visible = false;
                    return true;
                }
                else
                {
                    label_ErrorVolunteerId.Visible = false;
                    return true;
                }
            }
        }
        private bool checkInput()
        {
            bool properIdText = !textBox_VolunteerId.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_VolunteerId.TextLength == 9);
            bool emptyId = textBox_VolunteerId.Text == "";

            // checking first name value
            string name = textBox_VolunteerFirstName.Text.Replace(" ", "");
            bool properFirstNameText = !name.All(char.IsLetter);
            bool emptyFirstName = textBox_VolunteerFirstName.Text == "";

            // checking last name value 
            name = textBox_VolunteerLastName.Text.Replace(" ", "");
            bool properLastNameText = !name.All(char.IsLetter);
            bool emptyLastName = textBox_VolunteerLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_VolunteerMail.Text.Contains('@') || textBox_VolunteerMail.Text.Contains('.'));
            bool properMailLength = !(textBox_VolunteerMail.TextLength >= 5);
            bool emptyMail = textBox_VolunteerMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_VolunteerPhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_VolunteerPhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_VolunteerPhoneNumber.Text == "";


            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorVolunteerId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerId.Visible = true;
            }
            else
            {
                if (Program.seekEmployee(textBox_VolunteerId.Text) != null)
                {
                    label_ErrorVolunteerId.Text = "תעודת הזהות כבר קיימת במערכת";
                }
                else
                {
                    label_ErrorVolunteerId.Visible = false;
                }
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorVolunteerFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerFirstName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorVolunteerLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVolunteerLastName.Visible = true;
            }
            else
            {
                label_ErrorVolunteerLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorVolunteerMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorVolunteerMail.Visible = true;
            }
            else
            {
                label_ErrorVolunteerMail.Visible = false;
            }
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorVolunteerPhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVolunteerPhone.Visible = true;
            }
            else
            {
                label_ErrorVolunteerPhone.Visible = false;
            }

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }
        private void makeLabelsErrorInvisible()
        {
            label_ErrorVolunteerId.Visible = false;
            label_ErrorVolunteerFirstName.Visible = false;
            label_ErrorVolunteerLastName.Visible = false;
            label_ErrorVolunteerMail.Visible = false;
            label_ErrorVolunteerPhone.Visible = false;
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
    }
}
