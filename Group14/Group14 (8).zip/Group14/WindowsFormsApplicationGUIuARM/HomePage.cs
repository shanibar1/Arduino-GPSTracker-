﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
            setLabelsError();
            makeLabelsErrorInvisible();
        }

        private void button_SignIn_Click(object sender, EventArgs e)
        {
            if (checkInput())
            {
                if (Program.seekEmployee(this.textBox_Id.Text) != null && Program.seekEmployee(this.textBox_Id.Text).get_isEmployeeActive())
                {
                    EmployeeManage em = new EmployeeManage(Program.seekEmployee(this.textBox_Id.Text));
                    em.Show();
                    this.Hide();
                }
                else if (Program.seekVolunteer(this.textBox_Id.Text) != null && Program.seekVolunteer(this.textBox_Id.Text).get_isVolunteerActive())
                {
                    VolunteerManage vm = new VolunteerManage(Program.seekVolunteer(this.textBox_Id.Text));
                    vm.Show();
                    this.Hide();
                }
                else if (Program.seekFamily(this.textBox_Id.Text) != null && Program.seekFamily(this.textBox_Id.Text).get_isActive())
                {
                    DonatedFamilyRepresentativeManage df = new DonatedFamilyRepresentativeManage(Program.seekFamily(this.textBox_Id.Text));
                    df.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("!משתמש לא קיים במערכת");
                }
            }
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private bool checkInput()
        {
            bool properIdText = !textBox_Id.Text.All(char.IsDigit);
            bool properIdLength = !(textBox_Id.TextLength == 9);
            bool emptyId = textBox_Id.Text == "";

            // checking first name value
            bool properFirstNameText = textBox_FirstName.Text.All(char.IsNumber);
            bool emptyFirstName = textBox_FirstName.Text == "";

            // checking last name value
            bool properLastNameText = textBox_LastName.Text.All(char.IsNumber);
            bool emptyLastName = textBox_LastName.Text == "";


            //print error message
            if (emptyId || properIdText || properIdLength)
            {
                if (emptyId)
                {
                    label_ErrorId.Text = "בבקשה הכנס ערך";
                }
                else if (properIdText)
                {
                    label_ErrorId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properIdLength)
                {
                    label_ErrorId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorId.Visible = true;
            }
            else
            {
                label_ErrorId.Visible = false;
            }
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorFirstName.Visible = true;
            }
            else
            {
                label_ErrorFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorLastName.Visible = true;
            }
            else
            {
                label_ErrorLastName.Visible = false;
            }
            

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }

        private void setLabelsError()
        {
            label_ErrorId.Text = "";
            label_ErrorFirstName.Text = "";
            label_ErrorLastName.Text = "";
        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorId.Visible = false;
            label_ErrorFirstName.Visible = false;
            label_ErrorLastName.Visible = false;
        }
    }
}
