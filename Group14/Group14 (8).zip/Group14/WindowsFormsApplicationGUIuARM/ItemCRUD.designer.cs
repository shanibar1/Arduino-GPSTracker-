﻿namespace Group14
{
    partial class ItemCRUD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemCRUD));
            this.button_AddNewItem = new System.Windows.Forms.Button();
            this.button_ReadItem = new System.Windows.Forms.Button();
            this.ReturnTo = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = System.Windows.Forms.DockStyle.Right;
            label1.Font = new System.Drawing.Font("David", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            label1.Location = new System.Drawing.Point(876, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(287, 63);
            label1.TabIndex = 3;
            label1.Text = "ניהול מלאי";
            // 
            // button_AddNewItem
            // 
            this.button_AddNewItem.BackColor = System.Drawing.Color.LimeGreen;
            this.button_AddNewItem.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_AddNewItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_AddNewItem.Location = new System.Drawing.Point(828, 472);
            this.button_AddNewItem.Name = "button_AddNewItem";
            this.button_AddNewItem.Size = new System.Drawing.Size(201, 82);
            this.button_AddNewItem.TabIndex = 0;
            this.button_AddNewItem.Text = "הזמנת מוצר חדש";
            this.button_AddNewItem.UseVisualStyleBackColor = false;
            this.button_AddNewItem.Click += new System.EventHandler(this.button_AddNewItem_Click);
            // 
            // button_ReadItem
            // 
            this.button_ReadItem.BackColor = System.Drawing.Color.LimeGreen;
            this.button_ReadItem.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.button_ReadItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_ReadItem.Location = new System.Drawing.Point(425, 472);
            this.button_ReadItem.Name = "button_ReadItem";
            this.button_ReadItem.Size = new System.Drawing.Size(201, 82);
            this.button_ReadItem.TabIndex = 1;
            this.button_ReadItem.Text = "צפייה ברשימת מוצרים";
            this.button_ReadItem.UseVisualStyleBackColor = false;
            this.button_ReadItem.Click += new System.EventHandler(this.button_ReadItem_Click);
            // 
            // ReturnTo
            // 
            this.ReturnTo.BackColor = System.Drawing.Color.OliveDrab;
            this.ReturnTo.Font = new System.Drawing.Font("David", 14.25F, System.Drawing.FontStyle.Bold);
            this.ReturnTo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ReturnTo.Location = new System.Drawing.Point(0, 299);
            this.ReturnTo.Name = "ReturnTo";
            this.ReturnTo.Size = new System.Drawing.Size(280, 82);
            this.ReturnTo.TabIndex = 2;
            this.ReturnTo.Text = "חזור";
            this.ReturnTo.UseVisualStyleBackColor = false;
            this.ReturnTo.Click += new System.EventHandler(this.ReturnTo_Click);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(280, 666);
            this.splitter1.TabIndex = 4;
            this.splitter1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(268, 284);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(843, 203);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(186, 167);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(440, 203);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(186, 167);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 19;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // ItemCRUD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1163, 666);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(label1);
            this.Controls.Add(this.ReturnTo);
            this.Controls.Add(this.button_ReadItem);
            this.Controls.Add(this.button_AddNewItem);
            this.Controls.Add(this.splitter1);
            this.Name = "ItemCRUD";
            this.Text = "ניהול מלאי";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_AddNewItem;
        private System.Windows.Forms.Button button_ReadItem;
        private System.Windows.Forms.Button ReturnTo;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}