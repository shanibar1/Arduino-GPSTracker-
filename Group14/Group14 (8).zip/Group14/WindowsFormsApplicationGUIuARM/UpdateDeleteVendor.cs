﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class UpdateDeleteVendor : Form
    {
        private Vendor exist_Vendor;
        private Employee employee;
        public UpdateDeleteVendor(Employee e)
        {
            InitializeComponent();
            //נטרול תיבות הטקסט כך שלא ניתן יהיה לרשום בהן
            employee = e;
            textBox_VendorFirstName.Enabled = false;
            textBox_VendorLastName.Enabled = false;
            textBox_VendorMail.Enabled = false;
            textBox_VendorPhoneNumber.Enabled = false;
            //הסתרת הודעות שגיאה
            makeLabelsErrorInvisible();
            //הסתרת הכפתורים
            //button_DeleteVendor.Hide();
            //button_UpdateVendor.Hide();
        }

        private bool checkIdInput()
        {
            bool properIdText = textBox_VendorId.Text.All(char.IsDigit);
            bool properIdLength = textBox_VendorId.TextLength == 9;
            bool emptyId = textBox_VendorId.Text == "";
            if (emptyId || !properIdText || !properIdLength)
            {
                MessageBox.Show("קלט לא תקין");
                if (emptyId)
                {
                    label_ErrorVendorId.Text = "בבקשה הכנס ערך";
                }
                else if (!properIdText)
                {
                    label_ErrorVendorId.Text = "בבקשה הכנס רק מספרים";
                }
                else if (!properIdLength)
                {
                    label_ErrorVendorId.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVendorId.Visible = true;
                return false;
            }
            else
            {
                if (Program.seekVendor(textBox_VendorId.Text) == null)
                {
                    label_ErrorVendorId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorVendorId.Visible = true;
                    return false;
                }
                else if (!Program.seekVendor(textBox_VendorId.Text).GetIsActive())
                {
                    label_ErrorVendorId.Text = "תעודת הזהות לא קיימת במערכת. נא נסה שנית";
                    label_ErrorVendorId.Visible = true;
                    return false;
                }
                else
                {
                    label_ErrorVendorId.Visible = false;
                    return true;
                }
            }
        }

        private bool checkInput()
        {
            label_ErrorVendorId.Visible = false;

            // checking first name value
            string name = textBox_VendorFirstName.Text.Replace(" ", "");
            bool properFirstNameText = !name.All(char.IsLetter);
            bool emptyFirstName = textBox_VendorFirstName.Text == "";

            // checking last name value
            name = textBox_VendorLastName.Text.Replace(" ", "");
            bool properLastNameText = !name.All(char.IsLetter);
            bool emptyLastName = textBox_VendorLastName.Text == "";

            // checking mail value
            bool properMailText = !(textBox_VendorMail.Text.Contains('@') || textBox_VendorMail.Text.Contains('.'));
            bool properMailLength = !(textBox_VendorMail.TextLength >= 5);
            bool emptyMail = textBox_VendorMail.Text == "";

            // checking phone value
            bool properPhoneText = !textBox_VendorPhoneNumber.Text.All(char.IsDigit);
            bool properPhoneLength = !(textBox_VendorPhoneNumber.TextLength == 10);
            bool emptyPhone = textBox_VendorPhoneNumber.Text == "";


            //print error message
            if (properFirstNameText || emptyFirstName)
            {
                if (emptyFirstName)
                {
                    label_ErrorVendorFirstName.Text = "בבקשה הכנס ערך";
                }
                else if (properFirstNameText)
                {
                    label_ErrorVendorFirstName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVendorFirstName.Visible = true;
            }
            else
            {
                label_ErrorVendorFirstName.Visible = false;
            }
            if (properLastNameText || emptyLastName)
            {
                if (emptyLastName)
                {
                    label_ErrorVendorLastName.Text = "בבקשה הכנס ערך";
                }
                else if (properLastNameText)
                {
                    label_ErrorVendorLastName.Text = "בבקשה הכנס קלט לא מספרי";
                }
                label_ErrorVendorLastName.Visible = true;
            }
            else
            {
                label_ErrorVendorLastName.Visible = false;
            }
            if (properMailText || properMailLength || emptyMail)
            {
                if (emptyMail)
                {
                    label_ErrorVendorMail.Text = "בבקשה הכנס ערך";
                }
                else if (properMailText)
                {
                    label_ErrorVendorMail.Text = "בבקשה הכנס מייל תקין";
                }
                else if (properMailLength)
                {
                    label_ErrorVendorMail.Text = "בבקשה הכנס מייל באורך תקין";
                }
                label_ErrorVendorMail.Visible = true;
            }
            else
            {
                label_ErrorVendorMail.Visible = false;
            }
            if (properPhoneText || properPhoneLength || emptyPhone)
            {
                if (emptyPhone)
                {
                    label_ErrorVendorPhone.Text = "בבקשה הכנס ערך";
                }
                else if (properPhoneText)
                {
                    label_ErrorVendorPhone.Text = "בבקשה הכנס רק מספרים";
                }
                else if (properPhoneLength)
                {
                    label_ErrorVendorPhone.Text = "בבקשה הכנס קלט באורך תקין";
                }
                label_ErrorVendorPhone.Visible = true;
            }
            else
            {
                label_ErrorVendorPhone.Visible = false;
            }

            if (properFirstNameText || emptyFirstName || properLastNameText || emptyLastName || properMailText || properMailLength || emptyMail || properPhoneText || properPhoneLength || emptyPhone)
            {
                MessageBox.Show("קלט לא תקין");
                return false;
            }
            return true;

        }

        private void makeLabelsErrorInvisible()
        {
            label_ErrorVendorId.Visible = false;
            label_ErrorVendorFirstName.Visible = false;
            label_ErrorVendorLastName.Visible = false;
            label_ErrorVendorMail.Visible = false;
            label_ErrorVendorPhone.Visible = false;
        }



        private void button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button_ReturnToVendorCRUD_Click_1(object sender, EventArgs e)
        {
            VendorCRUD ec = new VendorCRUD(employee);
            ec.Show();
            this.Hide();
        }

        private void button_DeleteVendor_Click_1(object sender, EventArgs e)
        {
            if (checkInput())
            {
                makeLabelsErrorInvisible();
                exist_Vendor.Delete_Vendor();

                UpdateDeleteVendor ecrud = new UpdateDeleteVendor(this.employee);
                ecrud.Show();
                this.Close();
            }
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            if (checkIdInput())
            {
                makeLabelsErrorInvisible();
                if (textBox_VendorId != null)
                {
                    label_ErrorVendorId.Visible = false;
                    //הצגת הכפתורים
                    button_DeleteVendor.Show();
                    button_UpdateVendor.Show();
                    //איתור המופע המתאים והצגת הפרטים
                    exist_Vendor = Program.seekVendor(textBox_VendorId.Text);
                    textBox_VendorFirstName.Enabled = true;
                    textBox_VendorLastName.Enabled = true;
                    textBox_VendorMail.Enabled = true;
                    textBox_VendorPhoneNumber.Enabled = true;
                    textBox_VendorFirstName.Text = exist_Vendor.GetFirstName();
                    textBox_VendorLastName.Text = exist_Vendor.GetLastName();
                    textBox_VendorMail.Text = exist_Vendor.GetMail();
                    textBox_VendorPhoneNumber.Text = exist_Vendor.GetPhone();
                }
            }
        }

        private void button_UpdateVendor_Click_1(object sender, EventArgs e)
        {
            if (checkInput())
            {
                makeLabelsErrorInvisible();
                exist_Vendor.set_VendorFirstName(textBox_VendorFirstName.Text);
                exist_Vendor.set_VendorLastName(textBox_VendorLastName.Text);
                exist_Vendor.set_VendorMail(textBox_VendorMail.Text);
                exist_Vendor.set_VendorPhone(textBox_VendorPhoneNumber.Text);
                exist_Vendor.UpdateVendor();

                UpdateDeleteVendor ecrud = new UpdateDeleteVendor(this.employee);
                ecrud.Show();
                this.Close();
            }
        }
    }
}
