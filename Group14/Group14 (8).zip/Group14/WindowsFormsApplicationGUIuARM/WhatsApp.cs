﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group14
{
    public partial class WhatsApp : Form
    {
        private Employee employee;
        public WhatsApp(Employee employee)
        {
            InitializeComponent();
            this.employee = employee;
            fillComboBoxVolunteersNames();
        }
        private void fillComboBoxVolunteersNames()
        {
            foreach (Volunteer v in Program.Volunteers)
            {
                string fullName = v.get_volunteerFirstName() + " " + v.get_volunteerLastName();
                this.comboBoxVolunteers_Name.Items.Add(fullName);
            }
        }

        private void whatsApp_Load(object sender, EventArgs e)
        {
            
        }
        private void SendwhatsApp(string number, string message)
        {
            try
            {
                if(number == "")
                {
                    MessageBox.Show("No Number Added");
                }
                
                else
                {
                    if (number.Length <= 10)
                    {
                        number = "+972" + number;
                    }
                    number = number.Replace(" ", "");
                    System.Diagnostics.Process.Start("http://api.whatsapp.com/send?phone=" + number + "&text=" + message);
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void buttonSend_Message_Click(object sender, EventArgs e)
        {
            SendwhatsApp(textBoxPhone_Number.Text, textBox_Message.Text);
        }
        public void clearTextBox()
        {
            textBox_Message.Text = "";
            textBoxPhone_Number.Text = ""; 

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Buttonreturn_Click(object sender, EventArgs e)
        {
            EmployeeManage WA = new EmployeeManage(this.employee);
            WA.Show();
            this.Hide();
        }

        private void textBoxPhone_Number_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxVolunteers_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = this.comboBoxVolunteers_Name.GetItemText(this.comboBoxVolunteers_Name.SelectedItem);
            foreach (Volunteer v in Program.Volunteers)
            {
                string fullName = v.get_volunteerFirstName() + " " + v.get_volunteerLastName();
                if (name.Equals(fullName))
                {
                    this.textBoxPhone_Number.Text = v.get_volunteerPhone();
                    break;
                }
            }
        }
    }
}
