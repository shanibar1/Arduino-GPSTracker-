
	import java.util.Scanner;
public class SUDOKU {
	
	static boolean [][] given = new boolean [9][9];
	static int [][] mat = new int[9][9];
	
	public static boolean CheckRow (int row) {// function that checks the row combination in mat
		boolean ans = true; 
		int [] count = new int [10];
		for (int j = 0 ; j<mat[row].length; j++) {
			int value = mat [row][j];
			if(value>=1 && value<=9) {
				count[value]= count[value]+1;
			}
		}
		for (int i = 1; i<count.length; i++) {// checking how many times the number appears
			if(count[i]>1) {
				ans = false;
			}
		}
		return ans;
	}
	
	public static boolean CheckCol(int col) {//function that checks the column combination in mat
		boolean ans = true; 
		int [] count = new int [10];
		for (int i = 0 ; i<mat.length; i++) {
			int value = mat [i][col];
			if(value>=1 && value<=9) {
				count[value]= count[value]+1;
			}
		}
		for (int i = 1; i<count.length; i++) {
			if(count[i]>1) {
				ans = false;
			}
		}
		return ans;
	}

	public static boolean CheckSquare( int SRow, int SCol) {//Checks if all numbers between 1 and 9 exist exactly once in a Square (3x3)
		boolean ans = true; 
		int [] count = new int [10];
		for (int i = 0; i< count.length; i++) {
			count [i] = 0;
		}
		for(int i = SRow; i<= SRow+2 ; i++) {
			for(int j = SCol; j<= SCol+2 ; j++ ) {
				int value = mat[i][j]; 
				if(value >= 1 && value <= 9) {
					count [value]= count[value]+1; 
				}
			}
		}
		for (int i = 1; i<count.length &&  ans==true; i++) {
			if(count[i]>1) {
				ans = false;
			}
		}
		return ans;
	}
		
	public static boolean CheckNum (String num) {//Checks the number the user entered and which is in the correct format
		if (num.length()!=4) {
			return false;
		}
		if((num.charAt(0)>='0' && num.charAt(0)<'9') && (num.charAt(1)>='0' && num.charAt(1)<'9') && (num.charAt(2)=='-') && (num.charAt(3)>='1' && num.charAt(3)<='9')) {
			return true;
		}
		return false;
	}
	
	public static boolean checkSlot (int row, int col) {//Running the possible numbers for the slot we are pointing at.
		if(given[row][col]) {
			return true; 
		}
		int i = mat[row][col]+1;
		while (i<=9) {
			mat[row][col] = i;
			int srow = 0;
			int scol = 0;
			if(row<=2) {srow = 0;} if(row>=3 && row <=5) {srow = 3;} if(row>=6){srow = 6;}
			if(col<=2) {scol = 0;} if(col>=3 && col <=5) {scol = 3;} if(col>=6){scol = 6;}
			if(CheckRow(row) && CheckCol(col) && CheckSquare(srow, scol)) {
				return true;
			}
			else {
				i = i+1;
			}
		}
		mat[row][col]=0;
		return false;
	}
	
	public static int[] checkLastSlot (int row, int col) {//finds the last slot in given that was FALSE.
		if (col==0) {
			row = row - 1;
			col = 8;
		}
		else {
			col = col - 1;
		}
		if(row == -1) {
			int[] ans = {-1,-1};
			return ans;
		}		
		while(given[row][col]) {
			if (col==0) {
				row = row - 1;
				col = 8;
			}
			else {
				col = col - 1;
			}
			if(row == -1) {
				int[] ans = {-1,-1};
				return ans;
			}	
		}//finding the numbers the user typed and returning one backwards
		int[] ans = {row,col};
		return ans;
	}
	
	public static void run() {//Determines if there is a solution to the matrix and if so prints it.
		System.out.println("Looking for a solution...");
		int[] pointer = new int[2];
		pointer[0] = 0;//pointer for row number
		pointer[1] = 0;//pointer for column number
		while(pointer[0] != -1 && pointer[0] != 9) {
			if(checkSlot(pointer[0],pointer[1])) {
				if(pointer[1]==8) {
					pointer[0] = pointer[0] + 1;
					pointer[1] = 0;
				}// if we are at the end of the row, we moving forward to the next one
				else {
					pointer[1] = pointer[1] + 1;
				}//moving forward to the next column
			}
			else {
				pointer = checkLastSlot(pointer[0], pointer[1]);
			}// if we cannot reach to combination with the followings numbers we go backwards
		}//checking the possible combination for each slot
		if(pointer[0] == -1) {
			System.out.println("There is no valid solution");
		}//if we reach to the index before the index of the first row (index -1)
		if(pointer[0] == 9) {
			System.out.println("The solution is:");
			printMat();
		}// there is combination that solve the mat
	}
	
	static public void scanFromUser() {//Prints the start sentences, makes sure the user enters correct values after them
		Scanner sc = new Scanner(System.in);
		String input = "";
		System.out.println("Welcome to FATMA SODUKO 2022. To start, press enter");	
		input = sc.nextLine();
		while (input.length() != 0) {
			System.out.println("Welcome to FATMA SODUKO 2022. To start, press enter");
			input = sc.nextLine();
			}
		System.out.println("Please enter a given number and its location.");
		String num = sc.nextLine();
		while(!num.equals("00-0")) {
			if (CheckNum(num) == false) {
				System.out.println("The input is not valid. Please try again");
			}	
			else {
				mat[Character.getNumericValue(num.charAt(0))][Character.getNumericValue(num.charAt(1))] = Character.getNumericValue(num.charAt(3));
				given[Character.getNumericValue(num.charAt(0))][Character.getNumericValue(num.charAt(1))] = true;
			}
			System.out.println("Please enter a given number and its location.");
			num = sc.nextLine();
		}
	}
	
	static public void printMat() {//Prints the soduko with the user's numbers
		for(int i=0;i<mat.length;i++) {
			for(int j=0;j<mat[i].length;j++) {
				System.out.print(mat[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		scanFromUser();
		System.out.println("The given numbers are:");
		printMat();
		run();
	}
}


